#!/usr/bin/env python3
"""PJM 1.3.10: all production classes unchanged; refreshed PJR 0.1.23 offline map data."""
import argparse,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE_JAR='73c3065370afa1efe80bfce29dcc5b193d6c0e8f6958587f8dfdd77ca179c17a'
BASE_SOURCE='68fe6685bd83f811de425a697bb2346c229f6657f057bd65d40605828f8d9739'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser()
 for n in ['baseline-jar','baseline-source','pjr-jar']:ap.add_argument('--'+n,type=Path,required=True)
 a=ap.parse_args();assert sha(a.baseline_jar)==BASE_JAR and sha(a.baseline_source)==BASE_SOURCE
 binding=json.loads((ROOT/'data/pjr-0.1.23-binding.json').read_text());assert sha(a.pjr_jar)==binding['jar_sha256']
 with zipfile.ZipFile(a.baseline_source) as z:
  prefix='Project-Japan-Map-V1.3.9-source/src/main/java/'
  old_sources={n[len(prefix):]:z.read(n) for n in z.namelist() if n.startswith(prefix) and n.endswith('.java')}
 actual={p.relative_to(ROOT/'src/main/java').as_posix():p.read_bytes() for p in (ROOT/'src/main/java').rglob('*.java')};assert actual==old_sources,'Production Java changed'
 with zipfile.ZipFile(a.baseline_jar) as z:old={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
 resources={p.relative_to(ROOT/'src/main/resources').as_posix():p.read_bytes() for p in (ROOT/'src/main/resources').rglob('*') if p.is_file()}
 for n,b in old.items():
  if n.startswith('assets/') and not n.startswith('assets/pjm/precomputed/'):assert resources[n]==b,n
 index=dict(l.split('=',1) for l in resources['assets/pjm/precomputed/index.properties'].decode().splitlines() if '=' in l)
 assert index['fingerprint']==binding['fingerprint'] and index['renderer']=='render-v10-river-coverage' and index['provider']=='pjr'
 assert 'legacyFingerprints' not in index,'Old pixels must not be accepted for changed water inputs'
 tiles={k:v for k,v in index.items() if '/' in k};assert len(tiles)==1345
 for k,v in tiles.items():
  assert v in ['png','empty']
  assert ('assets/pjm/precomputed/'+k+'.png' in resources)==(v=='png')
 props=dict(l.split('=',1) for l in (ROOT/'gradle.properties').read_text().splitlines() if '=' in l);assert props['mod_version']=='1.3.10'
 for n in ['META-INF/mods.toml','pack.mcmeta']:
  for k,v in props.items():resources[n]=resources[n].replace(('${'+k+'}').encode(),v.encode())
 entries={n:b for n,b in old.items() if not n.startswith('assets/pjm/precomputed/')};entries.update(resources)
 entries['META-INF/MANIFEST.MF']=b'Manifest-Version: 1.0\r\nImplementation-Title: Project Japan Map\r\nImplementation-Version: 1.3.10\r\n\r\n'
 out=ROOT/'build/libs/pjm-1.3.10.jar';out.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(entries.items()):
   i=zipfile.ZipInfo(n,(2026,10,9,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b,compresslevel=9)
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None
  retained={n:b for n,b in old.items() if n.endswith('.class')};assert all(z.read(n)==b for n,b in retained.items())
 report=f'PJM map-data-only assembly PASS\nversion=1.3.10\njarBytes={out.stat().st_size}\nSHA256={sha(out)}\nunchangedProductionJavaSources={len(actual)}\nunchangedProductionClasses={len(retained)}\nmapTiles={len(tiles)}\nfingerprint={binding["fingerprint"]}\n'
 report+='PJR 0.1.23 changed actual water data. Changed map tiles rendered; unaffected tiles reused only with recorded spatial-input parity proof. Old fingerprint aliases deliberately absent. No client/GPU/FPS test claimed.\n'
 (ROOT/'validation/assembly-1.3.10.txt').write_text(report);print(report)
if __name__=='__main__':main()
