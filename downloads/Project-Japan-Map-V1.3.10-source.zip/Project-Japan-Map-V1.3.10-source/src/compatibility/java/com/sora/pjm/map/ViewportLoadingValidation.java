package com.sora.pjm.map;
import com.sora.pjr.core.WorldEngine;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;
import java.lang.reflect.*;
import java.io.*;
import java.security.*;
import javax.imageio.ImageIO;

/** Real release classes and PJR data, two read/decode workers; no GPU/game timing claim. */
public final class ViewportLoadingValidation {
 public static void main(String[] args) throws Exception {
  Path out=Path.of(args[0]);Files.createDirectories(out);
  long t=System.nanoTime();var engine=WorldEngine.load();double engineMs=ms(t);
  t=System.nanoTime();var actual=new PJMProjectJapanRefinedRuntime(engine,System.getProperty("pjr.version","0.1.23-alpha"));double adapterMs=ms(t);
  System.out.println("fingerprint="+actual.fingerprint()+" engineMs="+engineMs+" adapterMs="+adapterMs);
  if(Boolean.getBoolean("pjm.fingerprintOnly"))return;
  LongAdder queries=new LongAdder();
  PJMGeographicRuntime runtime=(PJMGeographicRuntime)Proxy.newProxyInstance(ViewportLoadingValidation.class.getClassLoader(),new Class[]{PJMGeographicRuntime.class},(p,m,a)->{
   if(Set.of("visualTerrain","terrain","lakeWater","riverWater","riverSegments","surveyedWater").contains(m.getName())) {
    queries.increment();if(Boolean.getBoolean("pjm.requireNoQueries"))throw new AssertionError("Unbundled visible tile: "+m.getName());
   }
   try{return m.invoke(actual,a);}catch(InvocationTargetException e){throw e.getCause();}
  });
  var source=new PJMProjectJapanMapSource(runtime,out.resolve("cache"));var h=source.header();
  // Screenshot zoom 3.50, 2048x1132 client pixels at GUI scale 2; Tokyo-centred representative view.
  int level=4,width=1024,height=566;double scale=Math.pow(2,3.5-level),axis=1<<level;
  double cx=(0-h.minWorldX())/h.worldWidth()*256*axis,cy=(0-h.minWorldZ())/h.worldHeight()*256*axis;
  double left=cx-width/scale/2,top=cy-height/scale/2;
  List<PJMTileKey> keys=new ArrayList<>();
  for(int y=Math.max(0,(int)Math.floor(top/256));y<=Math.min((int)axis-1,(int)Math.floor(Math.nextDown(top+height/scale)/256));y++)
   for(int x=Math.max(0,(int)Math.floor(left/256));x<=Math.min((int)axis-1,(int)Math.floor(Math.nextDown(left+width/scale)/256));x++)keys.add(new PJMTileKey(level,x,y));
  var pool=Executors.newFixedThreadPool(2);var completions=new ExecutorCompletionService<String>(pool);var hashes=new TreeSet<String>();t=System.nanoTime();final long start=t;
  for(var key:keys)completions.submit(()->{
   byte[] b=source.readTile(key);
   if(b!=null){var image=ImageIO.read(new ByteArrayInputStream(b));if(image==null||image.getWidth()!=256||image.getHeight()!=256)throw new AssertionError(key);image.flush();}
   return key+" "+(b==null?"empty":HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b)));
  });
  double first=0,total=0;
  try{for(int i=0;i<keys.size();i++){var done=completions.poll(300,TimeUnit.SECONDS);if(done==null)throw new AssertionError("Viewport stalled");hashes.add(done.get());if(i==0)first=ms(start);System.out.println("resolved="+(i+1)+"/"+keys.size()+" elapsedMs="+ms(start));}total=ms(start);}finally{pool.shutdownNow();}
  String report=String.format(Locale.ROOT,"Viewport backend PASS%nzoom=3.50 level=4 logicalViewport=1024x566 centreWorld=0,0 workers=2%nvisibleTiles=%d firstTileMs=%.3f allTilesReadDecodeMs=%.3f%nterrainAndWaterQueries=%d%nengineInitMs=%.3f adapterInitMs=%.3f%nfingerprint=%s%nExcludes GPU uploads, road overlay, client frames; ImageIO PNG decode included.%n",keys.size(),first,total,queries.sum(),engineMs,adapterMs,actual.fingerprint());
  Files.writeString(out.resolve("viewport.txt"),report);Files.write(out.resolve("tile-hashes.txt"),hashes);System.out.print(report);
 }
 static double ms(long start){return (System.nanoTime()-start)*1e-6;}
}
