package com.sora.pjm.map;

import com.sora.pjr.core.*;
import java.io.ByteArrayInputStream;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Compares the adapter and real rendered tiles to the supplied PJR engine, without game stubs. */
public final class PJRCompatibilityValidation {
    private static int checks, lakeSamples, riverSamples, holes;

    public static void main(String[] args) throws Exception {
        Path output = Path.of(args[0]);
        Files.createDirectories(output);
        long started = System.nanoTime();
        String expectedRelease = System.getProperty("pjm.expectedReleaseJar");
        if (expectedRelease != null) {
            for (Class<?> type : List.of(PJMProjectJapanRefinedRuntime.class,
                    PJMProjectJapanMapSource.class, PJMPlaceNames.class, PJMAsyncTileLoader.class)) {
                Path actual = Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI());
                require(Files.isSameFile(actual, Path.of(expectedRelease)), "Final JAR class origin " + type.getSimpleName());
            }
            System.out.println("PJM_FINAL_JAR_ORIGIN_PASS: " + Path.of(expectedRelease).getFileName());
        }
        providerSelection();
        WorldEngine engine = WorldEngine.load();
        Terrain terrain = engine.hydrology().terrain();
        WorldData data = engine.hydrology().data();
        var runtime = new PJMProjectJapanRefinedRuntime(engine, System.getProperty("pjr.version", "0.1.21-alpha"));
        require(data.rivers().size() == 356 && data.lakes().size() == 221, "source dataset counts");
        require(runtime.footprintScale() == 8.0 / Geo.METRES_XZ, "active geographic footprint scale");
        require(runtime.worldXFromLongitude(Geo.ORIGIN_LON) == 0, "Tokyo X origin");
        require(runtime.worldZFromLatitude(Geo.ORIGIN_LAT) == 0, "Tokyo Z origin");
        Random random = new Random(131);
        for (int i = 0; i < 3000; i++) {
            double lon = 122 + random.nextDouble() * 32, lat = 20 + random.nextDouble() * 26;
            int x = runtime.worldXFromLongitude(lon), z = runtime.worldZFromLatitude(lat);
            require(Math.abs(x - Geo.x(lon)) <= .50001, "longitude projection");
            require(Math.abs(z - Geo.z(lat)) <= .50001, "latitude projection");
            require(Math.abs(runtime.longitudeFromWorldX(x) - Geo.lon(x)) < 1e-10, "inverse longitude");
            require(Math.abs(runtime.latitudeFromWorldZ(z) - Geo.lat(z)) < 1e-10, "inverse latitude");
            var expected = terrain.sample(x, z);
            var actual = runtime.terrain(x, z);
            require(expected.land() == actual.land()
                    && Math.round(expected.metres()) == actual.elevationMetres()
                    && Math.abs(expected.coverage() - actual.coverage()) < 1e-12, "terrain runtime sample");
        }
        int namedRivers = 0, namedLakes = 0;
        for (River river : data.rivers()) {
            String label = PJMPlaceNames.display(PJMPlaceNames.Kind.RIVER, river.name());
            require(!label.isBlank() && !label.matches(".*[A-Za-z].*"), "Unresolved active river name " + river.name());
            namedRivers++;
        }
        for (Lake lake : data.lakes()) {
            String label = PJMPlaceNames.display(PJMPlaceNames.Kind.LAKE, lake.name());
            require(!label.isBlank() && !label.matches(".*[A-Za-z].*"), "Unresolved active lake name " + lake.name());
            namedLakes++;

            checkLake(engine, runtime, lake.representativeX(), lake.representativeZ());
            List<Polygon.Ring> rings = new ArrayList<>();
            rings.add(lake.polygon().outer());
            rings.addAll(lake.polygon().holes());
            holes += lake.polygon().holes().size();
            for (Polygon.Ring ring : rings) {
                for (int i = 0; i < ring.size(); i += Math.max(1, ring.size() / 12)) {
                    for (int offset : new int[]{-2, 0, 2})
                        checkLake(engine, runtime, ring.x(i) + offset, ring.z(i) - offset);
                }
            }
        }
        for (River river : data.rivers()) {
            for (int i = 0; i <= 16; i++) {
                River.Point point = river.at(river.totalLength() * i / 16.0);
                for (double offset : new double[]{0, point.width() * .5, point.width() * .5 + 2}) {
                    int x = (int)Math.floor(point.x() + offset), z = (int)Math.floor(point.z());
                    var water = engine.hydrology().sample(x, z).water();
                    var actual = runtime.riverSample(x, z);
                    require(actual.water() == (water.kind() == Hydrology.Kind.RIVER), "river ownership " + river.name());
                    if (actual.water()) require(actual.name().equals(water.owner().startsWith("tidal:") ? "" : water.owner()), "river display identity");
                    riverSamples++;
                }
            }
        }
        int count = runtime.riverSegments(runtime.minWorldX(), runtime.minWorldZ(), runtime.maxWorldX(), runtime.maxWorldZ()).size();
        require(count == data.rivers().stream().mapToInt(r -> r.segments().size()).sum(), "all solved river segments extracted");
        PJMExternalGeodata labels = new PJMExternalGeodata(runtime);
        require(labels.cityAt(0, 0).equals("东京都"), "Tokyo HUD city projection");
        require(labels.cityCount() > 100 && labels.mountainCount() > 10, "bundled geographic data loaded");
        require(!labels.mountainAt(runtime.worldXFromLongitude(138.7274), runtime.worldZFromLatitude(35.3606)).isBlank(), "Fuji mountain footprint");

        // Separate provider directories must not remove an existing PJ cache.
        Path cache = output.resolve("cache");
        Files.createDirectories(cache.resolve("projectjapan/old-pj"));
        Files.writeString(cache.resolve("projectjapan/old-pj/sentinel"), "old PJ");
        Files.createDirectories(cache.resolve("pjr/render-v7-pjr-compat-old"));
        Files.writeString(cache.resolve("pjr/render-v7-pjr-compat-old/stale.png"), "old coastal tile");
        var source = new PJMProjectJapanMapSource(runtime, cache);
        require(source.header().maxZoom() == 14, "PJR local zoom resolution");
        require(Files.exists(cache.resolve("projectjapan/old-pj/sentinel")), "PJ/PJR cache isolation");
        long cleanupDeadline = System.nanoTime() + 5_000_000_000L;
        while (Files.exists(cache.resolve("pjr/render-v7-pjr-compat-old")) && System.nanoTime() < cleanupDeadline)
            Thread.sleep(5);
        require(!Files.exists(cache.resolve("pjr/render-v7-pjr-compat-old")), "old coastal cache cleaned off render thread");
        render(source, new PJMTileKey(0, 0, 0), output.resolve("japan.png"));
        for (String name : new String[]{"Biwa", "津久井湖"}) {
            Lake lake = data.lakes().stream().filter(l -> l.name().equals(name)).findFirst().orElseThrow();
            var overview = tileAt(source.header(), 8, lake.representativeX(), lake.representativeZ());
            render(source, overview, output.resolve(name + "-overview.png"));
        }
        River outlet = data.rivers().stream().filter(r -> r.name().equals("Yodo") || r.name().equals("淀川")).findFirst().orElseThrow();
        River.Point p = outlet.at(0);
        PJMTileKey local = tileAt(source.header(), 14, p.x(), p.z());
        byte[] png = render(source, local, output.resolve("biwa-outlet-local.png"));
        var image = ImageIO.read(new ByteArrayInputStream(png));
        PJMMapHeader h = source.header();
        int wet = 0;
        for (int y = 0; y < 256; y++) for (int x = 0; x < 256; x++) {
            int wx = (int)Math.floor(h.minWorldX() + (local.x() * 256.0 + x + .5) * h.worldWidth() / (256 * (1 << local.zoom())));
            int wz = (int)Math.floor(h.minWorldZ() + (local.y() * 256.0 + y + .5) * h.worldHeight() / (256 * (1 << local.zoom())));
            var water = engine.hydrology().sample(wx, wz).water();
            int color = image.getRGB(x, y);
            require((color == 0xFF5B9DBB) == (water.kind() == Hydrology.Kind.LAKE), "rendered lake pixel matches PJR");
            if (terrain.sample(wx, wz).land())
                require((color == 0xFF4E9FC8) == (water.kind() == Hydrology.Kind.RIVER), "rendered river pixel matches PJR");
            if (water.wet()) wet++;
        }
        require(wet > 0, "local tile covers water");
        require(Arrays.equals(png, source.readTile(local)), "tile cache readback");
        String report = String.format(Locale.ROOT,
                "PJR_COMPATIBILITY_PASS%nPJR: %s%nAssertions: %d%nLakes: 221; shoreline samples: %d; island holes: %d%nRivers: 356; water samples: %d; segments: %d%nProjection/terrain random points: 3000%nExact local tile pixels: 65536%nProvider selection, city/mountain labels, cache isolation/readback: PASS%nAll 356 river and 221 lake display names resolved without roman IDs.%nElapsed seconds: %.2f%n",
                runtime.version(), checks, lakeSamples, holes, riverSamples, count, (System.nanoTime() - started) / 1e9);
        Files.writeString(output.resolve("validation.txt"), report);
        System.out.print(report);
    }

    private static void checkLake(WorldEngine engine, PJMGeographicRuntime runtime, int x, int z) {
        var water = engine.hydrology().sample(x, z).water();
        var actual = runtime.lakeSample(x, z);
        require(actual.water() == (water.kind() == Hydrology.Kind.LAKE), "lake shoreline at " + x + "," + z);
        if (actual.water()) require(actual.name().equals(water.lake().name()), "lake name uses display name, not ID");
        lakeSamples++;
    }

    private static PJMTileKey tileAt(PJMMapHeader h, int zoom, double x, double z) {
        int axis = 1 << zoom;
        return new PJMTileKey(zoom, (int)Math.floor((x - h.minWorldX()) / h.worldWidth() * axis),
                (int)Math.floor((z - h.minWorldZ()) / h.worldHeight() * axis));
    }

    private static byte[] render(PJMProjectJapanMapSource source, PJMTileKey key, Path path) throws Exception {
        long start = System.nanoTime();
        byte[] png = source.readTile(key);
        require(png != null, "nonempty map tile " + key);
        Files.write(path, png);
        System.out.printf(Locale.ROOT, "Rendered %s in %.3f seconds%n", path.getFileName(), (System.nanoTime() - start) / 1e9);
        return png;
    }

    private static void providerSelection() {
        require(PJMRuntimeRegistry.select(true, true, "pjr") == PJMRuntimeRegistry.Kind.PJR, "both mods, PJR world");
        require(PJMRuntimeRegistry.select(true, true, "projectjapan") == PJMRuntimeRegistry.Kind.PJ, "both mods, PJ world");
        require(PJMRuntimeRegistry.select(false, true, "pjr") == PJMRuntimeRegistry.Kind.PJR, "PJR only");
        require(PJMRuntimeRegistry.select(true, false, "projectjapan") == PJMRuntimeRegistry.Kind.PJ, "PJ only");
        require(PJMRuntimeRegistry.select(false, false, "minecraft") == PJMRuntimeRegistry.Kind.NONE, "standalone");
        require(PJMRuntimeRegistry.select(true, false, "pjr") == PJMRuntimeRegistry.Kind.NONE, "missing PJR client provider");
        require(PJMRuntimeRegistry.select(true, true, "minecraft") == PJMRuntimeRegistry.Kind.NONE, "ambiguous world does not pick wrong scale");
    }

    private static void require(boolean value, String detail) {
        checks++;
        if (!value) throw new AssertionError(detail);
    }
}
