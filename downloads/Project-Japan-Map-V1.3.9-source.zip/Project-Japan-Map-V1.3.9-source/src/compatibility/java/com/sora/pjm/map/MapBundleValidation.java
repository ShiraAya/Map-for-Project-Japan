package com.sora.pjm.map;

import com.sora.pjr.core.WorldEngine;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicInteger;
import javax.imageio.ImageIO;

/** Cold bundled reads, no terrain queries, stale-fingerprint rejection and PNG integrity. */
public final class MapBundleValidation {
 public static void main(String[] args) throws Exception {
  Path out=Path.of(args[0]);Files.createDirectories(out);
  long init=System.nanoTime();var engine=WorldEngine.load();
  double engineMs=(System.nanoTime()-init)*1e-6;
  init=System.nanoTime();var runtime=new PJMProjectJapanRefinedRuntime(engine,"0.1.21-alpha");
  double adapterMs=(System.nanoTime()-init)*1e-6;
  var source=new PJMProjectJapanMapSource(runtime,out.resolve("fresh-cache"));
  StringBuilder report=new StringBuilder("PJM offline map bundle PASS\nPJR=0.1.21-alpha\n");
  report.append(String.format(Locale.ROOT,"engineInitMs=%.3f adapterInitMs=%.3f%n",engineMs,adapterMs));
  for(int zoom:new int[]{14,8,4,0}) {
   int x=runtime.worldXFromLongitude(139.7671),z=runtime.worldZFromLatitude(35.6812);
   var h=source.header();var key=new PJMTileKey(zoom,(int)Math.floor((x-h.minWorldX())/h.worldWidth()*(1<<zoom)),(int)Math.floor((z-h.minWorldZ())/h.worldHeight()*(1<<zoom)));
   long started=System.nanoTime();byte[] png=source.readTile(key);double ms=(System.nanoTime()-started)*1e-6;
   if(png==null)throw new AssertionError("Missing Tokyo tile");
   Files.write(out.resolve("z"+zoom+".png"),png);
   report.append(String.format(Locale.ROOT,"cold %s readMs=%.6f bytes=%d%n",key,ms,png.length));
  }
  Properties index=new Properties();
  try(var in=MapBundleValidation.class.getResourceAsStream("/assets/pjm/precomputed/index.properties")){index.load(in);}
  if(!runtime.fingerprint().equals(index.getProperty("fingerprint")))throw new AssertionError("PJR fingerprint mismatch");
  int images=0,empty=0;
  for(String key:index.stringPropertyNames()) {
   if(!key.contains("/"))continue;
   if(index.getProperty(key).equals("empty")){empty++;continue;}
   try(var in=MapBundleValidation.class.getResourceAsStream("/assets/pjm/precomputed/"+key+".png")) {
    var image=ImageIO.read(in);if(image==null||image.getWidth()!=256||image.getHeight()!=256)throw new AssertionError(key);images++;
   }
  }
  AtomicInteger queried=new AtomicInteger();
  PJMGeographicRuntime guard=(PJMGeographicRuntime)Proxy.newProxyInstance(MapBundleValidation.class.getClassLoader(),new Class[]{PJMGeographicRuntime.class},(proxy,method,values)->{
   if(Set.of("visualTerrain","terrain","lakeWater","riverWater","surveyedWater","riverSegments").contains(method.getName()))throw new AssertionError("Bundled read sampled PJR: "+method.getName());
   return method.invoke(runtime,values);
  });
  var guarded=new PJMProjectJapanMapSource(guard,out.resolve("guard-cache"));
  if(guarded.readTile(new PJMTileKey(0,0,0))==null)throw new AssertionError("Bundled map unavailable");
  PJMGeographicRuntime changed=(PJMGeographicRuntime)Proxy.newProxyInstance(MapBundleValidation.class.getClassLoader(),new Class[]{PJMGeographicRuntime.class},(proxy,method,values)->{
   return switch(method.getName()) {
    case "fingerprint" -> "different-pjr-data";
    case "visualTerrain" -> {queried.incrementAndGet();yield new PJMGeographicRuntime.VisualTerrain(false,0,0);}
    case "lakeWater","riverWater","vectorRiversAvailable","exactLocalRivers" -> false;
    case "surveyedWater" -> PJMGeographicRuntime.SurveyWater.UNMAPPED;
    default -> method.invoke(runtime,values);
   };
  });
  var stale=new PJMProjectJapanMapSource(changed,out.resolve("changed-cache"));
  if(stale.readTile(new PJMTileKey(0,0,0))!=null||queried.get()==0)throw new AssertionError("Wrong provider fingerprint used bundled pixels");
  report.append("bundledPngs=").append(images).append("\nbundledEmptyTiles=").append(empty)
   .append("\nmatchingFingerprintTerrainQueries=0\nchangedFingerprintFallback=PASS\nPNGDimensions=256x256 PASS\n");
  report.append("Timings measure tile byte generation/read, excluding engine initialization, GPU uploads and client frames.\n");
  Files.writeString(out.resolve("validation.txt"),report);System.out.print(report);
 }
}
