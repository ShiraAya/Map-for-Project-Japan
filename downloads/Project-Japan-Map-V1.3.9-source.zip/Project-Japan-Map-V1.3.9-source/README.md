# Project Japan Map

**Project Japan Map V1.3.9** is a Minecraft Forge 1.20.1 map, minimap, geography HUD and waypoint companion designed for **Project Japan** and **ProjectJapanRefined (PJR)**.

> [!IMPORTANT]
> **This mod is AI-generated and AI-assisted.**  
> Source code, implementation, debugging, refactoring, data-processing logic and documentation have been produced or modified with generative AI under the direction and review of the project author.

## Project Information

- **Release:** Project Japan Map V1.3.9
- **Minecraft:** 1.20.1
- **Forge:** 47.4.20
- **Java:** 17
- **Mod ID:** `pjm`
- **Status:** Active

## Map controls

- `M` — open the full map
- `N` — toggle the minimap
- `Z` — change minimap zoom
- `\` — cycle the synchronized map mode used by both minimap and full-screen map

Modes:

- **Default mode** — Project Japan geographic terrain + CityBuild road overlay. Roads appear only at `zoom >= 3.50`.
- **Terrain mode** — Project Japan geographic terrain only.
- **Map mode** — conventional coloured top-down Minecraft block map.

## PJR 0.1.21 / 0.1.22 loading performance in V1.3.9

- Offline precomputed maps use the same terrain, lake and river predicates as live maps. The bundle covers all national overview tiles at zoom 0–4 and the precision-coast footprints of 16 cities at zoom 5–9.
- Bundled maps are used only when the active PJR data fingerprint and renderer revision match. Display-version changes alone no longer invalidate maps. Explicitly audited PJR 0.1.21/0.1.22 code is map-equivalent; unknown code/data changes still invalidate. Unbundled detailed zooms use the live provider and disk cache.
- Fine terrain queries run in spatial order, with terrain and water passes fused to reuse PJR's bounded atlas cache. Nearby queries share the same immutable runtime; no additional national model is loaded.
- Running obsolete map jobs cancel cooperatively when the player changes the view. Known compatible 0.1.21/0.1.22 disk caches are retained; incompatible old caches are removed in the background.
- Latest PJR's public terrain getter is preferred; the older field-based adapter remains a fallback for PJR 0.1.1.
- Existing roads, map modes, waypoint controls and names retain their original compiled classes and resources.
- See `RELEASE_NOTES_V1.3.9.md` and `validation/` for results and limitations. Full ForgeGradle and a graphical client are not available in this build environment. This release recompiles the map source and PJR adapter, retains other client classes from 1.3.8, and preserves every existing offline map PNG byte-for-byte. See validation/1.3.9 for cache identity and viewport checks.

## Zoom responsiveness and geographic names in V1.3.3

- Decodes PNG tiles on background workers; the render thread only uploads completed images.
- Keeps loading work bounded, discards obsolete views and prioritizes tiles near the view centre.
- Shares a two-upload budget across active terrain, road and block-map layers per render. The optional 2 ms time check is a soft budget, not a guaranteed frame duration.
- Reuses uploaded overview tiles during rapid zoom and bounds fallback detail when zooming out.
- Resolves rivers, lakes, mountains, cities, prefectures, marine areas and islands through one exact, type-aware name catalogue. Verified official Chinese names take priority; otherwise the recorded Japanese name is preserved.
- Covers all 356 active PJR rivers, 221 lakes, 1,537 bundled geographic records and the supplied legacy PJ's 115 river / 33 lake identifiers. Internal roman IDs and anonymous water-owner IDs are not displayed as names.
- This PJM update does not change world generation. Keep the matching PJR 0.1.21 installed separately; replace the PJM JAR and restart. Existing worlds and waypoints remain usable; geographic tile caches follow the current data fingerprint.
- See `RELEASE_NOTES_V1.3.3.md`, `NAME-LOCALIZATION.md`, `ZOOM-PERFORMANCE.md` and `VALIDATION_V1.3.3.md`. Earlier Tokyo-water reports describe historical releases. The current release targets PJR 0.1.21-alpha.

## PJR compatibility

- Targets the supplied **PJR 0.1.21-alpha**, Minecraft 1.20.1 / Forge 47.4.20.
- Reads `Geo` from the loaded PJR: uniform **0.5 : 0.5 : 0.5**, Tokyo station at `(0, 0)`.
- Reuses PJR's loaded world engine and terrain raster; PJM bundles derived preview tiles while reusing PJR for the terrain model.
- Draws the 356 solved rivers and 221 lakes from that engine. Lake islands and shorelines use PJR's own block-water predicate. Detailed river tiles use the actual hydrology result, including lake ownership and blocked banks.
- Projects city, prefecture, mountain and island labels with PJR coordinates. Geographic footprints scale with the world; the river/lake and mountain-foot outside display distances remain **30 blocks**.
- Raises the PJR map's maximum tile zoom to 14 so local maps retain detail across the larger world.
- When PJ and PJR are both installed, the synchronized dimension type chooses the matching provider. An unknown world with both installed uses the standalone fallback rather than guessing a scale.
- Geographic cache directories are independent: `config/PJM/cache/projectjapan/` and `config/PJM/cache/pjr/`. Fingerprints include PJR projection, implementation and geography resource bytes.
- Both maps and the geography HUD share the provider. World/dimension changes reset the minimap and discard stale HUD results.
- Existing block map, CityBuild road style, 3.50 road display threshold and waypoint controls remain available.

Install `pjm-1.3.8.jar` in the client's `mods` folder, replacing the previous PJM JAR. Install PJR separately. No PJR source or generated world needs modifying. No PJM installation is required on a dedicated server; clients need the corresponding world mod and matching data.

**Existing waypoints use actual Minecraft coordinates.** Old PJ waypoint positions are not multiplied by three or migrated into PJR worlds automatically. Use each world's own waypoint/cache directory.

See `RELEASE_NOTES_V1.3.2.md` and `VALIDATION_V1.3.2.md` for scope and verification.

## V1.3 map-mode rewrite

V1.3 removes the V1.2 `surface/*.pjms` implementation completely and replaces it with a new `blockmap` subsystem.

The new map mode:

- samples only chunks already present in the client chunk cache; it never requests or generates chunks
- finds the upper visible map surface in each X/Z column
- skips non-colliding decorative noise such as flowers, grass tufts and torches instead of allowing them to dominate single map pixels
- uses the block's Minecraft `MapColor.col` (`0xRRGGBB`) directly; the V1.2 ABGR/ARGB conversion path no longer exists
- blends Minecraft's client block-colour resolver into biome-tinted blocks such as grass, foliage and water
- applies a restrained local height shade so hills and built structures remain readable without changing material identity
- stores one 16×16 colour raster per explored chunk
- uses 4×4 and 16×16 precomputed averages when zoomed out, avoiding per-block work for large-area map tiles
- keeps an independent GPU tile cache from the geographic and road layers
- scans a small amount in the background even outside Map mode so switching modes does not start from an empty view
- increases the scan budget only while Map mode is active

New cache location:

```text
.minecraft/PJM/cache/<存档名称>/blockmap/minecraft_overworld/regions/
```

Each `.pjmb` file covers 32×32 chunks. Old `.pjms` files from V1.2 are not read and may be deleted manually later; leaving them in place has no effect.

## Faster CityBuild road updates

The V1.1/V1.2 road drawing style itself is unchanged. V1.3 changes only how quickly the cached road geometry is refreshed:

- `zoom < 3.50` still hides the road overlay
- current chunk refresh target: about 0.25 s
- immediate neighbouring chunks: about 0.5 s
- progressively farther chunks use longer intervals
- up to 6 already-loaded chunks may be processed in one client tick, but a short nanosecond time budget stops the loop early on slower systems
- client chunk-load and block place/break events are promoted to an urgent queue when Forge exposes them
- uncached chunks receive priority over already-known distant chunks
- changed chunks invalidate only intersecting road GPU tiles
- road tile regeneration now has two lightweight workers instead of one
- road region storage remains the compact `.pjmr` 32×32-chunk format

Road cache location:

```text
.minecraft/PJM/cache/<存档名称>/roads/minecraft_overworld/regions/
```

## Geography HUD

Static geography required by the HUD is bundled in the mod JAR. Nearby hydrology is sampled dynamically from the active PJ/PJR runtime.

Current display behaviour includes:

- nearest named river within 30 blocks
- nearest named lake within 30 blocks
- river and lake labels can be displayed together
- mountain labels use terrain-derived mountain footprints
- marine labels use type-sensitive ranges
- Tokyo special-ward locations are presented as `东京都`

## Waypoints

- `B` — create a waypoint
- `U` — open the waypoint manager
- add / edit / delete waypoints
- editable colour and initials / symbol
- hide / show individual waypoints
- client-only teleport in single-player and multiplayer through the vanilla `/tp` command
- PJM does not need to be installed on a dedicated server; the server only needs to grant the player `/tp` permission

## Building

Requirements:

- Java 17
- Minecraft 1.20.1
- Forge 47.4.20

Windows:

```powershell
gradlew.bat clean build
```

Linux / macOS:

```bash
./gradlew clean build
```

The installable, reobfuscated JAR is written to `build/libs/`. ForgeGradle is pinned to 6.0.54. A locally installed Java 17 JDK is required.

Optional integration validation with an extracted PJR source tree:

```bash
./gradlew check build validateReleasePjrCompatibility -PpjrSource=/absolute/path/ProjectJapanRefined
```

The PJR core source is compiled only into this validation source set and is excluded from the PJM mod JAR.

## AI Development Disclosure

Project Japan Map is an **AI-generated / AI-assisted software project**. AI-generated code is not assumed to be correct automatically; development direction, acceptance decisions and practical testing are controlled by the project author.

## Attribution

See `ATTRIBUTION.md` for bundled geography data and external interaction references.

## Current Release

**Project Japan Map V1.3.9**
