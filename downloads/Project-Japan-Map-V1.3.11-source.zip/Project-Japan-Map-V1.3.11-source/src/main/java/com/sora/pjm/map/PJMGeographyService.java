package com.sora.pjm.map;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.function.Supplier;

/**
 * Real-world geography context shown below the minimap.
 *
 * <p>0.19: all static geography is bundled in the PJM jar. There is no HTTP/cache loading.
 * River/lake geometry still comes from the currently loaded ProjectJapan runtime. One displayed
 * metre equals one Minecraft block for HUD proximity thresholds.</p>
 */
public final class PJMGeographyService {
    public static final PJMGeographyService INSTANCE = new PJMGeographyService();

    private static final int UPDATE_INTERVAL_TICKS = 60;
    private static final int MOVE_REFRESH_BLOCKS = 32;

    // Local HUD labels should describe features the player is actually near, not features
    // hundreds of blocks away. River/lake proximity is therefore a strict 30-block radius.
    private static final int RIVER_SEARCH_RADIUS = 30;
    private static final int RIVER_SEARCH_STEP = 1;
    private static final int LAKE_SEARCH_RADIUS = 30;
    private static final int LAKE_SEARCH_STEP = 1;

    // Marine names may reasonably carry a little farther inland than a river/lake label, but the
    // allowed distance is type-sensitive (strait/channel < bay < sea) in nearbyMarine().
    private static final int COAST_SEARCH_RADIUS = 120;
    private static final int COAST_SEARCH_STEP = 4;

    private final ExecutorService worker;
    private volatile Snapshot snapshot = Snapshot.EMPTY;
    private volatile boolean pending;
    private PJMExternalGeodata external;

    // These three geographic fields are owned exclusively by the single background worker.
    private PJMGeographicRuntime runtime;
    private PJMRuntimeRegistry.Kind runtimeKind = PJMRuntimeRegistry.Kind.NONE;
    private volatile long generation;
    private List<FallbackAnchor> fallbackPrefectures = List.of();

    private int lastX = Integer.MIN_VALUE;
    private int lastZ = Integer.MIN_VALUE;
    private int lastTick = Integer.MIN_VALUE;

    private PJMGeographyService() {
        worker = Executors.newSingleThreadExecutor(daemonFactory("PJM-Geography"));
    }

    private static ThreadFactory daemonFactory(String name) {
        return runnable -> {
            Thread thread = new Thread(runnable, name);
            thread.setDaemon(true);
            return thread;
        };
    }

    public Snapshot snapshot() {
        return snapshot;
    }

    public void tick(Minecraft minecraft) {
        if (minecraft.player == null || minecraft.level == null) {
            reset();
            return;
        }

        int x = Mth.floor(minecraft.player.getX());
        int z = Mth.floor(minecraft.player.getZ());
        int tick = minecraft.player.tickCount;

        boolean moved = lastX == Integer.MIN_VALUE
                || Math.abs(x - lastX) >= MOVE_REFRESH_BLOCKS
                || Math.abs(z - lastZ) >= MOVE_REFRESH_BLOCKS;
        boolean elapsed = lastTick == Integer.MIN_VALUE
                || tick - lastTick >= UPDATE_INTERVAL_TICKS;
        if (pending || (!moved && !elapsed)) return;

        pending = true;
        lastX = x;
        lastZ = z;
        lastTick = tick;

        long taskGeneration = generation;
        PJMRuntimeRegistry.Kind kind = PJMRuntimeRegistry.currentKind();
        worker.execute(() -> {
            try {
                if (taskGeneration != generation) return;
                ensureRuntime(kind);
                Snapshot result = runtime == null ? Snapshot.EMPTY : compute(x, z);
                minecraft.execute(() -> {
                    if (taskGeneration == generation) snapshot = result;
                });
            } catch (Throwable ignored) {
                // Keep the previous valid snapshot. Individual layers are isolated in compute().
            } finally {
                minecraft.execute(() -> {
                    if (taskGeneration == generation) pending = false;
                });
            }
        });
    }

    public void reset() {
        generation++;
        snapshot = Snapshot.EMPTY;
        pending = false;
        lastX = Integer.MIN_VALUE;
        lastZ = Integer.MIN_VALUE;
        lastTick = Integer.MIN_VALUE;
    }

    /** Initializes PJ runtime + bundled geography on the existing background geography worker. */
    private void ensureRuntime(PJMRuntimeRegistry.Kind kind) throws IOException {
        if (runtime != null && runtimeKind == kind) return;
        runtime = null;
        external = null;
        fallbackPrefectures = List.of();
        runtimeKind = kind;
        if (kind == PJMRuntimeRegistry.Kind.NONE) return;
        PJMGeographicRuntime loaded = PJMRuntimeRegistry.open(kind);
        List<FallbackAnchor> anchors = resolveFallbackPrefectures(loaded);
        PJMExternalGeodata geography = new PJMExternalGeodata(loaded);
        runtime = loaded;
        external = geography;
        fallbackPrefectures = anchors;
    }

    private Snapshot compute(int x, int z) {
        String fallbackLocation = safeLayer(() -> fallbackPrefectureAt(x, z));

        String location = safeLayer(() -> {
            PJMExternalGeodata data = external;
            if (data == null || data.cityCount() <= 0) return fallbackLocation;
            String resolved = data.cityAt(x, z);
            return resolved == null || resolved.isBlank() ? fallbackLocation : resolved;
        });
        if (location.isBlank()) location = fallbackLocation;

        String marine = safeLayer(() -> nearbyMarine(x, z));
        String mountain = safeLayer(() -> {
            PJMExternalGeodata data = external;
            return data == null || data.mountainCount() <= 0 ? "" : data.mountainAt(x, z);
        });
        String hydro = safeLayer(() -> nearbyHydrology(x, z));
        String island = safeLayer(() -> {
            PJMExternalGeodata data = external;
            return data == null ? "" : data.famousIslandAt(x, z);
        });

        return new Snapshot(location, marine, mountain, hydro, island);
    }

    private static String safeLayer(Supplier<String> supplier) {
        try {
            String value = supplier.get();
            return value == null ? "" : value;
        } catch (Throwable ignored) {
            return "";
        }
    }

    private String fallbackPrefectureAt(int x, int z) {
        FallbackAnchor nearest = null;
        double best = Double.POSITIVE_INFINITY;
        for (FallbackAnchor anchor : fallbackPrefectures) {
            double d = Math.hypot(x - anchor.x, z - anchor.z);
            if (d < best) {
                best = d;
                nearest = anchor;
            }
        }
        return nearest == null ? "" : nearest.name;
    }

    private static List<FallbackAnchor> resolveFallbackPrefectures(PJMGeographicRuntime runtime) {
        List<FallbackAnchor> result = new ArrayList<>(PREFECTURE_FALLBACKS.size());
        for (FallbackGeo def : PREFECTURE_FALLBACKS) {
            result.add(new FallbackAnchor(
                    PJMPlaceNames.display(PJMPlaceNames.Kind.PREFECTURE, def.name),
                    runtime.worldXFromLongitude(def.longitude),
                    runtime.worldZFromLatitude(def.latitude)));
        }
        return List.copyOf(result);
    }

    private String nearbyMarine(int x, int z) {
        PJMExternalGeodata data = external;
        if (data == null || data.marineCount() <= 0) return "";

        if (runtime.lakeSample(x, z).water() || runtime.riverSample(x, z).water()) {
            return "";
        }

        PJMGeographicRuntime.TerrainPixel terrain = runtime.terrain(x, z);
        if (!terrain.land()) {
            return data.marineAt(x, z);
        }

        OceanPoint coast = nearestOceanPoint(x, z);
        if (coast == null) return "";

        String name = data.marineAt(coast.x, coast.z);
        if (name.isBlank()) return "";
        return coast.distance <= marineInlandDisplayDistance(name) ? name : "";
    }

    private OceanPoint nearestOceanPoint(int x, int z) {
        int maxRing = COAST_SEARCH_RADIUS / COAST_SEARCH_STEP;

        for (int ring = 1; ring <= maxRing; ring++) {
            int r = ring * COAST_SEARCH_STEP;
            OceanPoint best = null;
            double bestDistance = Double.POSITIVE_INFINITY;

            for (int i = -ring; i <= ring; i++) {
                int d = i * COAST_SEARCH_STEP;
                int[][] offsets = {
                        {d, -r}, {d, r}, {-r, d}, {r, d}
                };

                for (int[] offset : offsets) {
                    int sx = x + offset[0];
                    int sz = z + offset[1];

                    if (runtime.lakeSample(sx, sz).water()
                            || runtime.riverSample(sx, sz).water()) {
                        continue;
                    }
                    if (runtime.terrain(sx, sz).land()) continue;

                    double distance = Math.hypot(offset[0], offset[1]);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        best = new OceanPoint(sx, sz, distance);
                    }
                }
            }

            if (best != null) return best;
        }
        return null;
    }

    /**
     * River and lake are independent HUD categories: each category contributes at most its single
     * nearest named water body, and both categories may be visible at the same time.
     */
    private String nearbyHydrology(int x, int z) {
        String lake = findNearbyHydro(
                x, z, true, LAKE_SEARCH_RADIUS, LAKE_SEARCH_STEP);
        String river = findNearbyHydro(
                x, z, false, RIVER_SEARCH_RADIUS, RIVER_SEARCH_STEP);

        String lakeDisplay = lake.isBlank() ? "" : displayLakeName(lake);
        String riverDisplay = river.isBlank() ? "" : displayRiverName(river);
        if (lakeDisplay.isBlank()) return riverDisplay;
        if (riverDisplay.isBlank()) return lakeDisplay;
        return lakeDisplay + " · " + riverDisplay;
    }

    /** Returns the genuinely nearest named water sample inside the requested radius. */
    private String findNearbyHydro(int x, int z, boolean lake,
                                   int radius, int step) {
        PJMGeographicRuntime.NamedHydroSample direct = lake
                ? runtime.lakeSample(x, z)
                : runtime.riverSample(x, z);
        String directName = lake ? displayLakeName(direct.name()) : displayRiverName(direct.name());
        if (direct.named() && direct.water() && !directName.isBlank()) return directName;

        String bestName = "";
        double bestDistanceSq = Double.POSITIVE_INFINITY;
        int safeStep = Math.max(1, step);
        int radiusSq = radius * radius;

        for (int dz = -radius; dz <= radius; dz += safeStep) {
            for (int dx = -radius; dx <= radius; dx += safeStep) {
                if (dx == 0 && dz == 0) continue;
                int distanceSq = dx * dx + dz * dz;
                if (distanceSq > radiusSq || distanceSq >= bestDistanceSq) continue;

                PJMGeographicRuntime.NamedHydroSample sample = lake
                        ? runtime.lakeSample(x + dx, z + dz)
                        : runtime.riverSample(x + dx, z + dz);
                if (!sample.named() || !sample.water()) continue;

                String display = lake ? displayLakeName(sample.name()) : displayRiverName(sample.name());
                if (display.isBlank()) continue;
                bestDistanceSq = distanceSq;
                bestName = display;
            }
        }
        return bestName;
    }

    /**
     * Inland visibility for marine labels is deliberately smaller for narrow named passages.
     * The marine catalogue itself still decides which water area owns the sampled ocean point.
     */
    private static double marineInlandDisplayDistance(String name) {
        if (name.contains("海峡") || name.contains("水道") || name.contains("瀬戸")
                || name.contains("濑户")) return 60.0D;
        if (name.contains("湾") || name.endsWith("浦")) return 80.0D;
        if (name.contains("内海") || name.contains("灘")) return 100.0D;
        if (name.contains("海") || name.contains("洋")) return 120.0D;
        return 80.0D;
    }

    private static String displayLakeName(String raw) {
        return PJMPlaceNames.display(PJMPlaceNames.Kind.LAKE, raw);
    }
    private static String displayRiverName(String raw) {
        return PJMPlaceNames.display(PJMPlaceNames.Kind.RIVER, raw);
    }

    public record Snapshot(String location, String sea,
                           String mountain, String hydro, String island) {
        static final Snapshot EMPTY = new Snapshot("", "", "", "", "");

        public String locationSeaLine() {
            if (location.isBlank()) return sea;
            if (sea.isBlank()) return location;
            return location + " · " + sea;
        }

        public String mountainHydroLine() {
            if (mountain.isBlank()) return hydro;
            if (hydro.isBlank()) return mountain;
            return mountain + " · " + hydro;
        }
    }

    private record OceanPoint(int x, int z, double distance) {}
    private record FallbackAnchor(String name, int x, int z) {}
    private record FallbackGeo(String name, double longitude, double latitude) {}

    // Real prefectural-government coordinates used only as a no-network startup fallback. They are
    // independent from PJHUD and are replaced by the nationwide municipality layer when it loads.
    private static final List<FallbackGeo> PREFECTURE_FALLBACKS = List.of(
            new FallbackGeo("北海道", 141.3469, 43.0642),
            new FallbackGeo("青森县", 140.7400, 40.8244),
            new FallbackGeo("岩手县", 141.1527, 39.7036),
            new FallbackGeo("宫城县", 140.8721, 38.2688),
            new FallbackGeo("秋田县", 140.1024, 39.7186),
            new FallbackGeo("山形县", 140.3633, 38.2404),
            new FallbackGeo("福岛县", 140.4678, 37.7500),
            new FallbackGeo("茨城县", 140.4468, 36.3418),
            new FallbackGeo("栃木县", 139.8836, 36.5657),
            new FallbackGeo("群马县", 139.0608, 36.3911),
            new FallbackGeo("埼玉县", 139.6489, 35.8569),
            new FallbackGeo("千叶县", 140.1233, 35.6051),
            new FallbackGeo("东京都", 139.6917, 35.6895),
            new FallbackGeo("神奈川县", 139.6425, 35.4478),
            new FallbackGeo("新潟县", 139.0236, 37.9026),
            new FallbackGeo("富山县", 137.2113, 36.6953),
            new FallbackGeo("石川县", 136.6256, 36.5947),
            new FallbackGeo("福井县", 136.2216, 36.0652),
            new FallbackGeo("山梨县", 138.5684, 35.6642),
            new FallbackGeo("长野县", 138.1810, 36.6513),
            new FallbackGeo("岐阜县", 136.7223, 35.3912),
            new FallbackGeo("静冈县", 138.3831, 34.9769),
            new FallbackGeo("爱知县", 136.9066, 35.1802),
            new FallbackGeo("三重县", 136.5086, 34.7303),
            new FallbackGeo("滋贺县", 135.8686, 35.0045),
            new FallbackGeo("京都府", 135.7556, 35.0212),
            new FallbackGeo("大阪府", 135.5200, 34.6863),
            new FallbackGeo("兵库县", 135.1830, 34.6913),
            new FallbackGeo("奈良县", 135.8327, 34.6853),
            new FallbackGeo("和歌山县", 135.1675, 34.2260),
            new FallbackGeo("鸟取县", 134.2377, 35.5039),
            new FallbackGeo("岛根县", 133.0505, 35.4723),
            new FallbackGeo("冈山县", 133.9350, 34.6618),
            new FallbackGeo("广岛县", 132.4596, 34.3963),
            new FallbackGeo("山口县", 131.4705, 34.1861),
            new FallbackGeo("德岛县", 134.5593, 34.0658),
            new FallbackGeo("香川县", 134.0434, 34.3401),
            new FallbackGeo("爱媛县", 132.7657, 33.8416),
            new FallbackGeo("高知县", 133.5311, 33.5597),
            new FallbackGeo("福冈县", 130.4183, 33.6064),
            new FallbackGeo("佐贺县", 130.2988, 33.2494),
            new FallbackGeo("长崎县", 129.8737, 32.7448),
            new FallbackGeo("熊本县", 130.7417, 32.7898),
            new FallbackGeo("大分县", 131.6126, 33.2382),
            new FallbackGeo("宫崎县", 131.4239, 31.9111),
            new FallbackGeo("鹿儿岛县", 130.5581, 31.5602),
            new FallbackGeo("冲绳县", 127.6809, 26.2124));

}
