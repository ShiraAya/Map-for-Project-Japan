package com.sora.pjm.map;

import net.minecraftforge.fml.ModList;

import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/** PJR adapter. Reuses the loaded engine, surveyed water footprints and solved river network. */
final class PJMProjectJapanRefinedRuntime implements PJMGeographicRuntime {
    private static final int RIVER_GRID = 2048, LAKE_GRID = 2048;
    private final MethodHandle geoX, geoZ, geoLon, geoLat;
    private final MethodHandle sampleTerrain, terrainLand, terrainMetres, terrainCoverage;
    private final MethodHandle sampleHydrology, contextWater, waterKind, waterOwner;
    private final MethodHandle tidalChannel, channelAuthority;
    private final MethodHandle polygonDistance, polygonWetBlock;
    private final Map<Long, List<LakeView>> lakeGrid = new HashMap<>();
    private final Map<Long, List<RiverVectorSegment>> riverGrid = new HashMap<>();
    private final List<RiverVectorSegment> rivers;
    private static final class LastSample { int x, z; TerrainPixel terrain; Object water; }
    private final ThreadLocal<LastSample> lastSample = ThreadLocal.withInitial(LastSample::new);
    private final String version, fingerprint;
    private final double footprintScale;
    private final int minX, maxX, minZ, maxZ;

    PJMProjectJapanRefinedRuntime() throws ReflectiveOperationException, IOException {
        this(Class.forName("com.sora.pjr.forge.WorldRuntime").getMethod("engine").invoke(null),
                ModList.get().getModContainerById("pjr")
                        .map(c -> c.getModInfo().getVersion().toString()).orElse("unknown"));
    }

    /** Also permits integration checks against an engine compiled from the supplied PJR source. */
    PJMProjectJapanRefinedRuntime(Object engine, String version)
            throws ReflectiveOperationException, IOException {
        this.version = version;
        Class<?> geo = Class.forName("com.sora.pjr.core.Geo");
        geoX = method(geo, "x", double.class);
        geoZ = method(geo, "z", double.class);
        geoLon = method(geo, "lon", double.class);
        geoLat = method(geo, "lat", double.class);
        footprintScale = 8.0D / geo.getField("METRES_XZ").getDouble(null);
        minX = (int)Math.floor(project(geoX, 122));
        maxX = (int)Math.ceil(project(geoX, 154));
        minZ = (int)Math.floor(project(geoZ, 46));
        maxZ = (int)Math.ceil(project(geoZ, 20));

        Object hydrology = engine.getClass().getMethod("hydrology").invoke(engine);
        Class<?> hydroClass = hydrology.getClass();
        // Current PJR exposes its shared terrain publicly. Retain the field fallback only
        // for older PJR 0.1.1; never allocate a duplicate national terrain model.
        Object terrain;
        try {
            terrain = hydroClass.getMethod("terrain").invoke(hydrology);
        } catch (NoSuchMethodException oldPjr) {
            Field terrainField = hydroClass.getDeclaredField("terrain");
            terrainField.setAccessible(true);
            terrain = terrainField.get(hydrology);
        }
        Class<?> terrainApi = Class.forName("com.sora.pjr.core.Terrain");
        sampleTerrain = method(terrainApi, "sample", int.class, int.class).bindTo(terrain);
        tidalChannel = optionalMethod(terrainApi, "tidalChannel", terrain);
        channelAuthority = optionalMethod(terrainApi, "channelAuthority", terrain);
        Class<?> sample = Class.forName("com.sora.pjr.core.Terrain$Sample");
        terrainLand = method(sample, "land");
        terrainMetres = method(sample, "metres");
        terrainCoverage = method(sample, "coverage");

        sampleHydrology = method(hydroClass, "sample", int.class, int.class).bindTo(hydrology);
        contextWater = method(Class.forName("com.sora.pjr.core.Hydrology$Context"), "water");
        Class<?> water = Class.forName("com.sora.pjr.core.Hydrology$Water");
        waterKind = method(water, "kind");
        waterOwner = method(water, "owner");

        Object data = hydroClass.getMethod("data").invoke(hydrology);
        Class<?> polygon = Class.forName("com.sora.pjr.core.Polygon");
        polygonDistance = method(polygon, "distance", double.class, double.class);
        polygonWetBlock = method(polygon, "wetBlock", int.class, int.class, double.class);
        List<?> lakes = (List<?>)data.getClass().getMethod("lakes").invoke(data);
        for (Object lake : lakes) {
            Object shape = lake.getClass().getMethod("polygon").invoke(lake);
            Object bounds = polygon.getMethod("bounds").invoke(shape);
            LakeView view = new LakeView(
                    (String)lake.getClass().getMethod("id").invoke(lake),
                    (String)lake.getClass().getMethod("name").invoke(lake), shape,
                    number(bounds, "minX") - 1, number(bounds, "maxX") + 1,
                    number(bounds, "minZ") - 1, number(bounds, "maxZ") + 1);
            index(lakeGrid, view, view.minX, view.maxX, view.minZ, view.maxZ, LAKE_GRID);
        }
        // Hydrology resolves overlapping lakes by ID, not feature insertion order.
        lakeGrid.values().forEach(cell -> cell.sort(Comparator.comparing(LakeView::id)));

        List<RiverVectorSegment> segments = new ArrayList<>();
        for (Object river : (List<?>)data.getClass().getMethod("rivers").invoke(data)) {
            for (Object segment : (List<?>)river.getClass().getMethod("segments").invoke(river)) {
                Object a = segment.getClass().getMethod("a").invoke(segment);
                Object b = segment.getClass().getMethod("b").invoke(segment);
                double ax = number(a, "x"), az = number(a, "z");
                double bx = number(b, "x"), bz = number(b, "z");
                // Public Point.width is already in the active world's blocks. The 1.5 total
                // raster allowance matches Hydrology.radius(hit) = width / 2 + 0.75.
                double wa = number(a, "width"), wb = number(b, "width");
                double width = (wa + wb) * 0.5 + 1.5;
                double radius = Math.max(wa, wb) * 0.5 + 2;
                RiverVectorSegment view = new RiverVectorSegment(ax, az, bx, bz, width,
                        Math.min(ax, bx) - radius, Math.max(ax, bx) + radius,
                        Math.min(az, bz) - radius, Math.max(az, bz) + radius);
                segments.add(view);
                index(riverGrid, view, view.minX(), view.maxX(), view.minZ(), view.maxZ(), RIVER_GRID);
            }
        }
        rivers = List.copyOf(segments);
        if (rivers.isEmpty()) throw new IOException("PJR exposed no solved river segments");
        fingerprint = fingerprint(geo);
    }

    private static MethodHandle method(Class<?> owner, String name, Class<?>... args)
            throws ReflectiveOperationException {
        return MethodHandles.publicLookup().unreflect(owner.getMethod(name, args));
    }

    private static double number(Object owner, String name) throws ReflectiveOperationException {
        return ((Number)owner.getClass().getMethod(name).invoke(owner)).doubleValue();
    }

    private static MethodHandle optionalMethod(Class<?> owner, String name, Object receiver)
            throws ReflectiveOperationException {
        try { return method(owner, name, int.class, int.class).bindTo(receiver); }
        catch (NoSuchMethodException oldPjr) { return null; }
    }

    private static double project(MethodHandle method, double value) {
        try { return (double)method.invoke(value); }
        catch (Throwable t) { throw failed("projection", t); }
    }

    public String modId() { return "pjr"; }
    public String displayName() { return "ProjectJapanRefined"; }
    public String version() { return version; }
    public String fingerprint() { return fingerprint; }
    public int minWorldX() { return minX; }
    public int maxWorldX() { return maxX; }
    public int minWorldZ() { return minZ; }
    public int maxWorldZ() { return maxZ; }
    public double footprintScale() { return footprintScale; }
    public boolean exactLocalRivers() { return true; }
    public int worldXFromLongitude(double longitude) { return (int)Math.round(project(geoX, longitude)); }
    public int worldZFromLatitude(double latitude) { return (int)Math.round(project(geoZ, latitude)); }
    public double longitudeFromWorldX(double x) { return project(geoLon, x); }
    public double latitudeFromWorldZ(double z) { return project(geoLat, z); }

    public TerrainPixel terrain(int x, int z) {
        try {
            LastSample last = sampleSlot(x, z);
            if (last.terrain == null) {
                Object sample = sampleTerrain.invoke(x, z);
                last.terrain = new TerrainPixel((boolean)terrainLand.invoke(sample),
                        (int)Math.round((double)terrainMetres.invoke(sample)),
                        (double)terrainCoverage.invoke(sample));
            }
            return last.terrain;
        } catch (Throwable t) { throw failed("terrain", t); }
    }

    public VisualTerrain visualTerrain(double u, double v) {
        TerrainPixel t = terrain((int)Math.floor(minX + u * (maxX - minX)),
                (int)Math.floor(minZ + v * (maxZ - minZ)));
        return new VisualTerrain(t.land(), t.elevationMetres(), t.coverage());
    }

    public boolean lakeWater(int x, int z) { return wetLake(x, z) != null; }

    public NamedHydroSample lakeSample(int x, int z) {
        LakeView lake = wetLake(x, z);
        return lake == null ? NamedHydroSample.EMPTY : new NamedHydroSample(true, true, lake.name);
    }

    private LakeView wetLake(int x, int z) {
        List<LakeView> candidates = lakeGrid.get(key(Math.floorDiv(x, LAKE_GRID), Math.floorDiv(z, LAKE_GRID)));
        if (candidates == null) return null;
        try {
            for (LakeView lake : candidates) {
                if (x + 0.5 < lake.minX || x + 0.5 > lake.maxX || z + 0.5 < lake.minZ || z + 0.5 > lake.maxZ) continue;
                double distance = (double)polygonDistance.invoke(lake.polygon, x + 0.5, z + 0.5);
                if ((boolean)polygonWetBlock.invoke(lake.polygon, x, z, distance)) return lake;
            }
            return null;
        } catch (Throwable t) { throw failed("lake shoreline", t); }
    }

    public boolean riverWater(int x, int z) { return riverSample(x, z).water(); }

    public NamedHydroSample riverSample(int x, int z) {
        // Surveyed canals and wide lower reaches need not have a W05 centre-line nearby.
        // They must bypass the centre-line bounding-box optimization.
        try {
            if (tidalChannel != null && (boolean)tidalChannel.invoke(x, z))
                return exactRiverSample(x, z);
        } catch (Throwable t) { throw failed("surveyed river footprint", t); }
        // Reject empty river grid cells before calling the full hydrology engine.
        List<RiverVectorSegment> candidates = riverGrid.get(key(Math.floorDiv(x, RIVER_GRID), Math.floorDiv(z, RIVER_GRID)));
        if (candidates == null) return NamedHydroSample.EMPTY;
        boolean possible = false;
        for (RiverVectorSegment s : candidates) {
            if (x + 0.5 >= s.minX() && x + 0.5 <= s.maxX() && z + 0.5 >= s.minZ() && z + 0.5 <= s.maxZ()) {
                possible = true;
                break;
            }
        }
        if (!possible) return NamedHydroSample.EMPTY;
        return exactRiverSample(x, z);
    }

    private NamedHydroSample exactRiverSample(int x, int z) {
        try {
            Object water = waterAt(x, z);
            if (!"RIVER".equals(((Enum<?>)waterKind.invoke(water)).name())) return NamedHydroSample.EMPTY;
            String owner = (String)waterOwner.invoke(water);
            return new NamedHydroSample(true, true, owner.startsWith("tidal:") ? "" : owner);
        } catch (Throwable t) { throw failed("river water", t); }
    }

    public SurveyWater surveyedWater(int x, int z) {
        if (channelAuthority == null) return SurveyWater.UNMAPPED;
        try {
            if ((double)channelAuthority.invoke(x, z) <= 0) return SurveyWater.UNMAPPED;
            Object water = waterAt(x, z);
            return SurveyWater.valueOf(((Enum<?>)waterKind.invoke(water)).name());
        } catch (Throwable t) { throw failed("surveyed water classification", t); }
    }

    private LastSample sampleSlot(int x, int z) {
        LastSample last = lastSample.get();
        if (last.x != x || last.z != z) { last.x = x; last.z = z; last.terrain = null; last.water = null; }
        return last;
    }

    private Object waterAt(int x, int z) throws Throwable {
        LastSample last = sampleSlot(x, z);
        if (last.water == null) last.water = contextWater.invoke(sampleHydrology.invoke(x, z));
        return last.water;
    }

    public boolean vectorRiversAvailable() { return !rivers.isEmpty(); }

    public List<RiverVectorSegment> riverSegments(double minX, double minZ, double maxX, double maxZ) {
        Set<RiverVectorSegment> result = new LinkedHashSet<>();
        for (int z = cell(minZ, RIVER_GRID); z <= cell(maxZ, RIVER_GRID); z++) {
            for (int x = cell(minX, RIVER_GRID); x <= cell(maxX, RIVER_GRID); x++) {
                List<RiverVectorSegment> candidates = riverGrid.get(key(x, z));
                if (candidates == null) continue;
                for (RiverVectorSegment s : candidates)
                    if (s.maxX() >= minX && s.minX() <= maxX && s.maxZ() >= minZ && s.minZ() <= maxZ)
                        result.add(s);
            }
        }
        return new ArrayList<>(result);
    }

    private static <T> void index(Map<Long, List<T>> grid, T value, double minX, double maxX,
                                  double minZ, double maxZ, int size) {
        for (int z = cell(minZ, size); z <= cell(maxZ, size); z++)
            for (int x = cell(minX, size); x <= cell(maxX, size); x++)
                grid.computeIfAbsent(key(x, z), ignored -> new ArrayList<>()).add(value);
    }

    private static int cell(double value, int size) { return (int)Math.floor(value / size); }
    private static long key(int x, int z) {
        long value = ((long)x << 32) ^ (z & 0xffffffffL);
        value = (value ^ value >>> 30) * 0xbf58476d1ce4e5b9L;
        value = (value ^ value >>> 27) * 0x94d049bb133111ebL;
        return value ^ value >>> 31;
    }

    private String fingerprint(Class<?> anchor) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // Display versions are not map inputs. Hash actual code/data instead.
            digest.update(("pjr-map-inputs-v4:" + minX + ":" + maxX + ":" + minZ
                    + ":" + maxZ + ":" + footprintScale).getBytes(StandardCharsets.UTF_8));
            String[] paths = {
                    "/com/sora/pjr/core/Geo.class", "/com/sora/pjr/core/RasterTerrain.class",
                    "/com/sora/pjr/core/Hydrology.class", "/com/sora/pjr/core/WorldData.class",
                    "/com/sora/pjr/core/WorldData$Builder.class", "/com/sora/pjr/core/HydraulicSolver.class",
                    "/com/sora/pjr/core/RawGeography.class", "/com/sora/pjr/core/RouteMath.class",
                    "/com/sora/pjr/core/River.class", "/com/sora/pjr/core/River$Segment.class",
                    "/com/sora/pjr/core/Lake.class", "/com/sora/pjr/core/Polygon.class",
                    "/com/sora/pjr/core/Polygon$Ring.class",
                    "/assets/pjr/terrain/japan_height.png", "/assets/pjr/terrain/japan_land_hd.png",
                    "/assets/pjr/world/geography.pjrg.gz"
            };
            for (String path : paths) {
                digest.update(path.getBytes(StandardCharsets.UTF_8));
                try (InputStream in = anchor.getResourceAsStream(path)) {
                    if (in == null) throw new IOException("Missing PJR fingerprint resource: " + path);
                    if (path.equals("/com/sora/pjr/core/Hydrology.class")) {
                        digest.update(mapHydrologyDigest(in.readAllBytes()));
                        continue;
                    }
                    byte[] buffer = new byte[65536];
                    int count;
                    while ((count = in.read(buffer)) != -1) digest.update(buffer, 0, count);
                }
            }
            // Optional resources retain compatibility with PJR 0.1.1. Their presence and bytes
            // invalidate coastal tiles even when a local rebuild keeps the same mod version.
            String[] coastalPaths = {
                    "/com/sora/pjr/core/CoastalRegions.class", "/com/sora/pjr/core/CoastalRegions$Region.class",
                    "/com/sora/pjr/core/RiverWidths.class", "/com/sora/pjr/core/LakeLevels.class",
                    "/com/sora/pjr/core/LocalElevation.class", "/com/sora/pjr/core/Coastline.class",
                    "/assets/pjr/terrain/japan_land_ocean.png", "/assets/pjr/terrain/coast.pjrc.gz",
                    "/assets/pjr/terrain/tokyo-bay.pjrt.gz", "/assets/pjr/terrain/tokyo-bay-outer.pjrt.gz",
                    "/assets/pjr/terrain/iturup.pjrt.gz", "/assets/pjr/terrain/shikotan-habomai.pjrt.gz",
                    "/assets/pjr/terrain/sameura-dem.pjrd.gz",
                    "/assets/pjr/world/river-shapes.properties", "/assets/pjr/world/lake-references.properties"
            };
            for (String path : coastalPaths) {
                digest.update(path.getBytes(StandardCharsets.UTF_8));
                try (InputStream in = anchor.getResourceAsStream(path)) {
                    digest.update((byte)(in == null ? 0 : 1));
                    if (in != null) {
                        byte[] buffer = new byte[65536];int count;
                        while ((count = in.read(buffer)) != -1) digest.update(buffer, 0, count);
                    }
                }
            }
            // Newer PJR versions put precision data in offline atlases. Their bytes, not
            // just the mod version, must invalidate both local and bundled map caches.
            for (String name : List.of("PrecisionTerrain", "TiledRaster", "PackedAtlas", "CoastTileCodec",
                    "CompactDemCodec", "PrecomputedHydrology", "RiverShapes", "LakeDepths",
                    "SpatialIndex", "Box", "Terrain", "Terrain$Sample", "Hydrology$Kind",
                    "Hydrology$Water", "Hydrology$Context", "Hydrology$Shore"))
                digestResource(anchor, digest, "/com/sora/pjr/core/" + name + ".class");
            digestResource(anchor, digest, "/assets/pjr/world/hydraulic-startup.bin.gz");
            for (String folder : List.of("dem-atlas", "urban-coast")) digestAtlas(anchor, digest, folder);
            return HexFormat.of().formatHex(digest.digest()).substring(0, 20);
        } catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    /** Explicitly audited map-equivalent binaries, NOT a blanket exemption for hydrology.
     * PJR 0.1.21 -> 0.1.22 changes bankGround only; PJM never calls it. All map-used
     * methods and other core classes/assets are identical (see cache validation report).
     * Any unknown build, including a future water-ownership edit, retains its own hash.
     */
    static byte[] mapHydrologyDigest(byte[] bytecode) throws NoSuchAlgorithmException {
        byte[] actual = MessageDigest.getInstance("SHA-256").digest(bytecode);
        String hash = HexFormat.of().formatHex(actual);
        if (hash.equals("68efe71e5dee91f1eee7e8d3b73a9579506f233df9dba8a1d9729779674fccaf")
                || hash.equals("f53050c89ed50b9fd9fbb8206121c7642cca72ffeff373253a0ba50af9210eeb"))
            return HexFormat.of().parseHex("68efe71e5dee91f1eee7e8d3b73a9579506f233df9dba8a1d9729779674fccaf");
        return actual;
    }

    private static void digestResource(Class<?> anchor, MessageDigest digest, String path) throws IOException {
        digest.update(path.getBytes(StandardCharsets.UTF_8));
        try (InputStream in = anchor.getResourceAsStream(path)) {
            digest.update((byte)(in == null ? 0 : 1));
            if (in != null) {
                byte[] buffer = new byte[65536]; int count;
                while ((count = in.read(buffer)) != -1) digest.update(buffer, 0, count);
            }
        }
    }

    private static void digestAtlas(Class<?> anchor, MessageDigest digest, String folder) throws IOException {
        String root = "/assets/pjr/terrain/" + folder + "/";
        for (String name : List.of("format.properties", "regions.tsv", "index.tsv"))
            digestResource(anchor, digest, root + name);
        Properties format = new Properties();
        try (InputStream in = anchor.getResourceAsStream(root + "format.properties")) {
            if (in != null) format.load(in);
        }
        Set<String> paths = new TreeSet<>();
        try (InputStream raw = anchor.getResourceAsStream(root + "index.tsv")) {
            if (raw == null) return; // PJR 0.1.1–0.1.14
            try (BufferedReader in = new BufferedReader(new InputStreamReader(raw, StandardCharsets.UTF_8))) {
                for (String line; (line = in.readLine()) != null;) {
                    if (line.isBlank() || line.startsWith("#")) continue;
                    String[] f = line.split("\\t");
                    int z = f.length == 3 ? Integer.parseInt(f[0]) : 14;
                    int x = Integer.parseInt(f[f.length - 2]), y = Integer.parseInt(f[f.length - 1]);
                    String file = "4".equals(format.getProperty("packSize"))
                            ? "packs/" + z + "-" + (x >> 2) + "-" + (y >> 2) + ".pck"
                            : (folder.equals("dem-atlas") ? z + "-" : "") + x + "-" + y + ".bin.gz";
                    paths.add(root + file);
                }
            }
        }
        for (String path : paths) digestResource(anchor, digest, path);
    }

    private static RuntimeException failed(String operation, Throwable cause) {
        return new IllegalStateException("PJR " + operation + " sampling failed", cause);
    }

    private record LakeView(String id, String name, Object polygon,
                            double minX, double maxX, double minZ, double maxZ) {}
}
