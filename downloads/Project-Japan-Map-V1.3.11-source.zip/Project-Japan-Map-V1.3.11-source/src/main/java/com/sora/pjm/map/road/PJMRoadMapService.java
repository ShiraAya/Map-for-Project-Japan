package com.sora.pjm.map.road;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Client-side CityBuild road sampler and persistent cache coordinator.
 *
 * <p>V1.3 replaces the old one-chunk-per-tick / 10-second nearby refresh with a bounded priority
 * scheduler. The current chunk and immediate neighbours are rescanned frequently, explicit client
 * block updates are promoted to the urgent queue, and the loop is capped by both a chunk count and
 * a short time budget. This keeps newly built roads responsive without allowing map maintenance to
 * monopolise the render/client thread.</p>
 *
 * <p>Only already-loaded client chunks are sampled. PJM never asks Minecraft to load or generate a
 * chunk for the road map.</p>
 */
public final class PJMRoadMapService {
    public static final PJMRoadMapService INSTANCE = new PJMRoadMapService();

    private static final int SCAN_RADIUS_CHUNKS = 6;
    private static final int MAX_SCANS_PER_TICK = 6;
    private static final long SCAN_BUDGET_NS = 2_500_000L;
    private static final int ROAD_SEARCH_DEPTH = 12;
    private static final int MAX_CHANGE_HISTORY = 4096;

    private final ArrayDeque<Long> urgentQueue = new ArrayDeque<>();
    private final ArrayDeque<Long> normalQueue = new ArrayDeque<>();
    private final Set<Long> urgentQueued = new HashSet<>();
    private final Set<Long> normalQueued = new HashSet<>();
    private final Map<Long, Integer> lastScannedTick = new HashMap<>();
    private final ArrayDeque<RoadChange> changeHistory = new ArrayDeque<>();

    private PJMRoadRegionStore store;
    private ClientLevel currentLevel;
    private String currentWorldKey;
    private int ticks;
    private long revision = 1L;
    private boolean cityBuildLoaded;
    private boolean cityBuildChecked;

    private PJMRoadMapService() {
    }

    public synchronized void tick(Minecraft minecraft) {
        if (minecraft.player == null || minecraft.level == null) {
            reset();
            return;
        }

        ensureWorld(minecraft);
        if (!cityBuildLoaded || store == null) return;
        if (!minecraft.level.dimension().equals(Level.OVERWORLD)) return;

        ticks++;
        if (ticks == 1 || ticks % 5 == 0) {
            enqueueNearby(minecraft);
        }

        long start = System.nanoTime();
        int scans = 0;
        while (scans < MAX_SCANS_PER_TICK) {
            Long packed = pollNext();
            if (packed == null) break;
            scanLoadedChunk(minecraft.level, unpackX(packed), unpackZ(packed));
            scans++;
            if (scans > 0 && System.nanoTime() - start >= SCAN_BUDGET_NS) break;
        }
    }

    public synchronized void ensureWorld(Minecraft minecraft) {
        if (!cityBuildChecked) {
            cityBuildLoaded = ModList.get().isLoaded("citybuild");
            cityBuildChecked = true;
        }
        if (!cityBuildLoaded || minecraft.level == null) return;
        if (minecraft.level == currentLevel && store != null) return;

        String worldName = worldName(minecraft);
        ResourceKey<Level> dimension = minecraft.level.dimension();
        String key = worldName + "|" + dimension.location();
        if (key.equals(currentWorldKey) && store != null) {
            currentLevel = minecraft.level;
            return;
        }

        closeStore();
        currentLevel = minecraft.level;
        currentWorldKey = key;
        ticks = 0;
        clearQueues();
        lastScannedTick.clear();
        changeHistory.clear();

        String folder = sanitize(worldName);
        String dimensionFolder = sanitize(dimension.location().toString());
        Path root = FMLPaths.GAMEDIR.get()
                .resolve("PJM")
                .resolve("cache")
                .resolve(folder)
                .resolve("roads")
                .resolve(dimensionFolder);
        try {
            store = new PJMRoadRegionStore(root);
            revision++;
        } catch (IOException e) {
            store = null;
        }
    }

    /** Promotes the affected road chunk for re-sampling on the next client ticks. */
    public synchronized void markDirty(BlockPos pos) {
        if (pos == null) return;
        markChunkDirty(pos.getX() >> 4, pos.getZ() >> 4);
    }

    public synchronized void markChunkDirty(int chunkX, int chunkZ) {
        long key = pack(chunkX, chunkZ);
        lastScannedTick.remove(key);
        enqueue(chunkX, chunkZ, true);
    }

    public synchronized void markChunkLoaded(int chunkX, int chunkZ) {
        boolean cached = store != null && store.hasChunk(chunkX, chunkZ);
        enqueue(chunkX, chunkZ, !cached);
    }

    public synchronized boolean available() {
        return cityBuildLoaded && store != null;
    }

    public synchronized long revision() {
        return revision;
    }

    /** Returns changed road chunks since a renderer's last seen revision. */
    public synchronized ChangeBatch changesSince(long seenRevision) {
        if (seenRevision == revision) {
            return new ChangeBatch(false, List.of(), revision);
        }
        if (changeHistory.isEmpty()) {
            return new ChangeBatch(true, List.of(), revision);
        }

        long oldest = changeHistory.peekFirst().revision();
        if (seenRevision < oldest - 1L) {
            return new ChangeBatch(true, List.of(), revision);
        }

        List<RoadChange> changes = new ArrayList<>();
        for (RoadChange change : changeHistory) {
            if (change.revision() > seenRevision) changes.add(change);
        }
        return new ChangeBatch(false, changes, revision);
    }

    synchronized PJMRoadRegionStore store() {
        return store;
    }

    public synchronized void reset() {
        if (store == null && currentWorldKey == null && urgentQueue.isEmpty() && normalQueue.isEmpty()
                && urgentQueued.isEmpty() && normalQueued.isEmpty() && lastScannedTick.isEmpty()) {
            return;
        }
        closeStore();
        currentLevel = null;
        currentWorldKey = null;
        ticks = 0;
        clearQueues();
        lastScannedTick.clear();
        changeHistory.clear();
        revision++;
    }

    private void enqueueNearby(Minecraft minecraft) {
        if (minecraft.player == null || minecraft.level == null) return;
        int centerX = minecraft.player.chunkPosition().x;
        int centerZ = minecraft.player.chunkPosition().z;

        for (int radius = 0; radius <= SCAN_RADIUS_CHUNKS; radius++) {
            int interval = refreshInterval(radius);
            boolean urgent = radius <= 1;
            if (radius == 0) {
                enqueueIfDue(centerX, centerZ, interval, true);
                continue;
            }
            for (int dx = -radius; dx <= radius; dx++) {
                enqueueIfDue(centerX + dx, centerZ - radius, interval, urgent);
                enqueueIfDue(centerX + dx, centerZ + radius, interval, urgent);
            }
            for (int dz = -radius + 1; dz <= radius - 1; dz++) {
                enqueueIfDue(centerX - radius, centerZ + dz, interval, urgent);
                enqueueIfDue(centerX + radius, centerZ + dz, interval, urgent);
            }
        }
    }

    private static int refreshInterval(int radius) {
        if (radius == 0) return 5;      // 0.25 s at 20 TPS
        if (radius <= 1) return 10;     // 0.5 s
        if (radius <= 2) return 20;     // 1 s
        if (radius <= 3) return 40;     // 2 s
        if (radius <= 4) return 80;     // 4 s
        return 120;                     // 6 s at the edge
    }

    private void enqueueIfDue(int chunkX, int chunkZ, int interval, boolean urgent) {
        long key = pack(chunkX, chunkZ);
        Integer last = lastScannedTick.get(key);
        if (last != null && ticks - last < interval) return;

        boolean cached = store != null && store.hasChunk(chunkX, chunkZ);
        enqueue(chunkX, chunkZ, urgent || !cached);
    }

    private void enqueue(int chunkX, int chunkZ, boolean urgent) {
        long key = pack(chunkX, chunkZ);
        if (urgent) {
            if (urgentQueued.contains(key)) return;
            if (normalQueued.remove(key)) normalQueue.remove(key);
            urgentQueued.add(key);
            urgentQueue.addLast(key);
        } else {
            if (urgentQueued.contains(key) || normalQueued.contains(key)) return;
            normalQueued.add(key);
            normalQueue.addLast(key);
        }
    }

    private Long pollNext() {
        Long key = urgentQueue.pollFirst();
        if (key != null) {
            urgentQueued.remove(key);
            return key;
        }
        key = normalQueue.pollFirst();
        if (key != null) normalQueued.remove(key);
        return key;
    }

    private void scanLoadedChunk(ClientLevel level, int chunkX, int chunkZ) {
        LevelChunk chunk = level.getChunkSource().getChunkNow(chunkX, chunkZ);
        if (chunk == null) return;

        long[] roadMask = new long[4];
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int localZ = 0; localZ < 16; localZ++) {
            int worldZ = (chunkZ << 4) + localZ;
            for (int localX = 0; localX < 16; localX++) {
                int worldX = (chunkX << 4) + localX;
                int top = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, localX, localZ);
                int startY = Math.min(level.getMaxBuildHeight() - 1, top + 1);
                int endY = Math.max(level.getMinBuildHeight(), startY - ROAD_SEARCH_DEPTH);

                boolean road = false;
                for (int y = startY; y >= endY; y--) {
                    pos.set(worldX, y, worldZ);
                    if (PJMRoadBlockClassifier.isRoadSurface(chunk.getBlockState(pos))) {
                        road = true;
                        break;
                    }
                }

                if (road) {
                    int bit = localZ * 16 + localX;
                    roadMask[bit >>> 6] |= 1L << (bit & 63);
                }
            }
        }

        lastScannedTick.put(pack(chunkX, chunkZ), ticks);
        if (store != null && store.putChunk(chunkX, chunkZ, roadMask)) {
            revision++;
            changeHistory.addLast(new RoadChange(revision, chunkX, chunkZ));
            while (changeHistory.size() > MAX_CHANGE_HISTORY) changeHistory.removeFirst();
        }
    }

    private void closeStore() {
        if (store != null) {
            store.close();
            store = null;
        }
    }

    private void clearQueues() {
        urgentQueue.clear();
        normalQueue.clear();
        urgentQueued.clear();
        normalQueued.clear();
    }

    private static String worldName(Minecraft minecraft) {
        if (minecraft.getSingleplayerServer() != null) {
            try {
                Path saveRoot = minecraft.getSingleplayerServer()
                        .getWorldPath(LevelResource.ROOT)
                        .toAbsolutePath().normalize();
                Path folder = saveRoot.getFileName();
                if (folder != null && !folder.toString().isBlank()) return folder.toString();
            } catch (RuntimeException ignored) {
            }
            return minecraft.getSingleplayerServer().getWorldData().getLevelName();
        }
        ServerData server = minecraft.getCurrentServer();
        if (server != null && server.ip != null && !server.ip.isBlank()) {
            return "server-" + server.ip;
        }
        return "world";
    }

    private static String sanitize(String value) {
        String result = value.replaceAll("[<>:\"/\\\\|?*]", "_").trim();
        while (result.endsWith(".") || result.endsWith(" ")) {
            result = result.substring(0, result.length() - 1);
        }
        return result.isBlank() ? "world" : result;
    }

    private static long pack(int x, int z) {
        return ((long)x << 32) ^ (z & 0xffffffffL);
    }

    private static int unpackX(long key) {
        return (int)(key >> 32);
    }

    private static int unpackZ(long key) {
        return (int)key;
    }

    public record RoadChange(long revision, int chunkX, int chunkZ) {
    }

    public record ChangeBatch(boolean fullRefresh, List<RoadChange> changes, long latestRevision) {
    }
}
