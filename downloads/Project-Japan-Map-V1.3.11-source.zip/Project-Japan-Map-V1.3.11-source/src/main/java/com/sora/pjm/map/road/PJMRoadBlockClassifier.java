package com.sora.pjm.map.road;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Identifies CityBuild blocks that represent the drivable road surface itself.
 *
 * <p>PJM intentionally does not depend on CityBuild at compile time. Registry IDs are used so the
 * road layer remains optional and does not pull signs, guard rails, lamps or other street furniture
 * into the map.</p>
 */
final class PJMRoadBlockClassifier {
    private static final String CITYBUILD_NAMESPACE = "citybuild";

    private PJMRoadBlockClassifier() {
    }

    static boolean isRoadSurface(BlockState state) {
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        if (id == null || !CITYBUILD_NAMESPACE.equals(id.getNamespace())) {
            return false;
        }

        String path = id.getPath();
        return path.equals("asphalt_road")
                || path.equals("asphalt_road_slab")
                || path.equals("white_asphalt_road")
                || path.equals("white_asphalt_road_slab")
                || path.equals("yellow_asphalt_road")
                || path.equals("yellow_asphalt_road_slab")
                || path.startsWith("white_line_")
                || path.startsWith("yellow_line_")
                || path.startsWith("white_yellow_line_")
                || path.startsWith("white_arrow_");
    }
}
