package com.sora.pjm.world;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Integrated-server terrain helper used when PJM creates a waypoint in single-player.
 *
 * <p>Multiplayer teleporting does not use this class. PJM sends the vanilla {@code /tp} command
 * through the normal client connection, so a remote server does not need PJM installed.</p>
 */
public final class PJMTeleportService {
    private PJMTeleportService() {
    }

    /** Finds the highest genuinely standable feet-Y in this world column. */
    public static int findSafeFeetY(ServerLevel level, int x, int z) {
        int minFeetY = level.getMinBuildHeight() + 1;
        int maxFeetY = level.getMaxBuildHeight() - 2;

        for (int feetY = maxFeetY; feetY >= minFeetY; feetY--) {
            if (canStand(level, x, feetY, z)) {
                return feetY;
            }
        }

        int surface = Mth.clamp(
                level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z),
                minFeetY, maxFeetY);
        for (int feetY = surface;
             feetY <= Math.min(maxFeetY, surface + 64);
             feetY++) {
            if (isBodySpaceClear(level, x, feetY, z)) {
                return feetY;
            }
        }

        return maxFeetY;
    }

    private static boolean canStand(ServerLevel level, int x, int y, int z) {
        if (!isBodySpaceClear(level, x, y, z)) return false;

        BlockPos below = new BlockPos(x, y - 1, z);
        BlockState support = level.getBlockState(below);
        if (support.is(BlockTags.LEAVES)) return false;

        return support.getFluidState().isEmpty()
                && !support.getCollisionShape(level, below).isEmpty();
    }

    private static boolean isBodySpaceClear(ServerLevel level, int x, int y, int z) {
        BlockPos feet = new BlockPos(x, y, z);
        BlockPos head = feet.above();

        BlockState feetState = level.getBlockState(feet);
        BlockState headState = level.getBlockState(head);

        return feetState.getFluidState().isEmpty()
                && headState.getFluidState().isEmpty()
                && feetState.getCollisionShape(level, feet).isEmpty()
                && headState.getCollisionShape(level, head).isEmpty();
    }
}
