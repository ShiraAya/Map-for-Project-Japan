package com.sora.pjm.map;

import java.util.*;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import java.io.InterruptedIOException;
import java.util.function.BooleanSupplier;

/** Bounded CPU work and decoded results. Only the current view may publish a tile. */
final class PJMAsyncTileLoader<T extends AutoCloseable> implements AutoCloseable {
    private static final ThreadLocal<BooleanSupplier> CANCELLED = new ThreadLocal<>();

    /** Cooperative cancellation: invalidating a view must not kill reusable worker threads. */
    static void checkCancelled() throws InterruptedIOException {
        BooleanSupplier cancelled = CANCELLED.get();
        if (Thread.currentThread().isInterrupted() || cancelled != null && cancelled.getAsBoolean())
            throw new InterruptedIOException("Map view superseded or closed");
    }
    interface Decoder<T> { T load(PJMTileKey key) throws Exception; }
    record Result<T>(PJMTileKey key, T value, boolean failed) {}
    private final Decoder<T> decoder;
    private final Runnable onStopped;
    private final int maxJobs, maxReady;
    private final Map<PJMTileKey, Job> jobs = new HashMap<>();
    private final PriorityQueue<Job> queued = new PriorityQueue<>(Comparator.comparingDouble(j -> j.priority));
    private final ArrayDeque<Completed> ready = new ArrayDeque<>();
    private final List<Thread> threads = new ArrayList<>();
    private Predicate<PJMTileKey> wanted = key -> true;
    private ToDoubleFunction<PJMTileKey> priority = key -> 0;
    private boolean closed;
    private int liveWorkers;
    private long discarded;

    PJMAsyncTileLoader(int workers, int maxJobs, int maxReady, Decoder<T> decoder, Runnable onStopped) {
        this.decoder = decoder; this.onStopped = onStopped;
        this.maxJobs = maxJobs; this.maxReady = maxReady;
        liveWorkers = workers;
        for (int i = 0; i < workers; i++) {
            Thread thread = new Thread(this::run, "PJM-Tile-Decode-" + i);
            thread.setDaemon(true); threads.add(thread);
        }
        threads.forEach(Thread::start);
    }

    synchronized void beginView(Predicate<PJMTileKey> wanted, ToDoubleFunction<PJMTileKey> priority) {
        this.wanted = wanted; this.priority = priority;
        invalidate(key -> !wanted.test(key));
        // A pan can change priority without changing which tiles intersect the screen.
        List<Job> waiting = new ArrayList<>(queued); queued.clear();
        for (Job j : waiting) { j.priority = priority.applyAsDouble(j.key); queued.add(j); }
    }

    synchronized void request(PJMTileKey key) {
        if (closed || !wanted.test(key) || jobs.containsKey(key) || jobs.size() >= maxJobs) return;
        Job job = new Job(key, priority.applyAsDouble(key));
        jobs.put(key, job); queued.add(job); notifyAll();
    }

    synchronized void invalidate(Predicate<PJMTileKey> predicate) {
        jobs.entrySet().removeIf(e -> {
            if (!predicate.test(e.getKey())) return false;
            e.getValue().cancelled = true;
            return true;
        });
        queued.removeIf(j -> jobs.get(j.key) != j);
        for (Iterator<Completed> it = ready.iterator(); it.hasNext();) {
            Completed c = it.next();
            if (jobs.get(c.job.key) != c.job) { dispose(c.value); it.remove(); discarded++; }
        }
        notifyAll();
    }

    synchronized Result<T> poll() {
        Completed c = ready.pollFirst();
        if (c == null) return null;
        jobs.remove(c.job.key, c.job); notifyAll();
        return new Result<>(c.job.key, c.value, c.failed);
    }

    synchronized int pendingCount() { return jobs.size(); }
    synchronized int readyCount() { return ready.size(); }
    synchronized long discardedCount() { return discarded; }

    private void run() {
        try {
            while (true) {
                Job job;
                synchronized (this) {
                    while (!closed && queued.isEmpty()) wait();
                    if (closed) return;
                    job = queued.remove();
                }
                T value = null; boolean failed = false;
                CANCELLED.set(() -> job.cancelled);
                try { checkCancelled(); value = decoder.load(job.key); }
                catch (Exception | LinkageError e) { failed = true; }
                finally { CANCELLED.remove(); }
                synchronized (this) {
                    try {
                        while (!closed && jobs.get(job.key) == job && ready.size() >= maxReady) wait();
                    } catch (InterruptedException e) {
                        dispose(value); throw e;
                    }
                    if (closed || jobs.get(job.key) != job) { dispose(value); discarded++; }
                    else { ready.addLast(new Completed(job, value, failed)); notifyAll(); }
                }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } finally {
            boolean last;
            synchronized (this) { last = --liveWorkers == 0; notifyAll(); }
            if (last) onStopped.run();
        }
    }

    @Override public synchronized void close() {
        if (closed) return;
        closed = true; jobs.values().forEach(j -> j.cancelled = true); jobs.clear(); queued.clear();
        for (Completed c : ready) dispose(c.value);
        ready.clear(); threads.forEach(Thread::interrupt); notifyAll();
    }

    private static void dispose(AutoCloseable value) {
        if (value != null) try { value.close(); } catch (Exception ignored) {}
    }
    private final class Job {
        final PJMTileKey key; double priority; volatile boolean cancelled;
        Job(PJMTileKey key, double priority) { this.key = key; this.priority = priority; }
    }
    private final class Completed {
        final Job job; final T value; final boolean failed;
        Completed(Job job, T value, boolean failed) { this.job = job; this.value = value; this.failed = failed; }
    }
}
