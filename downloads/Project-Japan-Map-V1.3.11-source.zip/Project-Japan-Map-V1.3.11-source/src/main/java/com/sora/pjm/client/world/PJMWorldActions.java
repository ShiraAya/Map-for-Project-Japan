package com.sora.pjm.client.world;

import com.sora.pjm.world.PJMTeleportService;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;

import java.util.Locale;
import java.util.function.IntConsumer;

/** Client entry points for PJM world actions. */
public final class PJMWorldActions {
    private static final double MAX_HORIZONTAL_COORD = 29_999_984.0D;

    private PJMWorldActions() {
    }

    /**
     * Resolves a default waypoint feet-Y when an integrated server is available.
     *
     * <p>Remote multiplayer clients cannot synchronously inspect arbitrary server chunks, so this
     * helper keeps the existing fallback for waypoint creation. Teleporting itself does not require
     * PJM on the server: PJM submits Minecraft's vanilla {@code /tp} command through the current
     * client connection.</p>
     */
    public static void resolveGroundY(Minecraft minecraft, int blockX, int blockZ,
                                      IntConsumer onResolved) {
        MinecraftServer server = minecraft.getSingleplayerServer();
        if (server == null) {
            int fallback = minecraft.player == null ? 64 : Mth.floor(minecraft.player.getY());
            minecraft.execute(() -> onResolved.accept(fallback));
            return;
        }

        server.execute(() -> {
            ServerLevel level = server.overworld();
            level.getChunk(blockX >> 4, blockZ >> 4);
            int y = PJMTeleportService.findSafeFeetY(level, blockX, blockZ);
            minecraft.execute(() -> onResolved.accept(y));
        });
    }

    /**
     * Teleports to a map X/Z using the vanilla server command path.
     *
     * <p>The current server-side Y is preserved with {@code ~}. This keeps PJM client-only and
     * avoids pretending that a remote client can safely inspect or generate an arbitrary target
     * chunk. The server remains authoritative and applies its normal command permissions.</p>
     */
    public static boolean teleportToSurface(Minecraft minecraft,
                                            double targetX, double targetZ,
                                            Runnable afterScheduled) {
        if (!validHorizontal(targetX) || !validHorizontal(targetZ)) return false;

        ClientPacketListener connection = minecraft.getConnection();
        if (minecraft.player == null || connection == null) return false;

        String command = String.format(Locale.ROOT,
                "tp @s %.3f ~ %.3f", targetX, targetZ);
        connection.sendCommand(command);

        if (afterScheduled != null) afterScheduled.run();
        return true;
    }

    /**
     * Teleports to a waypoint XYZ using the vanilla server command path.
     *
     * <p>No PJM packet or server-side PJM installation is required. If the player does not have
     * permission to use {@code /tp}, the server's normal command system rejects the request and
     * reports the reason to the player.</p>
     */
    public static boolean teleportToExact(Minecraft minecraft,
                                          double targetX, double targetY, double targetZ,
                                          Runnable afterScheduled) {
        if (!validHorizontal(targetX) || !Double.isFinite(targetY) || !validHorizontal(targetZ)) {
            return false;
        }

        ClientPacketListener connection = minecraft.getConnection();
        if (minecraft.player == null || connection == null) return false;

        String command = String.format(Locale.ROOT,
                "tp @s %.3f %.3f %.3f", targetX, targetY, targetZ);
        connection.sendCommand(command);

        if (afterScheduled != null) afterScheduled.run();
        return true;
    }

    private static boolean validHorizontal(double value) {
        return Double.isFinite(value) && Math.abs(value) <= MAX_HORIZONTAL_COORD;
    }
}
