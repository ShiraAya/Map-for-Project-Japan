package com.sora.pjm.map;

/** Shared by base/road/block layers in one rendered view. Never decode images in this budget. */
final class PJMUploadBudget {
    private int uploaded;
    private long started;
    boolean available() { return uploaded < 2 && (uploaded == 0 || System.nanoTime() - started < 2_000_000L); }
    void startUpload() { if (uploaded++ == 0) started = System.nanoTime(); }
}
