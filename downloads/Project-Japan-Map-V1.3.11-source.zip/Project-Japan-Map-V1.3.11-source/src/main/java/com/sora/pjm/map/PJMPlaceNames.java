package com.sora.pjm.map;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Exact, typed names: sourced Chinese spelling, otherwise the original Japanese form. */
final class PJMPlaceNames {
    enum Kind { RIVER, LAKE, MOUNTAIN, CITY, PREFECTURE, MARINE, ISLAND }
    private static final Map<Kind, Map<String,String>> NAMES = load();
    private PJMPlaceNames() {}

    static String display(Kind kind, String raw) {
        if (raw == null || raw.isBlank()) return "";
        String name = raw.strip();
        if (name.startsWith("tidal:") || name.equals("名称不明") || name.equals("名称未設定")
                || name.equals("不明") || name.equals("無名")) return "";
        String known = NAMES.get(kind).get(name);
        if (known != null) return known;
        // New real Japanese names remain intact. Internal IDs/romanization are never decorated
        // with an invented 川/湖 suffix. Unknown machine IDs are left unnamed until catalogued.
        boolean japanese = name.codePoints().anyMatch(c -> Character.UnicodeScript.of(c) == Character.UnicodeScript.HAN
                || Character.UnicodeScript.of(c) == Character.UnicodeScript.HIRAGANA
                || Character.UnicodeScript.of(c) == Character.UnicodeScript.KATAKANA);
        boolean internal = name.indexOf(':') >= 0 || name.indexOf('~') >= 0
                || name.codePoints().anyMatch(c -> c < 128 && (Character.isLetter(c) || Character.isDigit(c)));
        return japanese && !internal ? name : "";
    }
    static int aliases(Kind kind) { return NAMES.get(kind).size(); }

    private static Map<Kind,Map<String,String>> load() {
        Map<Kind,Map<String,String>> result = new EnumMap<>(Kind.class);
        for (Kind k : Kind.values()) result.put(k,new HashMap<>());
        try (InputStream in = PJMPlaceNames.class.getResourceAsStream("/assets/pjm/geography/place-names.tsv")) {
            if (in == null) throw new IOException("Missing place name catalogue");
            try (var reader = new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))) {
                for (String line; (line = reader.readLine()) != null;) {
                    if (line.isBlank() || line.startsWith("#")) continue;
                    String[] f = line.split("\t",-1);
                    if (f.length != 4 || f[2].isBlank()) throw new IOException("Malformed place name row");
                    Kind kind = Kind.valueOf(f[0].toUpperCase(Locale.ROOT));
                    String display = f[3].isBlank() ? f[2] : f[3];
                    String previous = result.get(kind).putIfAbsent(f[1],display);
                    if (previous != null && !previous.equals(display)) throw new IOException("Ambiguous place name: " + f[0] + "/" + f[1]);
                }
            }
        } catch (IOException | IllegalArgumentException e) { throw new IllegalStateException("Cannot load PJM names",e); }
        result.replaceAll((k,v) -> Map.copyOf(v));
        return Map.copyOf(result);
    }
}
