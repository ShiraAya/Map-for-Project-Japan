package com.sora.pjm.map.blockmap;

import com.sora.pjm.map.mode.PJMMapMode;
import com.sora.pjm.map.mode.PJMMapModeState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * V1.3 block-map sampler.
 *
 * <p>This is intentionally independent from the old V1.2 surface implementation. It builds a
 * conventional top-down Minecraft map from already-loaded client chunks, using the actual block
 * map colour as the base, biome tint where Minecraft exposes one, and a small terrain-relief shade.
 * Decorations with no collision (flowers, grass tufts, torches, etc.) are skipped so they do not
 * become giant single-pixel noise at map scale.</p>
 *
 * <p>No chunk ticket is created and no server chunk is requested. Unseen areas remain unknown until
 * the client has actually received those chunks.</p>
 */
public final class PJMBlockMapService {
    public static final PJMBlockMapService INSTANCE = new PJMBlockMapService();

    private static final int SCAN_RADIUS_CHUNKS = 6;
    private static final int ACTIVE_MAX_SCANS_PER_TICK = 4;
    private static final int BACKGROUND_MAX_SCANS_PER_TICK = 1;
    private static final long ACTIVE_BUDGET_NS = 3_000_000L;
    private static final long BACKGROUND_BUDGET_NS = 900_000L;
    private static final int SURFACE_SEARCH_DEPTH = 16;
    private static final int MAX_CHANGE_HISTORY = 4096;

    private final ArrayDeque<Long> urgentQueue = new ArrayDeque<>();
    private final ArrayDeque<Long> normalQueue = new ArrayDeque<>();
    private final Set<Long> urgentQueued = new HashSet<>();
    private final Set<Long> normalQueued = new HashSet<>();
    private final Map<Long, Integer> lastScannedTick = new HashMap<>();
    private final ArrayDeque<BlockMapChange> changeHistory = new ArrayDeque<>();

    private PJMBlockRegionStore store;
    private ClientLevel currentLevel;
    private String currentWorldKey;
    private int ticks;
    private long revision = 1L;

    private PJMBlockMapService() {
    }

    public synchronized void tick(Minecraft minecraft) {
        if (minecraft.player == null || minecraft.level == null) {
            reset();
            return;
        }

        ensureWorld(minecraft);
        if (store == null || !minecraft.level.dimension().equals(Level.OVERWORLD)) return;

        ticks++;
        boolean active = PJMMapModeState.INSTANCE.mode() == PJMMapMode.MAP;
        if (ticks == 1 || ticks % 10 == 0) {
            enqueueNearby(minecraft, active);
        }

        int maxScans = active ? ACTIVE_MAX_SCANS_PER_TICK : BACKGROUND_MAX_SCANS_PER_TICK;
        long budget = active ? ACTIVE_BUDGET_NS : BACKGROUND_BUDGET_NS;
        long start = System.nanoTime();
        int scans = 0;
        while (scans < maxScans) {
            Long packed = pollNext();
            if (packed == null) break;
            scanLoadedChunk(minecraft, minecraft.level, unpackX(packed), unpackZ(packed));
            scans++;
            if (scans > 0 && System.nanoTime() - start >= budget) break;
        }
    }

    public synchronized void ensureWorld(Minecraft minecraft) {
        if (minecraft.level == null) return;
        if (minecraft.level == currentLevel && store != null) return;

        String worldName = worldName(minecraft);
        ResourceKey<Level> dimension = minecraft.level.dimension();
        String key = worldName + "|" + dimension.location();
        if (key.equals(currentWorldKey) && store != null) {
            currentLevel = minecraft.level;
            return;
        }

        closeStore();
        currentLevel = minecraft.level;
        currentWorldKey = key;
        ticks = 0;
        clearQueues();
        lastScannedTick.clear();
        changeHistory.clear();

        String folder = sanitize(worldName);
        String dimensionFolder = sanitize(dimension.location().toString());
        Path root = FMLPaths.GAMEDIR.get()
                .resolve("PJM")
                .resolve("cache")
                .resolve(folder)
                .resolve("blockmap")
                .resolve(dimensionFolder);
        try {
            store = new PJMBlockRegionStore(root);
            revision++;
        } catch (IOException e) {
            store = null;
        }
    }

    /** Marks a client block update for near-immediate re-sampling. */
    public synchronized void markDirty(BlockPos pos) {
        if (pos == null) return;
        markChunkDirty(pos.getX() >> 4, pos.getZ() >> 4);
    }

    /** Marks a chunk dirty without loading it. The next tick samples it only if it is already loaded. */
    public synchronized void markChunkDirty(int chunkX, int chunkZ) {
        long key = pack(chunkX, chunkZ);
        lastScannedTick.remove(key);
        enqueue(chunkX, chunkZ, true);
    }

    /** Gives a newly received client chunk priority so map mode fills in quickly while exploring. */
    public synchronized void markChunkLoaded(int chunkX, int chunkZ) {
        boolean cached = store != null && store.hasChunk(chunkX, chunkZ);
        enqueue(chunkX, chunkZ, !cached);
    }

    public synchronized boolean available() {
        return store != null;
    }

    public synchronized long revision() {
        return revision;
    }

    public synchronized ChangeBatch changesSince(long seenRevision) {
        if (seenRevision == revision) {
            return new ChangeBatch(false, List.of(), revision);
        }
        if (changeHistory.isEmpty()) {
            return new ChangeBatch(true, List.of(), revision);
        }

        long oldest = changeHistory.peekFirst().revision();
        if (seenRevision < oldest - 1L) {
            return new ChangeBatch(true, List.of(), revision);
        }

        List<BlockMapChange> changes = new ArrayList<>();
        for (BlockMapChange change : changeHistory) {
            if (change.revision() > seenRevision) changes.add(change);
        }
        return new ChangeBatch(false, changes, revision);
    }

    synchronized PJMBlockRegionStore store() {
        return store;
    }

    public synchronized void reset() {
        if (store == null && currentWorldKey == null && urgentQueue.isEmpty() && normalQueue.isEmpty()
                && urgentQueued.isEmpty() && normalQueued.isEmpty() && lastScannedTick.isEmpty()) {
            return;
        }
        closeStore();
        currentLevel = null;
        currentWorldKey = null;
        ticks = 0;
        clearQueues();
        lastScannedTick.clear();
        changeHistory.clear();
        revision++;
    }

    private void enqueueNearby(Minecraft minecraft, boolean active) {
        if (minecraft.player == null || minecraft.level == null) return;
        int centerX = minecraft.player.chunkPosition().x;
        int centerZ = minecraft.player.chunkPosition().z;

        for (int radius = 0; radius <= SCAN_RADIUS_CHUNKS; radius++) {
            int interval = refreshInterval(radius, active);
            boolean urgent = radius <= 1;
            if (radius == 0) {
                enqueueIfDue(centerX, centerZ, interval, true);
                continue;
            }
            for (int dx = -radius; dx <= radius; dx++) {
                enqueueIfDue(centerX + dx, centerZ - radius, interval, urgent);
                enqueueIfDue(centerX + dx, centerZ + radius, interval, urgent);
            }
            for (int dz = -radius + 1; dz <= radius - 1; dz++) {
                enqueueIfDue(centerX - radius, centerZ + dz, interval, urgent);
                enqueueIfDue(centerX + radius, centerZ + dz, interval, urgent);
            }
        }
    }

    private int refreshInterval(int radius, boolean active) {
        if (!active) {
            if (radius == 0) return 100;
            if (radius <= 1) return 200;
            return 500;
        }
        if (radius == 0) return 20;
        if (radius <= 1) return 40;
        if (radius <= 2) return 80;
        if (radius <= 4) return 160;
        return 300;
    }

    private void enqueueIfDue(int chunkX, int chunkZ, int interval, boolean urgent) {
        long key = pack(chunkX, chunkZ);
        Integer last = lastScannedTick.get(key);
        if (last != null && ticks - last < interval) return;

        boolean cached = store != null && store.hasChunk(chunkX, chunkZ);
        enqueue(chunkX, chunkZ, urgent || !cached);
    }

    private void enqueue(int chunkX, int chunkZ, boolean urgent) {
        long key = pack(chunkX, chunkZ);
        if (urgent) {
            if (urgentQueued.contains(key)) return;
            if (normalQueued.remove(key)) normalQueue.remove(key);
            urgentQueued.add(key);
            urgentQueue.addLast(key);
        } else {
            if (urgentQueued.contains(key) || normalQueued.contains(key)) return;
            normalQueued.add(key);
            normalQueue.addLast(key);
        }
    }

    private Long pollNext() {
        Long key = urgentQueue.pollFirst();
        if (key != null) {
            urgentQueued.remove(key);
            return key;
        }
        key = normalQueue.pollFirst();
        if (key != null) normalQueued.remove(key);
        return key;
    }

    private void scanLoadedChunk(Minecraft minecraft, ClientLevel level, int chunkX, int chunkZ) {
        LevelChunk chunk = level.getChunkSource().getChunkNow(chunkX, chunkZ);
        if (chunk == null) return;

        int[] rawColours = new int[16 * 16];
        int[] heights = new int[16 * 16];
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        BlockColors blockColors = minecraft.getBlockColors();

        for (int localZ = 0; localZ < 16; localZ++) {
            int worldZ = (chunkZ << 4) + localZ;
            for (int localX = 0; localX < 16; localX++) {
                int worldX = (chunkX << 4) + localX;
                int top = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, localX, localZ);
                int startY = Math.min(level.getMaxBuildHeight() - 1, top - 1);
                int endY = Math.max(level.getMinBuildHeight(), startY - SURFACE_SEARCH_DEPTH);

                int rgb = 0;
                int surfaceY = level.getMinBuildHeight();
                for (int y = startY; y >= endY; y--) {
                    pos.set(worldX, y, worldZ);
                    BlockState state = chunk.getBlockState(pos);
                    if (state.isAir()) continue;

                    MapColor mapColor = state.getMapColor(level, pos);
                    if (mapColor == MapColor.NONE) continue;
                    if (state.getFluidState().isEmpty()
                            && state.getCollisionShape(level, pos).isEmpty()) {
                        continue;
                    }

                    rgb = resolveRgb(blockColors, state, level, pos, mapColor);
                    surfaceY = y;
                    break;
                }

                int index = localZ * 16 + localX;
                rawColours[index] = rgb == 0 ? 0 : 0xFF000000 | rgb;
                heights[index] = surfaceY;
            }
        }

        int[] shaded = new int[16 * 16];
        for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
                int index = z * 16 + x;
                int colour = rawColours[index];
                if ((colour >>> 24) == 0) continue;
                int h = heights[index];
                int west = x > 0 ? heights[index - 1] : h;
                int north = z > 0 ? heights[index - 16] : h;
                double slope = h - (west + north) * 0.5D;
                double factor = clamp(0.96D + slope * 0.035D, 0.84D, 1.12D);
                shaded[index] = shade(colour, factor);
            }
        }

        lastScannedTick.put(pack(chunkX, chunkZ), ticks);
        if (store != null && store.putChunk(chunkX, chunkZ, shaded)) {
            revision++;
            changeHistory.addLast(new BlockMapChange(revision, chunkX, chunkZ));
            while (changeHistory.size() > MAX_CHANGE_HISTORY) changeHistory.removeFirst();
        }
    }

    /**
     * Uses MapColor.col directly (0xRRGGBB). V1.2's byte-order conversion is intentionally gone.
     * For biome-tinted blocks (grass, foliage, water), blend in Minecraft's own tint resolver.
     */
    private static int resolveRgb(BlockColors blockColors, BlockState state, ClientLevel level,
                                  BlockPos pos, MapColor mapColor) {
        int base = mapColor.col & 0xFFFFFF;
        int tint = blockColors.getColor(state, level, pos, 0);
        if (tint < 0) return base;
        tint &= 0xFFFFFF;

        // Keep some of the material identity from MapColor while letting biome tint dominate.
        int br = (base >>> 16) & 0xFF;
        int bg = (base >>> 8) & 0xFF;
        int bb = base & 0xFF;
        int tr = (tint >>> 16) & 0xFF;
        int tg = (tint >>> 8) & 0xFF;
        int tb = tint & 0xFF;
        int r = (br * 2 + tr * 3) / 5;
        int g = (bg * 2 + tg * 3) / 5;
        int b = (bb * 2 + tb * 3) / 5;
        return (r << 16) | (g << 8) | b;
    }

    private static int shade(int argb, double factor) {
        int r = clamp((int)Math.round(((argb >>> 16) & 0xFF) * factor), 0, 255);
        int g = clamp((int)Math.round(((argb >>> 8) & 0xFF) * factor), 0, 255);
        int b = clamp((int)Math.round((argb & 0xFF) * factor), 0, 255);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void closeStore() {
        if (store != null) {
            store.close();
            store = null;
        }
    }

    private void clearQueues() {
        urgentQueue.clear();
        normalQueue.clear();
        urgentQueued.clear();
        normalQueued.clear();
    }

    private static String worldName(Minecraft minecraft) {
        if (minecraft.getSingleplayerServer() != null) {
            try {
                Path saveRoot = minecraft.getSingleplayerServer()
                        .getWorldPath(LevelResource.ROOT)
                        .toAbsolutePath().normalize();
                Path folder = saveRoot.getFileName();
                if (folder != null && !folder.toString().isBlank()) return folder.toString();
            } catch (RuntimeException ignored) {
            }
            return minecraft.getSingleplayerServer().getWorldData().getLevelName();
        }
        ServerData server = minecraft.getCurrentServer();
        if (server != null && server.ip != null && !server.ip.isBlank()) {
            return "server-" + server.ip;
        }
        return "world";
    }

    private static String sanitize(String value) {
        String result = value.replaceAll("[<>:\"/\\\\|?*]", "_").trim();
        while (result.endsWith(".") || result.endsWith(" ")) {
            result = result.substring(0, result.length() - 1);
        }
        return result.isBlank() ? "world" : result;
    }

    private static long pack(int x, int z) {
        return ((long)x << 32) ^ (z & 0xffffffffL);
    }

    private static int unpackX(long key) {
        return (int)(key >> 32);
    }

    private static int unpackZ(long key) {
        return (int)key;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    public record BlockMapChange(long revision, int chunkX, int chunkZ) {
    }

    public record ChangeBatch(boolean fullRefresh, List<BlockMapChange> changes,
                              long latestRevision) {
    }
}
