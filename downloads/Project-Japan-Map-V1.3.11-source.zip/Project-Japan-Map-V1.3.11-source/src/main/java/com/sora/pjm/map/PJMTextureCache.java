package com.sora.pjm.map;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import java.io.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

/** LRU GPU cache with worker PNG decode, current-view requests and paced GPU uploads. */
public final class PJMTextureCache implements AutoCloseable {
    private final Minecraft minecraft;
    private final int maxTextures;
    private final LinkedHashMap<PJMTileKey, CachedTexture> cache = new LinkedHashMap<>(64, .75f, true);
    private final Map<PJMTileKey, Boolean> knownEmpty = boundedMap(2048);
    private final Map<PJMTileKey, Long> retryAfter = boundedMap(256);
    private final PJMAsyncTileLoader<NativeImage> loader;
    private boolean closed;

    public PJMTextureCache(Minecraft minecraft, PJMMapSource source, int maxTextures) {
        this(minecraft, source, maxTextures, 2);
    }
    public PJMTextureCache(Minecraft minecraft, PJMMapSource source, int maxTextures, int requestedWorkers) {
        this.minecraft = minecraft; this.maxTextures = Math.max(16, maxTextures);
        loader = new PJMAsyncTileLoader<>(Math.max(1, Math.min(4, requestedWorkers)), 128, 8, key -> {
            byte[] png = source.readTile(key);
            if (png == null) return null;
            try (ByteArrayInputStream in = new ByteArrayInputStream(png)) {
                NativeImage image = NativeImage.read(in);
                if (image.getWidth() != source.header().tileSize() || image.getHeight() != source.header().tileSize()) {
                    image.close(); throw new IOException("Unexpected map tile dimensions");
                }
                return image;
            }
        }, () -> { try { source.close(); } catch (IOException ignored) {} });
    }

    /** Render-thread only. Old views cannot occupy the queue or upload textures over the new view. */
    void beginView(Predicate<PJMTileKey> wanted, ToDoubleFunction<PJMTileKey> priority, PJMUploadBudget budget) {
        if (closed) return;
        loader.beginView(wanted, priority);
        for (int completed = 0; completed < 64 && budget.available(); completed++) {
            var result = loader.poll();
            if (result == null) break;
            if (result.failed()) { retryAfter.put(result.key(), System.nanoTime() + 2_000_000_000L); continue; }
            if (result.value() == null) { knownEmpty.put(result.key(), true); continue; }
            budget.startUpload(); upload(result.key(), result.value());
        }
    }

    public ResourceLocation get(PJMTileKey key) {
        CachedTexture existing = cache.get(key);
        if (existing != null) return existing.location();
        if (!closed && !knownEmpty.containsKey(key) && System.nanoTime() >= retryAfter.getOrDefault(key, Long.MIN_VALUE))
            loader.request(key);
        return null;
    }
    public ResourceLocation getIfPresent(PJMTileKey key) {
        CachedTexture existing = cache.get(key); return existing == null ? null : existing.location();
    }
    public boolean isResolved(PJMTileKey key) { return cache.containsKey(key) || knownEmpty.containsKey(key); }
    public int pendingCount() { return loader.pendingCount(); }
    boolean hasLevel(int level) { return cache.keySet().stream().anyMatch(k -> k.zoom() == level); }

    private void upload(PJMTileKey key, NativeImage image) {
        if (closed || cache.containsKey(key)) { image.close(); return; }
        DynamicTexture texture = null;
        try {
            texture = new DynamicTexture(image);
            ResourceLocation location = minecraft.getTextureManager().register(
                    "pjm_tile_" + key.zoom() + "_" + key.x() + "_" + key.y(), texture);
            cache.put(key, new CachedTexture(location, texture)); trim();
        } catch (RuntimeException e) {
            if (texture == null) image.close(); else texture.close();
            retryAfter.put(key, System.nanoTime() + 2_000_000_000L);
        }
    }
    public void invalidate(Predicate<PJMTileKey> predicate) {
        if (closed) return;
        loader.invalidate(predicate);
        knownEmpty.keySet().removeIf(predicate); retryAfter.keySet().removeIf(predicate);
        for (Iterator<Map.Entry<PJMTileKey, CachedTexture>> it = cache.entrySet().iterator(); it.hasNext();) {
            var e = it.next(); if (!predicate.test(e.getKey())) continue;
            minecraft.getTextureManager().release(e.getValue().location()); it.remove();
        }
    }
    private void trim() {
        while (cache.size() > maxTextures) {
            var it = cache.entrySet().iterator(); var old = it.next().getValue(); it.remove();
            minecraft.getTextureManager().release(old.location());
        }
    }
    private static <K,V> Map<K,V> boundedMap(int limit) {
        return new LinkedHashMap<>(64, .75f, true) {
            @Override protected boolean removeEldestEntry(Map.Entry<K,V> e) { return size() > limit; }
        };
    }
    @Override public void close() throws IOException {
        if (closed) return;
        closed = true; loader.close();
        for (CachedTexture texture : cache.values()) minecraft.getTextureManager().release(texture.location());
        cache.clear(); knownEmpty.clear(); retryAfter.clear();
    }
    private record CachedTexture(ResourceLocation location, DynamicTexture texture) {}
}
