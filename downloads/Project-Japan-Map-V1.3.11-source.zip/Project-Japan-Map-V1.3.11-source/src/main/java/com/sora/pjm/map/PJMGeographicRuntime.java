package com.sora.pjm.map;

import java.util.List;

/** Optional geographic providers; no PJ/PJR classes are linked into PJM's JAR. */
interface PJMGeographicRuntime {
    String modId();
    String displayName();
    String version();
    String fingerprint();
    int minWorldX();
    int maxWorldX();
    int minWorldZ();
    int maxWorldZ();
    VisualTerrain visualTerrain(double u, double v);
    TerrainPixel terrain(int x, int z);
    boolean riverWater(int x, int z);
    boolean lakeWater(int x, int z);
    NamedHydroSample riverSample(int x, int z);
    NamedHydroSample lakeSample(int x, int z);
    boolean vectorRiversAvailable();
    List<RiverVectorSegment> riverSegments(double minX, double minZ, double maxX, double maxZ);
    int worldXFromLongitude(double longitude);
    int worldZFromLatitude(double latitude);
    double longitudeFromWorldX(double x);
    double latitudeFromWorldZ(double z);

    /** Geographic footprint sizes were tuned at the original PJ horizontal scale of 1:8. */
    default double footprintScale() { return 1.0D; }

    /** PJR has a block-accurate hydrology predicate for detailed map zooms. */
    default boolean exactLocalRivers() { return false; }

    /** An authoritative local survey may replace centre-line river cartography at every zoom. */
    default SurveyWater surveyedWater(int x, int z) { return SurveyWater.UNMAPPED; }

    enum SurveyWater { UNMAPPED, DRY, OCEAN, RIVER, LAKE }

    record VisualTerrain(boolean land, int elevationMetres, double coverage) {}
    record TerrainPixel(boolean land, int elevationMetres, double coverage) {}
    record NamedHydroSample(boolean corridor, boolean water, String name) {
        static final NamedHydroSample EMPTY = new NamedHydroSample(false, false, "");
        public boolean named() { return name != null && !name.isBlank(); }
    }
    record RiverVectorSegment(double x1, double z1, double x2, double z2,
                              double widthBlocks, double minX, double maxX,
                              double minZ, double maxZ) {}
}
