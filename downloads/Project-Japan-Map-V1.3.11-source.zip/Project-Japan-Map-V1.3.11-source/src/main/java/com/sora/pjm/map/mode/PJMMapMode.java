package com.sora.pjm.map.mode;

/** Shared display mode for both the minimap and the full-screen map. */
public enum PJMMapMode {
    DEFAULT("mode.pjm.default"),
    TERRAIN("mode.pjm.terrain"),
    MAP("mode.pjm.map");

    private final String translationKey;

    PJMMapMode(String translationKey) {
        this.translationKey = translationKey;
    }

    public String translationKey() {
        return translationKey;
    }

    public PJMMapMode next() {
        return switch (this) {
            case DEFAULT -> TERRAIN;
            case TERRAIN -> MAP;
            case MAP -> DEFAULT;
        };
    }
}
