package com.sora.pjm.map.blockmap;

import com.sora.pjm.map.PJMMapHeader;
import com.sora.pjm.map.PJMMapSource;
import com.sora.pjm.map.PJMTileKey;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Conventional coloured top-down Minecraft map generated from the V1.3 block-map cache.
 *
 * <p>At high zoom it renders one cached world column at a time. At lower zoom it switches to 4x4
 * and 16x16 precomputed averages so nationwide views do not iterate millions of individual blocks.
 * Unknown/unexplored chunks remain transparent and are filled by the renderer's neutral background.</p>
 */
public final class PJMBlockTileSource implements PJMMapSource {
    private final PJMMapHeader header;
    private final PJMBlockMapService service;

    public PJMBlockTileSource(PJMMapHeader header, PJMBlockMapService service) {
        this.header = header;
        this.service = service;
    }

    @Override
    public PJMMapHeader header() {
        return header;
    }

    @Override
    public byte[] readTile(PJMTileKey key) throws IOException {
        PJMBlockRegionStore store = service.store();
        if (store == null) return null;
        if (key.zoom() < header.minZoom() || key.zoom() > header.maxZoom()) return null;

        int axis = 1 << key.zoom();
        if (key.x() < 0 || key.y() < 0 || key.x() >= axis || key.y() >= axis) return null;

        int tileSize = header.tileSize();
        double tileWorldWidth = header.worldWidth() / axis;
        double tileWorldHeight = header.worldHeight() / axis;
        double minWorldX = header.minWorldX() + key.x() * tileWorldWidth;
        double minWorldZ = header.minWorldZ() + key.y() * tileWorldHeight;
        double maxWorldX = minWorldX + tileWorldWidth;
        double maxWorldZ = minWorldZ + tileWorldHeight;
        double worldPerPixelX = tileWorldWidth / tileSize;
        double worldPerPixelZ = tileWorldHeight / tileSize;
        double worldPerPixel = Math.max(worldPerPixelX, worldPerPixelZ);

        int minBlockX = (int)Math.floor(minWorldX) - 16;
        int minBlockZ = (int)Math.floor(minWorldZ) - 16;
        int maxBlockX = (int)Math.ceil(maxWorldX) + 16;
        int maxBlockZ = (int)Math.ceil(maxWorldZ) + 16;

        BufferedImage image = new BufferedImage(tileSize, tileSize, BufferedImage.TYPE_INT_ARGB);
        boolean[] any = {false};
        List<PJMBlockRegionStore.RegionCoord> regions = store.regionCoordsInWorldRange(
                minBlockX, minBlockZ, maxBlockX, maxBlockZ);

        for (PJMBlockRegionStore.RegionCoord region : regions) {
            store.visitBlockChunks(region,
                    minBlockX, minBlockZ, maxBlockX, maxBlockZ,
                    (chunkX, chunkZ, colours, colourOffset, chunkAverage,
                     quadrantAverage, quadrantOffset) -> {
                        int chunkBaseX = chunkX << 4;
                        int chunkBaseZ = chunkZ << 4;

                        if (worldPerPixel >= 8.0D) {
                            if ((chunkAverage >>> 24) != 0) {
                                fillWorldCell(image, tileSize, chunkBaseX, chunkBaseZ, 16,
                                        chunkAverage, minWorldX, minWorldZ,
                                        worldPerPixelX, worldPerPixelZ);
                                any[0] = true;
                            }
                            return;
                        }

                        if (worldPerPixel >= 2.0D) {
                            for (int qz = 0; qz < 4; qz++) {
                                for (int qx = 0; qx < 4; qx++) {
                                    int colour = quadrantAverage[quadrantOffset + qz * 4 + qx];
                                    if ((colour >>> 24) == 0) continue;
                                    fillWorldCell(image, tileSize,
                                            chunkBaseX + qx * 4,
                                            chunkBaseZ + qz * 4,
                                            4, colour,
                                            minWorldX, minWorldZ,
                                            worldPerPixelX, worldPerPixelZ);
                                    any[0] = true;
                                }
                            }
                            return;
                        }

                        for (int localZ = 0; localZ < 16; localZ++) {
                            for (int localX = 0; localX < 16; localX++) {
                                int colour = colours[colourOffset + localZ * 16 + localX];
                                if ((colour >>> 24) == 0) continue;
                                fillWorldCell(image, tileSize,
                                        chunkBaseX + localX,
                                        chunkBaseZ + localZ,
                                        1, colour,
                                        minWorldX, minWorldZ,
                                        worldPerPixelX, worldPerPixelZ);
                                any[0] = true;
                            }
                        }
                    });
        }

        if (!any[0]) return null;

        ByteArrayOutputStream out = new ByteArrayOutputStream(24 * 1024);
        if (!ImageIO.write(image, "PNG", out)) {
            throw new IOException("No PNG writer available");
        }
        return out.toByteArray();
    }

    private static void fillWorldCell(BufferedImage image, int size,
                                      int worldX, int worldZ, int worldSize,
                                      int colour,
                                      double tileMinX, double tileMinZ,
                                      double worldPerPixelX, double worldPerPixelZ) {
        int x0 = (int)Math.floor((worldX - tileMinX) / worldPerPixelX);
        int y0 = (int)Math.floor((worldZ - tileMinZ) / worldPerPixelZ);
        int x1 = (int)Math.ceil((worldX + worldSize - tileMinX) / worldPerPixelX) - 1;
        int y1 = (int)Math.ceil((worldZ + worldSize - tileMinZ) / worldPerPixelZ) - 1;

        if (x1 < x0) x1 = x0;
        if (y1 < y0) y1 = y0;
        if (x1 < 0 || y1 < 0 || x0 >= size || y0 >= size) return;

        x0 = Math.max(0, x0);
        y0 = Math.max(0, y0);
        x1 = Math.min(size - 1, x1);
        y1 = Math.min(size - 1, y1);

        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                image.setRGB(x, y, colour);
            }
        }
    }

    @Override
    public String displayName() {
        return "PJM block map";
    }

    @Override
    public void close() {
        // The service owns the persistent region store.
    }
}
