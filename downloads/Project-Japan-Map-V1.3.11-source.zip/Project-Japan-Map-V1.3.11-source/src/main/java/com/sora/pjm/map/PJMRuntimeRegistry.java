package com.sora.pjm.map;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.ModList;

import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;

/** Shares immutable geographic data between the HUD and both maps. */
final class PJMRuntimeRegistry {
    enum Kind { NONE, PJ, PJR }
    private static final Map<Kind, PJMGeographicRuntime> RUNTIMES = new EnumMap<>(Kind.class);

    private PJMRuntimeRegistry() {}

    static Kind currentKind() {
        Minecraft mc = Minecraft.getInstance();
        String namespace = mc.level == null ? "" : mc.level.dimensionTypeId().location().getNamespace();
        return select(ModList.get().isLoaded("projectjapan"), ModList.get().isLoaded("pjr"), namespace);
    }

    // Dimension types are synchronized to multiplayer clients by vanilla Minecraft.
    // Prefer the actual world over mod loading order when PJ and PJR coexist.
    static Kind select(boolean pj, boolean pjr, String namespace) {
        if ("pjr".equals(namespace)) return pjr ? Kind.PJR : Kind.NONE;
        if ("projectjapan".equals(namespace)) return pj ? Kind.PJ : Kind.NONE;
        if (pj && !pjr) return Kind.PJ;
        if (pjr && !pj) return Kind.PJR;
        return Kind.NONE;
    }

    static synchronized PJMGeographicRuntime open(Kind kind) throws IOException {
        if (kind == Kind.NONE) throw new IOException("No matching PJ/PJR world provider");
        PJMGeographicRuntime previous = RUNTIMES.get(kind);
        if (previous != null) return previous;
        try {
            PJMGeographicRuntime runtime = kind == Kind.PJR
                    ? new PJMProjectJapanRefinedRuntime() : new PJMProjectJapanRuntime();
            RUNTIMES.put(kind, runtime);
            return runtime;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            throw new IOException(kind + " runtime adapter failed: " + e.getMessage(), e);
        }
    }
}
