package com.sora.pjm;

import net.minecraftforge.fml.common.Mod;

/**
 * Project Japan Map entry point.
 *
 * <p>PJM has no gameplay/network component that must be installed on a dedicated server. Client
 * features are registered from the Dist.CLIENT subscribers in {@code com.sora.pjm.client}.</p>
 */
@Mod(PJM.MOD_ID)
public final class PJM {
    public static final String MOD_ID = "pjm";

    public PJM() {
    }
}
