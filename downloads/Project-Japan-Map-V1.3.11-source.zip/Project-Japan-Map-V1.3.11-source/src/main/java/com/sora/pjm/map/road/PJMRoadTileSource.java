package com.sora.pjm.map.road;

import com.sora.pjm.map.PJMMapHeader;
import com.sora.pjm.map.PJMMapSource;
import com.sora.pjm.map.PJMTileKey;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

/** Transparent GTA-like road overlay generated from the compact CityBuild road cache. */
public final class PJMRoadTileSource implements PJMMapSource {
    private static final int CORE_ARGB = 0xEAF3F0E8;
    private static final int OUTLINE_ARGB = 0xB8283035;

    private final PJMMapHeader header;
    private final PJMRoadMapService service;

    public PJMRoadTileSource(PJMMapHeader header, PJMRoadMapService service) {
        this.header = header;
        this.service = service;
    }

    @Override
    public PJMMapHeader header() {
        return header;
    }

    @Override
    public byte[] readTile(PJMTileKey key) throws IOException {
        PJMRoadRegionStore store = service.store();
        if (store == null) return null;
        if (key.zoom() < header.minZoom() || key.zoom() > header.maxZoom()) return null;

        int axis = 1 << key.zoom();
        if (key.x() < 0 || key.y() < 0 || key.x() >= axis || key.y() >= axis) return null;

        int tileSize = header.tileSize();
        double tileWorldWidth = header.worldWidth() / (double)axis;
        double tileWorldHeight = header.worldHeight() / (double)axis;
        double minWorldX = header.minWorldX() + key.x() * tileWorldWidth;
        double minWorldZ = header.minWorldZ() + key.y() * tileWorldHeight;
        double maxWorldX = minWorldX + tileWorldWidth;
        double maxWorldZ = minWorldZ + tileWorldHeight;
        double worldPerPixelX = tileWorldWidth / tileSize;
        double worldPerPixelZ = tileWorldHeight / tileSize;

        int minBlockX = (int)Math.floor(minWorldX) - 1;
        int minBlockZ = (int)Math.floor(minWorldZ) - 1;
        int maxBlockX = (int)Math.ceil(maxWorldX) + 1;
        int maxBlockZ = (int)Math.ceil(maxWorldZ) + 1;

        boolean[] core = new boolean[tileSize * tileSize];
        boolean[] anyRoad = {false};
        List<PJMRoadRegionStore.RegionCoord> regions = store.regionCoordsInWorldRange(
                minBlockX, minBlockZ, maxBlockX, maxBlockZ);

        for (PJMRoadRegionStore.RegionCoord region : regions) {
            store.visitRoadBlocks(region,
                    minBlockX, minBlockZ, maxBlockX, maxBlockZ,
                    (worldX, worldZ) -> {
                        fillBlock(core, tileSize, worldX, worldZ,
                                minWorldX, minWorldZ, worldPerPixelX, worldPerPixelZ);
                        anyRoad[0] = true;
                    });
        }

        if (!anyRoad[0]) return null;

        BufferedImage image = new BufferedImage(tileSize, tileSize, BufferedImage.TYPE_INT_ARGB);
        int outlineRadius = key.zoom() >= 8 ? 2 : 1;

        for (int y = 0; y < tileSize; y++) {
            for (int x = 0; x < tileSize; x++) {
                if (!core[y * tileSize + x]) continue;
                for (int dy = -outlineRadius; dy <= outlineRadius; dy++) {
                    for (int dx = -outlineRadius; dx <= outlineRadius; dx++) {
                        if (dx * dx + dy * dy > outlineRadius * outlineRadius + 1) continue;
                        int px = x + dx;
                        int py = y + dy;
                        if (px < 0 || py < 0 || px >= tileSize || py >= tileSize) continue;
                        image.setRGB(px, py, OUTLINE_ARGB);
                    }
                }
            }
        }

        for (int y = 0; y < tileSize; y++) {
            for (int x = 0; x < tileSize; x++) {
                if (core[y * tileSize + x]) image.setRGB(x, y, CORE_ARGB);
            }
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream(8 * 1024);
        if (!ImageIO.write(image, "PNG", out)) {
            throw new IOException("No PNG writer available");
        }
        return out.toByteArray();
    }

    private static void fillBlock(boolean[] core, int size,
                                  int worldX, int worldZ,
                                  double tileMinX, double tileMinZ,
                                  double worldPerPixelX, double worldPerPixelZ) {
        int x0 = (int)Math.floor((worldX - tileMinX) / worldPerPixelX);
        int y0 = (int)Math.floor((worldZ - tileMinZ) / worldPerPixelZ);
        int x1 = (int)Math.ceil((worldX + 1.0D - tileMinX) / worldPerPixelX) - 1;
        int y1 = (int)Math.ceil((worldZ + 1.0D - tileMinZ) / worldPerPixelZ) - 1;

        // At far zoom a whole road block can be much smaller than one map pixel. Preserve it as
        // one pixel so long continuous roads do not disappear because of rounding.
        if (x1 < x0) x1 = x0;
        if (y1 < y0) y1 = y0;

        if (x1 < 0 || y1 < 0 || x0 >= size || y0 >= size) return;
        x0 = Math.max(0, x0);
        y0 = Math.max(0, y0);
        x1 = Math.min(size - 1, x1);
        y1 = Math.min(size - 1, y1);

        for (int y = y0; y <= y1; y++) {
            int row = y * size;
            for (int x = x0; x <= x1; x++) {
                core[row + x] = true;
            }
        }
    }

    @Override
    public String displayName() {
        return "CityBuild roads";
    }

    @Override
    public void close() {
        // The service owns the persistent region store; individual renderers are disposable.
    }
}
