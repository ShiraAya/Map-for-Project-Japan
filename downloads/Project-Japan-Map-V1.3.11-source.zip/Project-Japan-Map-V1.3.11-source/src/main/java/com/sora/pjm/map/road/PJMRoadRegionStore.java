package com.sora.pjm.map.road;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Compact persistent road cache.
 *
 * <p>One region covers 32x32 Minecraft chunks (512x512 blocks). Each chunk stores a 16x16 road
 * bit-mask, so a complete region is only about 33 KiB before filesystem overhead. This avoids the
 * thousands of tiny files that a per-chunk cache would create on Windows.</p>
 */
final class PJMRoadRegionStore implements AutoCloseable {
    private static final int MAGIC = 0x504A4D52; // PJMR
    private static final int VERSION = 1;
    private static final int REGION_CHUNKS = 32;
    private static final int CHUNKS_PER_REGION = REGION_CHUNKS * REGION_CHUNKS;
    private static final int LONGS_PER_CHUNK = 4; // 256 bits
    private static final int VALID_BYTES = CHUNKS_PER_REGION / 8;
    private static final int MAX_LOADED_REGIONS = 128;
    private static final long FLUSH_DEBOUNCE_MS = 300L;

    private final Path regionDir;
    private final LinkedHashMap<Long, Region> loaded =
            new LinkedHashMap<>(64, 0.75F, true);
    private final Set<Long> knownRegions = new HashSet<>();
    private final Set<Long> pendingFlush = new HashSet<>();
    private final ExecutorService writer;
    private volatile boolean closed;

    PJMRoadRegionStore(Path root) throws IOException {
        regionDir = root.resolve("regions");
        Files.createDirectories(regionDir);

        AtomicInteger id = new AtomicInteger();
        ThreadFactory factory = runnable -> {
            Thread thread = new Thread(runnable, "PJM-Road-Cache-" + id.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        };
        writer = Executors.newSingleThreadExecutor(factory);
        discoverExistingRegions();
    }

    synchronized boolean hasChunk(int chunkX, int chunkZ) {
        Region region = getRegionIfPresent(regionX(chunkX), regionZ(chunkZ));
        return region != null && region.has(localChunkIndex(chunkX, chunkZ));
    }

    /**
     * Stores a road mask and returns true only when the visible road geometry changed.
     * Unknown -> empty does not invalidate rendered map tiles.
     */
    synchronized boolean putChunk(int chunkX, int chunkZ, long[] mask) {
        int rx = regionX(chunkX);
        int rz = regionZ(chunkZ);
        long key = pack(rx, rz);
        Region region = getOrCreateRegion(rx, rz);
        int index = localChunkIndex(chunkX, chunkZ);

        boolean had = region.has(index);
        boolean oldAny = had && region.any(index);
        boolean newAny = any(mask);
        boolean changed = !had || !region.same(index, mask);
        if (!changed) {
            return false;
        }

        region.put(index, mask);
        knownRegions.add(key);
        scheduleFlush(key, region);
        return oldAny != newAny || (oldAny && newAny);
    }

    /**
     * Returns only lightweight region coordinates. Region payloads are loaded one-at-a-time by
     * {@link #visitRoadBlocks}, so a nationwide low-zoom tile cannot pin every matching region in
     * memory at once and bypass the LRU cap.
     */
    synchronized List<RegionCoord> regionCoordsInWorldRange(int minBlockX, int minBlockZ,
                                                             int maxBlockX, int maxBlockZ) {
        int minRx = Math.floorDiv(minBlockX, 512);
        int maxRx = Math.floorDiv(maxBlockX, 512);
        int minRz = Math.floorDiv(minBlockZ, 512);
        int maxRz = Math.floorDiv(maxBlockZ, 512);

        List<RegionCoord> result = new ArrayList<>();
        for (long key : knownRegions) {
            int rx = unpackX(key);
            int rz = unpackZ(key);
            if (rx < minRx || rx > maxRx || rz < minRz || rz > maxRz) continue;
            result.add(new RegionCoord(rx, rz));
        }
        return result;
    }

    private void discoverExistingRegions() throws IOException {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(regionDir, "r.*.*.pjmr")) {
            for (Path path : stream) {
                String[] parts = path.getFileName().toString().split("\\.");
                if (parts.length != 4) continue;
                try {
                    int rx = Integer.parseInt(parts[1]);
                    int rz = Integer.parseInt(parts[2]);
                    knownRegions.add(pack(rx, rz));
                } catch (NumberFormatException ignored) {
                }
            }
        }
    }

    private Region getRegionIfPresent(int rx, int rz) {
        long key = pack(rx, rz);
        Region region = loaded.get(key);
        if (region != null) return region;
        if (!knownRegions.contains(key)) return null;

        Path file = file(rx, rz);
        try {
            region = readRegion(file, rx, rz);
            loaded.put(key, region);
            trimLoadedRegions();
            return region;
        } catch (IOException ignored) {
            // Corrupt road cache is disposable. Treat it as absent and let loaded chunks rebuild it.
            knownRegions.remove(key);
            return null;
        }
    }

    private Region getOrCreateRegion(int rx, int rz) {
        Region existing = getRegionIfPresent(rx, rz);
        if (existing != null) return existing;
        Region created = new Region(rx, rz);
        loaded.put(pack(rx, rz), created);
        trimLoadedRegions();
        return created;
    }


    private void trimLoadedRegions() {
        if (loaded.size() <= MAX_LOADED_REGIONS) return;

        Iterator<Map.Entry<Long, Region>> it = loaded.entrySet().iterator();
        while (loaded.size() > MAX_LOADED_REGIONS && it.hasNext()) {
            Map.Entry<Long, Region> entry = it.next();
            if (pendingFlush.contains(entry.getKey())) continue;
            it.remove();
        }
    }

    private void scheduleFlush(long key, Region region) {
        if (closed || !pendingFlush.add(key)) return;
        writer.execute(() -> flushLoop(key, region));
    }

    private void flushLoop(long key, Region region) {
        try {
            while (!closed) {
                try {
                    Thread.sleep(FLUSH_DEBOUNCE_MS);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    return;
                }

                RegionSnapshot snapshot;
                synchronized (this) {
                    snapshot = region.snapshot();
                }
                writeRegion(snapshot);

                synchronized (this) {
                    if (region.generation == snapshot.generation()) {
                        pendingFlush.remove(key);
                        return;
                    }
                }
            }
        } catch (IOException ignored) {
            synchronized (this) {
                pendingFlush.remove(key);
            }
        }
    }

    private Region readRegion(Path path, int expectedRx, int expectedRz) throws IOException {
        try (DataInputStream in = new DataInputStream(Files.newInputStream(path))) {
            if (in.readInt() != MAGIC || in.readInt() != VERSION) {
                throw new IOException("Unsupported PJM road cache");
            }
            int rx = in.readInt();
            int rz = in.readInt();
            if (rx != expectedRx || rz != expectedRz) {
                throw new IOException("PJM road cache coordinate mismatch");
            }

            Region region = new Region(rx, rz);
            in.readFully(region.valid);
            for (int i = 0; i < region.bits.length; i++) {
                region.bits[i] = in.readLong();
            }
            return region;
        } catch (EOFException e) {
            throw new IOException("Truncated PJM road cache", e);
        }
    }

    private void writeRegion(RegionSnapshot snapshot) throws IOException {
        Path target = file(snapshot.rx(), snapshot.rz());
        Files.createDirectories(target.getParent());
        Path temp = target.resolveSibling(target.getFileName() + ".tmp-" + UUID.randomUUID());
        try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(temp))) {
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(snapshot.rx());
            out.writeInt(snapshot.rz());
            out.write(snapshot.valid());
            for (long value : snapshot.bits()) out.writeLong(value);
        }
        try {
            Files.move(temp, target,
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private Path file(int rx, int rz) {
        return regionDir.resolve("r." + rx + "." + rz + ".pjmr");
    }

    void visitRoadBlocks(RegionCoord ref, int minX, int minZ, int maxX, int maxZ,
                         RoadVisitor visitor) {
        Region region;
        synchronized (this) {
            if (closed) return;
            region = getRegionIfPresent(ref.rx, ref.rz);
        }
        if (region == null) return;

        synchronized (region) {
            for (int chunkIndex = 0; chunkIndex < CHUNKS_PER_REGION; chunkIndex++) {
                if (!region.has(chunkIndex) || !region.any(chunkIndex)) continue;

                int localChunkX = chunkIndex & 31;
                int localChunkZ = chunkIndex >>> 5;
                int chunkBaseX = ref.rx * 512 + localChunkX * 16;
                int chunkBaseZ = ref.rz * 512 + localChunkZ * 16;
                if (chunkBaseX > maxX || chunkBaseX + 15 < minX
                        || chunkBaseZ > maxZ || chunkBaseZ + 15 < minZ) {
                    continue;
                }

                int bitBase = chunkIndex * LONGS_PER_CHUNK;
                for (int word = 0; word < LONGS_PER_CHUNK; word++) {
                    long value = region.bits[bitBase + word];
                    while (value != 0L) {
                        int bit = Long.numberOfTrailingZeros(value);
                        int local = word * 64 + bit;
                        int x = chunkBaseX + (local & 15);
                        int z = chunkBaseZ + (local >>> 4);
                        if (x >= minX && x <= maxX && z >= minZ && z <= maxZ) {
                            visitor.accept(x, z);
                        }
                        value &= value - 1L;
                    }
                }
            }
        }
    }

    @Override
    public void close() {
        List<RegionSnapshot> finalSnapshots = new ArrayList<>();
        synchronized (this) {
            if (closed) return;
            closed = true;
            for (long key : pendingFlush) {
                Region region = loaded.get(key);
                if (region != null) finalSnapshots.add(region.snapshot());
            }
        }

        // Let an already-running atomic write finish before writing the newest snapshot. This
        // guarantees an older worker snapshot can never overwrite the final world-exit flush.
        writer.shutdownNow();
        try {
            writer.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        }

        for (RegionSnapshot snapshot : finalSnapshots) {
            try {
                writeRegion(snapshot);
            } catch (IOException ignored) {
            }
        }

        synchronized (this) {
            loaded.clear();
            knownRegions.clear();
            pendingFlush.clear();
        }
    }

    private static int regionX(int chunkX) {
        return Math.floorDiv(chunkX, REGION_CHUNKS);
    }

    private static int regionZ(int chunkZ) {
        return Math.floorDiv(chunkZ, REGION_CHUNKS);
    }

    private static int localChunkIndex(int chunkX, int chunkZ) {
        int x = Math.floorMod(chunkX, REGION_CHUNKS);
        int z = Math.floorMod(chunkZ, REGION_CHUNKS);
        return z * REGION_CHUNKS + x;
    }

    private static boolean any(long[] mask) {
        for (long value : mask) if (value != 0L) return true;
        return false;
    }

    private static long pack(int x, int z) {
        return ((long)x << 32) ^ (z & 0xffffffffL);
    }

    private static int unpackX(long key) {
        return (int)(key >> 32);
    }

    private static int unpackZ(long key) {
        return (int)key;
    }

    interface RoadVisitor {
        void accept(int worldX, int worldZ);
    }

    static final class RegionCoord {
        final int rx;
        final int rz;

        RegionCoord(int rx, int rz) {
            this.rx = rx;
            this.rz = rz;
        }
    }

    private static final class Region {
        final int rx;
        final int rz;
        final byte[] valid = new byte[VALID_BYTES];
        final long[] bits = new long[CHUNKS_PER_REGION * LONGS_PER_CHUNK];
        int generation;

        Region(int rx, int rz) {
            this.rx = rx;
            this.rz = rz;
        }

        synchronized boolean has(int index) {
            return (valid[index >>> 3] & (1 << (index & 7))) != 0;
        }

        synchronized boolean any(int index) {
            int offset = index * LONGS_PER_CHUNK;
            return bits[offset] != 0L || bits[offset + 1] != 0L
                    || bits[offset + 2] != 0L || bits[offset + 3] != 0L;
        }

        synchronized boolean same(int index, long[] mask) {
            int offset = index * LONGS_PER_CHUNK;
            for (int i = 0; i < LONGS_PER_CHUNK; i++) {
                if (bits[offset + i] != mask[i]) return false;
            }
            return true;
        }

        synchronized void put(int index, long[] mask) {
            valid[index >>> 3] = (byte)(valid[index >>> 3] | (1 << (index & 7)));
            int offset = index * LONGS_PER_CHUNK;
            System.arraycopy(mask, 0, bits, offset, LONGS_PER_CHUNK);
            generation++;
        }

        synchronized RegionSnapshot snapshot() {
            return new RegionSnapshot(rx, rz, valid.clone(), bits.clone(), generation);
        }
    }

    private record RegionSnapshot(int rx, int rz, byte[] valid, long[] bits, int generation) {
    }
}
