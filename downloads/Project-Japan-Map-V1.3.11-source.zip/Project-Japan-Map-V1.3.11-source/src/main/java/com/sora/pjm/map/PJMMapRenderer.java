package com.sora.pjm.map;

import com.sora.pjm.map.mode.PJMMapMode;
import com.sora.pjm.map.mode.PJMMapModeState;
import com.sora.pjm.map.road.PJMRoadMapService;
import com.sora.pjm.map.road.PJMRoadTileSource;
import com.sora.pjm.map.blockmap.PJMBlockMapService;
import com.sora.pjm.map.blockmap.PJMBlockTileSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/**
 * Shared PJM renderer used by both the minimap and the full-screen map.
 *
 * <p>The global mode is read at render time, so both views switch together without recreating the
 * renderer. Geographic terrain, the CityBuild road overlay and the explored block map each keep an
 * independent GPU cache.</p>
 */
public final class PJMMapRenderer implements AutoCloseable {
    private static final double ROAD_MIN_DISPLAY_ZOOM = 3.50D;
    private static final int BLOCKMAP_UNKNOWN_BACKGROUND = 0xFF273137;

    private final Minecraft minecraft;
    private final PJMMapSource mapSource;
    private final PJMTextureCache textureCache;
    private final int roadMaxTextures;
    private final int blockMapMaxTextures;

    private PJMRoadTileSource roadSource;
    private PJMTextureCache roadTextureCache;
    private long roadRevision = Long.MIN_VALUE;

    private PJMBlockTileSource blockMapSource;
    private PJMTextureCache blockMapTextureCache;
    private long blockMapRevision = Long.MIN_VALUE;

    private PJMUploadBudget uploadBudget;
    private PJMMapMode lastMode;

    private double centerWorldX;
    private double centerWorldZ;
    private double zoom;

    private int activeBaseZoom = -1;
    private int fallbackBaseZoom = -1;
    private int activeBlockMapZoom = -1;
    private int fallbackBlockMapZoom = -1;

    public PJMMapRenderer(Minecraft minecraft, PJMMapSource mapSource, int maxGpuTiles) {
        this.minecraft = minecraft;
        this.mapSource = mapSource;
        this.textureCache = new PJMTextureCache(minecraft, mapSource, maxGpuTiles);
        this.roadMaxTextures = Math.max(16, maxGpuTiles / 2);
        this.blockMapMaxTextures = Math.max(16, maxGpuTiles);

        PJMRoadMapService.INSTANCE.ensureWorld(minecraft);
        syncRoadCache();

        PJMMapHeader h = mapSource.header();
        centerWorldX = (h.minWorldX() + h.maxWorldX()) * 0.5;
        centerWorldZ = (h.minWorldZ() + h.maxWorldZ()) * 0.5;
        zoom = h.minZoom();
    }

    public void render(GuiGraphics graphics, int left, int top, int width, int height) {
        if (width <= 0 || height <= 0) return;

        PJMMapMode mode = PJMMapModeState.INSTANCE.mode();
        uploadBudget = new PJMUploadBudget();
        if (lastMode != mode) {
            if (mode == PJMMapMode.MAP) textureCache.beginView(k -> false, k -> 0, uploadBudget);
            if (mode != PJMMapMode.MAP && blockMapTextureCache != null) blockMapTextureCache.beginView(k -> false, k -> 0, uploadBudget);
            if (mode != PJMMapMode.DEFAULT && roadTextureCache != null) roadTextureCache.beginView(k -> false, k -> 0, uploadBudget);
            lastMode = mode;
        }
        PJMMapHeader h = mapSource.header();
        int baseZoom = clamp((int)Math.round(zoom), h.minZoom(), h.maxZoom());

        if (mode == PJMMapMode.MAP) {
            PJMBlockMapService.INSTANCE.ensureWorld(minecraft);
            syncBlockMapCache();
            graphics.fill(left, top, left + width, top + height, BLOCKMAP_UNKNOWN_BACKGROUND);
            graphics.enableScissor(left, top, left + width, top + height);
            renderBlockMapMode(graphics, left, top, width, height, baseZoom, h);
            graphics.disableScissor();
            return;
        }

        graphics.fill(left, top, left + width, top + height, h.backgroundArgb());

        if (activeBaseZoom < 0) {
            activeBaseZoom = baseZoom;
        } else if (baseZoom != activeBaseZoom) {
            fallbackBaseZoom = activeBaseZoom;
            activeBaseZoom = baseZoom;
        }

        graphics.enableScissor(left, top, left + width, top + height);

        // Preserve an uploaded overview across several quick wheel steps. Limit finer fallbacks
        // to one level so a zoom-out cannot iterate thousands of tiny old tiles.
        fallbackBaseZoom = cachedFallback(textureCache, baseZoom, fallbackBaseZoom, h.minZoom());
        // Draw the last geographic zoom from GPU cache only while the new level resolves.
        if (fallbackBaseZoom >= h.minZoom()
                && fallbackBaseZoom <= h.maxZoom()
                && fallbackBaseZoom != baseZoom) {
            renderLevel(graphics, left, top, width, height,
                    fallbackBaseZoom, false, textureCache);
        }

        boolean allResolved = renderLevel(
                graphics, left, top, width, height, baseZoom, true, textureCache);
        if (allResolved) fallbackBaseZoom = -1;

        // Terrain mode stops here. Default mode adds the original V1.1.2 road styling, but only
        // from zoom 3.50 onward as requested.
        if (zoom < ROAD_MIN_DISPLAY_ZOOM && roadTextureCache != null)
            roadTextureCache.beginView(k -> false, k -> 0, uploadBudget);
        if (mode == PJMMapMode.DEFAULT && zoom >= ROAD_MIN_DISPLAY_ZOOM) {
            syncRoadCache();
            if (roadTextureCache != null) {
                renderLevel(graphics, left, top, width, height,
                        baseZoom, true, roadTextureCache);
            }
        }

        graphics.disableScissor();
    }

    private void renderBlockMapMode(GuiGraphics graphics,
                                   int left, int top, int width, int height,
                                   int level, PJMMapHeader h) {
        if (blockMapTextureCache == null) return;

        if (activeBlockMapZoom < 0) {
            activeBlockMapZoom = level;
        } else if (level != activeBlockMapZoom) {
            fallbackBlockMapZoom = activeBlockMapZoom;
            activeBlockMapZoom = level;
        }

        fallbackBlockMapZoom = cachedFallback(blockMapTextureCache, level, fallbackBlockMapZoom, h.minZoom());
        if (fallbackBlockMapZoom >= h.minZoom()
                && fallbackBlockMapZoom <= h.maxZoom()
                && fallbackBlockMapZoom != level) {
            renderLevel(graphics, left, top, width, height,
                    fallbackBlockMapZoom, false, blockMapTextureCache);
        }

        boolean allResolved = renderLevel(graphics, left, top, width, height,
                level, true, blockMapTextureCache);
        if (allResolved) fallbackBlockMapZoom = -1;
    }

    private boolean renderLevel(GuiGraphics graphics,
                                int left, int top, int width, int height,
                                int level, boolean requestMissing,
                                PJMTextureCache cache) {
        PJMMapHeader h = mapSource.header();
        double levelScale = Math.pow(2.0D, zoom - level);
        int tileSize = h.tileSize();
        int tilesPerAxis = 1 << level;
        double mapPixels = tileSize * (double)tilesPerAxis;

        double centerPxX = worldToMapPixelX(centerWorldX, mapPixels);
        double centerPxY = worldToMapPixelY(centerWorldZ, mapPixels);
        double visibleMapWidth = width / levelScale;
        double visibleMapHeight = height / levelScale;
        double mapLeft = centerPxX - visibleMapWidth * 0.5D;
        double mapTop = centerPxY - visibleMapHeight * 0.5D;

        int minTileX = Math.max(0, (int)Math.floor(mapLeft / tileSize));
        int minTileY = Math.max(0, (int)Math.floor(mapTop / tileSize));
        int maxTileX = Math.min(tilesPerAxis - 1,
                (int)Math.floor(Math.nextDown(mapLeft + visibleMapWidth) / tileSize));
        int maxTileY = Math.min(tilesPerAxis - 1,
                (int)Math.floor(Math.nextDown(mapTop + visibleMapHeight) / tileSize));

        if (requestMissing) {
            double centerTileX = centerPxX / tileSize, centerTileY = centerPxY / tileSize;
            cache.beginView(k -> k.zoom() == level && k.x() >= minTileX && k.x() <= maxTileX
                    && k.y() >= minTileY && k.y() <= maxTileY,
                    k -> Math.pow(k.x() + .5 - centerTileX, 2) + Math.pow(k.y() + .5 - centerTileY, 2), uploadBudget);
        }
        boolean allResolved = true;

        for (int tileY = minTileY; tileY <= maxTileY; tileY++) {
            for (int tileX = minTileX; tileX <= maxTileX; tileX++) {
                PJMTileKey key = new PJMTileKey(level, tileX, tileY);
                ResourceLocation texture = requestMissing
                        ? cache.get(key)
                        : cache.getIfPresent(key);

                if (requestMissing && !cache.isResolved(key)) {
                    allResolved = false;
                }

                if (texture == null) continue;

                double sx = left + (tileX * (double)tileSize - mapLeft) * levelScale;
                double sy = top + (tileY * (double)tileSize - mapTop) * levelScale;

                graphics.pose().pushPose();
                graphics.pose().translate((float)sx, (float)sy, 0.0F);
                graphics.pose().scale((float)levelScale, (float)levelScale, 1.0F);
                graphics.blit(texture, 0, 0, 0, 0,
                        tileSize, tileSize, tileSize, tileSize);
                graphics.pose().popPose();
            }
        }

        return allResolved;
    }

    private static int cachedFallback(PJMTextureCache cache, int target, int previous, int minimum) {
        if (previous >= minimum && previous != target && previous <= target + 1
                && previous >= target - 4 && cache.hasLevel(previous)) return previous;
        for (int level = target - 1; level >= Math.max(minimum, target - 4); level--)
            if (cache.hasLevel(level)) return level;
        return -1;
    }

    /** Keeps the road GPU cache hot and invalidates only tiles touched by changed road chunks. */
    private void syncRoadCache() {
        PJMRoadMapService service = PJMRoadMapService.INSTANCE;
        service.ensureWorld(minecraft);
        if (!service.available()) {
            closeRoadCache();
            roadRevision = service.revision();
            return;
        }

        long revision = service.revision();
        if (roadTextureCache == null) {
            roadSource = new PJMRoadTileSource(mapSource.header(), service);
            roadTextureCache = new PJMTextureCache(minecraft, roadSource, roadMaxTextures, 2);
            roadRevision = revision;
            return;
        }
        if (roadRevision == revision) return;

        PJMRoadMapService.ChangeBatch batch = service.changesSince(roadRevision);
        if (batch.fullRefresh()) {
            closeRoadCache();
            roadSource = new PJMRoadTileSource(mapSource.header(), service);
            roadTextureCache = new PJMTextureCache(minecraft, roadSource, roadMaxTextures, 2);
        } else {
            for (PJMRoadMapService.RoadChange change : batch.changes()) {
                int chunkX = change.chunkX();
                int chunkZ = change.chunkZ();
                roadTextureCache.invalidate(key -> tileIntersectsChunk(key, chunkX, chunkZ));
            }
        }
        roadRevision = batch.latestRevision();
    }

    /** Synchronizes the block-map GPU cache without touching geographic or road tiles. */
    private void syncBlockMapCache() {
        PJMBlockMapService service = PJMBlockMapService.INSTANCE;
        service.ensureWorld(minecraft);
        if (!service.available()) {
            closeBlockMapCache();
            blockMapRevision = service.revision();
            return;
        }

        long revision = service.revision();
        if (blockMapTextureCache == null) {
            blockMapSource = new PJMBlockTileSource(mapSource.header(), service);
            // Two small tile workers keep map-mode panning responsive while the scan service remains
            // bounded independently on the client thread.
            blockMapTextureCache = new PJMTextureCache(
                    minecraft, blockMapSource, blockMapMaxTextures, 2);
            blockMapRevision = revision;
            return;
        }
        if (blockMapRevision == revision) return;

        PJMBlockMapService.ChangeBatch batch = service.changesSince(blockMapRevision);
        if (batch.fullRefresh()) {
            closeBlockMapCache();
            blockMapSource = new PJMBlockTileSource(mapSource.header(), service);
            blockMapTextureCache = new PJMTextureCache(
                    minecraft, blockMapSource, blockMapMaxTextures, 2);
            activeBlockMapZoom = -1;
            fallbackBlockMapZoom = -1;
        } else {
            for (PJMBlockMapService.BlockMapChange change : batch.changes()) {
                int chunkX = change.chunkX();
                int chunkZ = change.chunkZ();
                blockMapTextureCache.invalidate(key -> tileIntersectsChunk(key, chunkX, chunkZ));
            }
        }
        blockMapRevision = batch.latestRevision();
    }

    private boolean tileIntersectsChunk(PJMTileKey key, int chunkX, int chunkZ) {
        PJMMapHeader h = mapSource.header();
        int axis = 1 << key.zoom();
        double tileWidth = h.worldWidth() / axis;
        double tileHeight = h.worldHeight() / axis;
        double tileMinX = h.minWorldX() + key.x() * tileWidth;
        double tileMinZ = h.minWorldZ() + key.y() * tileHeight;
        double tileMaxX = tileMinX + tileWidth;
        double tileMaxZ = tileMinZ + tileHeight;
        double chunkMinX = chunkX * 16.0D;
        double chunkMinZ = chunkZ * 16.0D;
        double chunkMaxX = chunkMinX + 16.0D;
        double chunkMaxZ = chunkMinZ + 16.0D;
        return tileMaxX > chunkMinX && tileMinX < chunkMaxX
                && tileMaxZ > chunkMinZ && tileMinZ < chunkMaxZ;
    }

    private void closeRoadCache() {
        if (roadTextureCache != null) {
            try {
                roadTextureCache.close();
            } catch (Exception ignored) {
            }
            roadTextureCache = null;
            roadSource = null;
        }
    }

    private void closeBlockMapCache() {
        if (blockMapTextureCache != null) {
            try {
                blockMapTextureCache.close();
            } catch (Exception ignored) {
            }
            blockMapTextureCache = null;
            blockMapSource = null;
        }
        activeBlockMapZoom = -1;
        fallbackBlockMapZoom = -1;
    }

    public void panPixels(double dragPixelsX, double dragPixelsY) {
        PJMMapHeader h = mapSource.header();
        double fullMapPixels = h.tileSize() * Math.pow(2.0D, zoom);
        centerWorldX -= dragPixelsX * h.worldWidth() / fullMapPixels;
        centerWorldZ -= dragPixelsY * h.worldHeight() / fullMapPixels;
        clampCenter();
    }

    public void zoomAt(double mouseX, double mouseY, double wheelDelta,
                       int left, int top, int width, int height) {
        WorldPoint before = screenToWorld(mouseX, mouseY, left, top, width, height);
        PJMMapHeader h = mapSource.header();
        zoom = clamp(zoom + wheelDelta * 0.25D, h.minZoom(), h.maxZoom());
        WorldPoint after = screenToWorld(mouseX, mouseY, left, top, width, height);
        centerWorldX += before.x() - after.x();
        centerWorldZ += before.z() - after.z();
        clampCenter();
    }

    public WorldPoint screenToWorld(double screenX, double screenY,
                                    int left, int top, int width, int height) {
        PJMMapHeader h = mapSource.header();
        double fullMapPixels = h.tileSize() * Math.pow(2.0D, zoom);
        double worldPerPixelX = h.worldWidth() / fullMapPixels;
        double worldPerPixelZ = h.worldHeight() / fullMapPixels;
        double dx = screenX - (left + width * 0.5D);
        double dy = screenY - (top + height * 0.5D);
        return new WorldPoint(centerWorldX + dx * worldPerPixelX,
                centerWorldZ + dy * worldPerPixelZ);
    }

    public ScreenPoint worldToScreen(double worldX, double worldZ,
                                     int left, int top, int width, int height) {
        PJMMapHeader h = mapSource.header();
        double fullMapPixels = h.tileSize() * Math.pow(2.0D, zoom);
        double pixelsPerWorldX = fullMapPixels / h.worldWidth();
        double pixelsPerWorldZ = fullMapPixels / h.worldHeight();
        return new ScreenPoint(
                left + width * 0.5D + (worldX - centerWorldX) * pixelsPerWorldX,
                top + height * 0.5D + (worldZ - centerWorldZ) * pixelsPerWorldZ);
    }

    public void centerOn(double worldX, double worldZ) {
        centerWorldX = worldX;
        centerWorldZ = worldZ;
        clampCenter();
    }

    public void fitToViewport(int width, int height) {
        PJMMapHeader h = mapSource.header();
        double fitPixels = Math.max(1.0D, Math.min(width, height));
        double rawZoom = Math.log(fitPixels / h.tileSize()) / Math.log(2.0D);
        zoom = clamp(rawZoom, h.minZoom(), h.maxZoom());
    }

    public double zoom() {
        return zoom;
    }

    public void setZoom(double zoom) {
        PJMMapHeader h = mapSource.header();
        this.zoom = clamp(zoom, h.minZoom(), h.maxZoom());
    }

    public void setZoomForWorldSpan(int viewportPixels, double worldSpanBlocks) {
        PJMMapHeader h = mapSource.header();
        if (viewportPixels <= 0 || worldSpanBlocks <= 0.0D) return;

        double pixelsPerWorld = viewportPixels / worldSpanBlocks;
        double fullMapPixels = pixelsPerWorld * h.worldWidth();
        double targetZoom = Math.log(fullMapPixels / h.tileSize()) / Math.log(2.0D);
        zoom = clamp(targetZoom, h.minZoom(), h.maxZoom());
    }

    public PJMMapHeader header() {
        return mapSource.header();
    }

    public int pendingTileCount() {
        PJMMapMode mode = PJMMapModeState.INSTANCE.mode();
        if (mode == PJMMapMode.MAP) {
            return blockMapTextureCache == null ? 0 : blockMapTextureCache.pendingCount();
        }
        int pending = textureCache.pendingCount();
        if (mode == PJMMapMode.DEFAULT && roadTextureCache != null) {
            pending += roadTextureCache.pendingCount();
        }
        return pending;
    }

    private double worldToMapPixelX(double worldX, double mapPixels) {
        PJMMapHeader h = mapSource.header();
        return (worldX - h.minWorldX()) / h.worldWidth() * mapPixels;
    }

    private double worldToMapPixelY(double worldZ, double mapPixels) {
        PJMMapHeader h = mapSource.header();
        return (worldZ - h.minWorldZ()) / h.worldHeight() * mapPixels;
    }

    private void clampCenter() {
        PJMMapHeader h = mapSource.header();
        centerWorldX = clamp(centerWorldX, h.minWorldX(), h.maxWorldX());
        centerWorldZ = clamp(centerWorldZ, h.minWorldZ(), h.maxWorldZ());
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public void close() throws java.io.IOException {
        closeRoadCache();
        closeBlockMapCache();
        textureCache.close();
    }

    public record WorldPoint(double x, double z) {
    }

    public record ScreenPoint(double x, double y) {
    }
}
