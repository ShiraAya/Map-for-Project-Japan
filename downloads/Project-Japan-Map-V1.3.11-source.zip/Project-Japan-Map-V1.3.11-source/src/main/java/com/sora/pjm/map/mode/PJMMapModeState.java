package com.sora.pjm.map.mode;

/**
 * Process-wide client display mode. Both map renderers read this singleton state, so changing the
 * mode from gameplay or from the full-screen map immediately keeps the two views synchronized.
 */
public final class PJMMapModeState {
    public static final PJMMapModeState INSTANCE = new PJMMapModeState();

    private volatile PJMMapMode mode = PJMMapMode.DEFAULT;

    private PJMMapModeState() {
    }

    public PJMMapMode mode() {
        return mode;
    }

    public PJMMapMode cycle() {
        mode = mode.next();
        return mode;
    }
}
