package com.sora.pjm.map.blockmap;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Persistent explored-block-map cache used by the normal block-colour map mode.
 *
 * <p>One region covers 32x32 Minecraft chunks. Each known chunk stores the 16x16 top-surface ARGB
 * colours (1 KiB). A completely explored region is therefore about 1 MiB, while the file count
 * remains small. Writes are debounced and performed on one background thread so walking through a
 * city does not rewrite a one-megabyte region every client tick.</p>
 */
final class PJMBlockRegionStore implements AutoCloseable {
    private static final int MAGIC = 0x504A4D42; // PJMB
    private static final int VERSION = 1;
    private static final int REGION_CHUNKS = 32;
    private static final int CHUNKS_PER_REGION = REGION_CHUNKS * REGION_CHUNKS;
    private static final int PIXELS_PER_CHUNK = 16 * 16;
    private static final int VALID_BYTES = CHUNKS_PER_REGION / 8;
    private static final int MAX_LOADED_REGIONS = 24;
    private static final long FLUSH_DEBOUNCE_MS = 1500L;

    private final Path regionDir;
    private final LinkedHashMap<Long, Region> loaded =
            new LinkedHashMap<>(16, 0.75F, true);
    private final Set<Long> knownRegions = new HashSet<>();
    private final Map<Long, byte[]> knownValid = new java.util.HashMap<>();
    private final Set<Long> pendingFlush = new HashSet<>();
    private final ExecutorService writer;
    private volatile boolean closed;

    PJMBlockRegionStore(Path root) throws IOException {
        regionDir = root.resolve("regions");
        Files.createDirectories(regionDir);

        AtomicInteger id = new AtomicInteger();
        ThreadFactory factory = runnable -> {
            Thread thread = new Thread(runnable, "PJM-BlockMap-Cache-" + id.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        };
        writer = Executors.newSingleThreadExecutor(factory);
        discoverExistingRegions();
    }

    synchronized boolean hasChunk(int chunkX, int chunkZ) {
        int rx = regionX(chunkX);
        int rz = regionZ(chunkZ);
        long key = pack(rx, rz);
        int index = localChunkIndex(chunkX, chunkZ);

        Region loadedRegion = loaded.get(key);
        if (loadedRegion != null) {
            synchronized (loadedRegion) {
                return loadedRegion.has(index);
            }
        }

        byte[] valid = knownValid.get(key);
        if (valid == null) return false;
        int mask = 1 << (index & 7);
        return (valid[index >>> 3] & mask) != 0;
    }

    /** Stores one complete 16x16 top-surface colour raster. */
    synchronized boolean putChunk(int chunkX, int chunkZ, int[] colours) {
        if (colours == null || colours.length != PIXELS_PER_CHUNK) {
            throw new IllegalArgumentException("Block-map chunk must contain exactly 256 colours");
        }

        int rx = regionX(chunkX);
        int rz = regionZ(chunkZ);
        long key = pack(rx, rz);
        Region region = getOrCreateRegion(rx, rz);
        int index = localChunkIndex(chunkX, chunkZ);

        boolean changed;
        synchronized (region) {
            changed = !region.has(index) || !region.same(index, colours);
            if (!changed) return false;
            region.put(index, colours);
        }

        knownRegions.add(key);
        byte[] validSummary = knownValid.computeIfAbsent(key, unused -> new byte[VALID_BYTES]);
        int validIndex = localChunkIndex(chunkX, chunkZ);
        validSummary[validIndex >>> 3] |= (byte)(1 << (validIndex & 7));
        scheduleFlush(key, region);
        return true;
    }

    synchronized List<RegionCoord> regionCoordsInWorldRange(int minBlockX, int minBlockZ,
                                                             int maxBlockX, int maxBlockZ) {
        int minRx = Math.floorDiv(minBlockX, 512);
        int maxRx = Math.floorDiv(maxBlockX, 512);
        int minRz = Math.floorDiv(minBlockZ, 512);
        int maxRz = Math.floorDiv(maxBlockZ, 512);

        List<RegionCoord> result = new ArrayList<>();
        for (long key : knownRegions) {
            int rx = unpackX(key);
            int rz = unpackZ(key);
            if (rx < minRx || rx > maxRx || rz < minRz || rz > maxRz) continue;
            result.add(new RegionCoord(rx, rz));
        }
        return result;
    }

    /**
     * Visits cached chunks intersecting the requested block range. The supplied arrays are owned by
     * the store and are valid only during the callback; callers must not retain them.
     */
    void visitBlockChunks(RegionCoord ref, int minX, int minZ, int maxX, int maxZ,
                            BlockChunkVisitor visitor) {
        Region region;
        synchronized (this) {
            if (closed) return;
            region = getRegionIfPresent(ref.rx, ref.rz);
        }
        if (region == null) return;

        synchronized (region) {
            for (int chunkIndex = 0; chunkIndex < CHUNKS_PER_REGION; chunkIndex++) {
                if (!region.has(chunkIndex)) continue;

                int localChunkX = chunkIndex & 31;
                int localChunkZ = chunkIndex >>> 5;
                int chunkX = ref.rx * REGION_CHUNKS + localChunkX;
                int chunkZ = ref.rz * REGION_CHUNKS + localChunkZ;
                int chunkBaseX = chunkX << 4;
                int chunkBaseZ = chunkZ << 4;
                if (chunkBaseX > maxX || chunkBaseX + 15 < minX
                        || chunkBaseZ > maxZ || chunkBaseZ + 15 < minZ) {
                    continue;
                }

                visitor.accept(chunkX, chunkZ,
                        region.colours, chunkIndex * PIXELS_PER_CHUNK,
                        region.chunkAverage[chunkIndex],
                        region.quadrantAverage, chunkIndex * 16);
            }
        }
    }

    private void discoverExistingRegions() throws IOException {
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(regionDir, "r.*.*.pjmb")) {
            for (Path path : stream) {
                String[] parts = path.getFileName().toString().split("\\.");
                if (parts.length != 4) continue;
                try {
                    int rx = Integer.parseInt(parts[1]);
                    int rz = Integer.parseInt(parts[2]);
                    byte[] valid = readValidHeader(path, rx, rz);
                    long key = pack(rx, rz);
                    knownRegions.add(key);
                    knownValid.put(key, valid);
                } catch (NumberFormatException | IOException ignored) {
                    // Invalid disposable cache files are simply not indexed.
                }
            }
        }
    }

    private byte[] readValidHeader(Path path, int expectedRx, int expectedRz) throws IOException {
        try (DataInputStream in = new DataInputStream(Files.newInputStream(path))) {
            if (in.readInt() != MAGIC || in.readInt() != VERSION) {
                throw new IOException("Unsupported PJM block-map cache");
            }
            int rx = in.readInt();
            int rz = in.readInt();
            if (rx != expectedRx || rz != expectedRz) {
                throw new IOException("PJM block-map cache coordinate mismatch");
            }
            byte[] valid = new byte[VALID_BYTES];
            in.readFully(valid);
            return valid;
        }
    }

    private Region getRegionIfPresent(int rx, int rz) {
        long key = pack(rx, rz);
        Region region = loaded.get(key);
        if (region != null) return region;
        if (!knownRegions.contains(key)) return null;

        try {
            region = readRegion(file(rx, rz), rx, rz);
            loaded.put(key, region);
            trimLoadedRegions();
            return region;
        } catch (IOException ignored) {
            // Block-map cache is disposable. Corrupt files are ignored and rebuilt from loaded chunks.
            knownRegions.remove(key);
            knownValid.remove(key);
            return null;
        }
    }

    private Region getOrCreateRegion(int rx, int rz) {
        Region existing = getRegionIfPresent(rx, rz);
        if (existing != null) return existing;
        Region created = new Region(rx, rz);
        loaded.put(pack(rx, rz), created);
        trimLoadedRegions();
        return created;
    }

    private void trimLoadedRegions() {
        if (loaded.size() <= MAX_LOADED_REGIONS) return;
        Iterator<Map.Entry<Long, Region>> it = loaded.entrySet().iterator();
        while (loaded.size() > MAX_LOADED_REGIONS && it.hasNext()) {
            Map.Entry<Long, Region> entry = it.next();
            if (pendingFlush.contains(entry.getKey())) continue;
            it.remove();
        }
    }

    private void scheduleFlush(long key, Region region) {
        if (closed || !pendingFlush.add(key)) return;
        writer.execute(() -> flushLoop(key, region));
    }

    private void flushLoop(long key, Region region) {
        try {
            while (!closed) {
                try {
                    Thread.sleep(FLUSH_DEBOUNCE_MS);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    return;
                }

                RegionSnapshot snapshot;
                synchronized (region) {
                    snapshot = region.snapshot();
                }
                writeRegion(snapshot);

                synchronized (this) {
                    synchronized (region) {
                        if (region.generation == snapshot.generation()) {
                            pendingFlush.remove(key);
                            trimLoadedRegions();
                            return;
                        }
                    }
                }
            }
        } catch (IOException ignored) {
            synchronized (this) {
                pendingFlush.remove(key);
                trimLoadedRegions();
            }
        }
    }

    private Region readRegion(Path path, int expectedRx, int expectedRz) throws IOException {
        try (DataInputStream in = new DataInputStream(Files.newInputStream(path))) {
            if (in.readInt() != MAGIC || in.readInt() != VERSION) {
                throw new IOException("Unsupported PJM block-map cache");
            }
            int rx = in.readInt();
            int rz = in.readInt();
            if (rx != expectedRx || rz != expectedRz) {
                throw new IOException("PJM block-map cache coordinate mismatch");
            }

            Region region = new Region(rx, rz);
            in.readFully(region.valid);
            for (int i = 0; i < region.colours.length; i++) {
                region.colours[i] = in.readInt();
            }
            region.rebuildSummaries();
            return region;
        } catch (EOFException e) {
            throw new IOException("Truncated PJM block-map cache", e);
        }
    }

    private void writeRegion(RegionSnapshot snapshot) throws IOException {
        Path target = file(snapshot.rx(), snapshot.rz());
        Files.createDirectories(target.getParent());
        Path temp = target.resolveSibling(target.getFileName() + ".tmp-" + UUID.randomUUID());
        try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(temp))) {
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(snapshot.rx());
            out.writeInt(snapshot.rz());
            out.write(snapshot.valid());
            for (int colour : snapshot.colours()) out.writeInt(colour);
        }
        try {
            Files.move(temp, target,
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private Path file(int rx, int rz) {
        return regionDir.resolve("r." + rx + "." + rz + ".pjmb");
    }

    @Override
    public void close() {
        List<RegionSnapshot> finalSnapshots = new ArrayList<>();
        synchronized (this) {
            if (closed) return;
            closed = true;
            for (long key : pendingFlush) {
                Region region = loaded.get(key);
                if (region != null) {
                    synchronized (region) {
                        finalSnapshots.add(region.snapshot());
                    }
                }
            }
        }

        writer.shutdownNow();
        try {
            writer.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        }

        for (RegionSnapshot snapshot : finalSnapshots) {
            try {
                writeRegion(snapshot);
            } catch (IOException ignored) {
            }
        }

        synchronized (this) {
            loaded.clear();
            knownRegions.clear();
            knownValid.clear();
            pendingFlush.clear();
        }
    }

    private static int regionX(int chunkX) {
        return Math.floorDiv(chunkX, REGION_CHUNKS);
    }

    private static int regionZ(int chunkZ) {
        return Math.floorDiv(chunkZ, REGION_CHUNKS);
    }

    private static int localChunkIndex(int chunkX, int chunkZ) {
        int x = Math.floorMod(chunkX, REGION_CHUNKS);
        int z = Math.floorMod(chunkZ, REGION_CHUNKS);
        return z * REGION_CHUNKS + x;
    }

    private static long pack(int x, int z) {
        return ((long)x << 32) ^ (z & 0xffffffffL);
    }

    private static int unpackX(long key) {
        return (int)(key >> 32);
    }

    private static int unpackZ(long key) {
        return (int)key;
    }

    interface BlockChunkVisitor {
        void accept(int chunkX, int chunkZ,
                    int[] colours, int colourOffset,
                    int chunkAverage,
                    int[] quadrantAverage, int quadrantOffset);
    }

    static final class RegionCoord {
        final int rx;
        final int rz;

        RegionCoord(int rx, int rz) {
            this.rx = rx;
            this.rz = rz;
        }
    }

    private static final class Region {
        final int rx;
        final int rz;
        final byte[] valid = new byte[VALID_BYTES];
        final int[] colours = new int[CHUNKS_PER_REGION * PIXELS_PER_CHUNK];
        final int[] chunkAverage = new int[CHUNKS_PER_REGION];
        final int[] quadrantAverage = new int[CHUNKS_PER_REGION * 16];
        long generation;

        Region(int rx, int rz) {
            this.rx = rx;
            this.rz = rz;
        }

        boolean has(int index) {
            int mask = 1 << (index & 7);
            return (valid[index >>> 3] & mask) != 0;
        }

        boolean same(int index, int[] incoming) {
            int offset = index * PIXELS_PER_CHUNK;
            for (int i = 0; i < PIXELS_PER_CHUNK; i++) {
                if (colours[offset + i] != incoming[i]) return false;
            }
            return true;
        }

        void put(int index, int[] incoming) {
            int offset = index * PIXELS_PER_CHUNK;
            System.arraycopy(incoming, 0, colours, offset, PIXELS_PER_CHUNK);
            valid[index >>> 3] |= (byte)(1 << (index & 7));
            rebuildSummary(index);
            generation++;
        }

        void rebuildSummaries() {
            for (int index = 0; index < CHUNKS_PER_REGION; index++) {
                if (has(index)) rebuildSummary(index);
            }
        }

        void rebuildSummary(int index) {
            int base = index * PIXELS_PER_CHUNK;
            chunkAverage[index] = average(colours, base, 0, 0, 16, 16);
            int qBase = index * 16;
            for (int qz = 0; qz < 4; qz++) {
                for (int qx = 0; qx < 4; qx++) {
                    quadrantAverage[qBase + qz * 4 + qx] =
                            average(colours, base, qx * 4, qz * 4, 4, 4);
                }
            }
        }

        RegionSnapshot snapshot() {
            return new RegionSnapshot(rx, rz, generation,
                    Arrays.copyOf(valid, valid.length),
                    Arrays.copyOf(colours, colours.length));
        }

        private static int average(int[] source, int base,
                                   int startX, int startZ, int width, int height) {
            long r = 0L, g = 0L, b = 0L;
            int count = 0;
            for (int z = startZ; z < startZ + height; z++) {
                int row = base + z * 16;
                for (int x = startX; x < startX + width; x++) {
                    int argb = source[row + x];
                    if ((argb >>> 24) == 0) continue;
                    r += (argb >>> 16) & 0xFF;
                    g += (argb >>> 8) & 0xFF;
                    b += argb & 0xFF;
                    count++;
                }
            }
            if (count == 0) return 0;
            return 0xFF000000
                    | ((int)(r / count) << 16)
                    | ((int)(g / count) << 8)
                    | (int)(b / count);
        }
    }

    private record RegionSnapshot(int rx, int rz, long generation,
                                  byte[] valid, int[] colours) {
    }
}
