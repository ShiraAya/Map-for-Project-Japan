package com.sora.pjm.map;

import net.minecraftforge.fml.loading.FMLPaths;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.UUID;
import java.util.Properties;
import java.util.List;
import java.util.ArrayList;
import java.io.InputStream;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runtime-generated map synchronized with the active PJ or PJR geographic provider.
 * Rivers use the provider's solved centre-lines, with exact PJR water queries at local zoom.
 * Lake shorelines are always sampled through the selected adapter's runtime water predicate.
 */
public final class PJMProjectJapanMapSource implements PJMMapSource {
    private static final int TILE_SIZE = 256;
    private static final int MIN_ZOOM = 0;
    private static final int MAX_ZOOM = 12;

    /** Separate rendering revision; provider IDs and data fingerprints isolate cache contents. */
    private static final String CACHE_RENDER_REVISION = "render-v10-river-coverage";

    private static final int OCEAN_ARGB = 0xFF6E97AD;
    private static final int RIVER_ARGB = 0xFF4E9FC8;
    private static final int LAKE_ARGB = 0xFF5B9DBB;

    private final PJMGeographicRuntime runtime;
    private final PJMMapHeader header;
    private final Path cacheDir;
    private final List<Path> compatibleCacheDirs;
    private final String displayName;
    private final Properties bundledTiles = new Properties();
    private static final String BUNDLED_ROOT = "/assets/pjm/precomputed/";
    private static final Set<Path> CLEANUP_SCHEDULED = ConcurrentHashMap.newKeySet();

    public static PJMProjectJapanMapSource open() throws IOException {
        return new PJMProjectJapanMapSource(PJMRuntimeRegistry.open(PJMRuntimeRegistry.currentKind()));
    }

    private PJMProjectJapanMapSource(PJMGeographicRuntime runtime) throws IOException {
        this(runtime, FMLPaths.CONFIGDIR.get().resolve("PJM").resolve("cache"));
    }

    PJMProjectJapanMapSource(PJMGeographicRuntime runtime, Path root) throws IOException {
        this.runtime = runtime;

        int minX = Math.min(runtime.minWorldX(), runtime.maxWorldX());
        int maxX = Math.max(runtime.minWorldX(), runtime.maxWorldX());
        int minZ = Math.min(runtime.minWorldZ(), runtime.maxWorldZ());
        int maxZ = Math.max(runtime.minWorldZ(), runtime.maxWorldZ());

        int maxZoom = MAX_ZOOM + Math.max(0, (int)Math.ceil(Math.log(runtime.footprintScale()) / Math.log(2)));
        header = new PJMMapHeader(1, TILE_SIZE, MIN_ZOOM, maxZoom,
                minX, minZ, maxX, maxZ, 0L, 0, OCEAN_ARGB);
        displayName = runtime.displayName() + " " + runtime.version() + " · 自动生成";
        if (!Boolean.getBoolean("pjm.skipBundledTiles")) {
            try (InputStream in = getClass().getResourceAsStream(BUNDLED_ROOT + "index.properties")) {
                if (in != null) bundledTiles.load(in);
            }
            if (!runtime.modId().equals(bundledTiles.getProperty("provider"))
                    || !runtime.fingerprint().equals(bundledTiles.getProperty("fingerprint"))
                    || !CACHE_RENDER_REVISION.equals(bundledTiles.getProperty("renderer"))) bundledTiles.clear();
        }

        root = root.resolve(runtime.modId());
        cacheDir = root.resolve(CACHE_RENDER_REVISION + "-" + runtime.fingerprint());
        // This list is trusted only after the full current data/renderer fingerprint matched.
        // Preserve known pixel-equivalent disk caches, including unbundled local zooms.
        List<Path> compatible = new ArrayList<>();
        for (String old : bundledTiles.getProperty("legacyFingerprints", "").split(",")) {
            if (old.matches("[0-9a-f]{20}") && !old.equals(runtime.fingerprint()))
                compatible.add(root.resolve(CACHE_RENDER_REVISION + "-" + old));
        }
        compatibleCacheDirs = List.copyOf(compatible);
        Files.createDirectories(cacheDir);
        if (CLEANUP_SCHEDULED.add(cacheDir.toAbsolutePath().normalize())) {
            Path cacheRoot = root;
            Thread cleanup = new Thread(() -> cleanupOldAutomaticCaches(cacheRoot, cacheDir, compatibleCacheDirs), "PJM-Cache-Cleanup");
            cleanup.setDaemon(true);
            cleanup.start();
        }
    }

    @Override
    public PJMMapHeader header() {
        return header;
    }

    @Override
    public String displayName() {
        return displayName;
    }

    @Override
    public byte[] readTile(PJMTileKey key) throws IOException {
        PJMAsyncTileLoader.checkCancelled();
        if (key.zoom() < MIN_ZOOM || key.zoom() > header.maxZoom()) return null;
        int axis = 1 << key.zoom();
        if (key.x() < 0 || key.y() < 0 || key.x() >= axis || key.y() >= axis) return null;

        String bundledKey = key.zoom() + "/" + key.x() + "/" + key.y();
        String bundled = bundledTiles.getProperty(bundledKey);
        if ("empty".equals(bundled)) return null;
        if ("png".equals(bundled)) {
            try (InputStream in = getClass().getResourceAsStream(BUNDLED_ROOT + bundledKey + ".png")) {
                if (in != null) return in.readAllBytes();
            }
        }

        Path png = tilePath(key, ".png");
        Path empty = tilePath(key, ".empty");

        if (Files.isRegularFile(png)) return Files.readAllBytes(png);
        if (Files.isRegularFile(empty)) return null;

        for (Path compatible : compatibleCacheDirs) {
            Path oldPng = compatible.resolve(cacheDir.relativize(png));
            if (Files.isRegularFile(oldPng)) return Files.readAllBytes(oldPng);
            if (Files.isRegularFile(compatible.resolve(cacheDir.relativize(empty)))) return null;
        }

        byte[] generated = generateTile(key);
        PJMAsyncTileLoader.checkCancelled();
        Files.createDirectories(png.getParent());

        if (generated == null) {
            try {
                Files.createFile(empty);
            } catch (java.nio.file.FileAlreadyExistsException ignored) {
            }
            return null;
        }

        Path temp = png.resolveSibling(png.getFileName() + ".tmp-" + UUID.randomUUID());
        Files.write(temp, generated);
        try {
            Files.move(temp, png,
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
            Files.move(temp, png, StandardCopyOption.REPLACE_EXISTING);
        }
        return generated;
    }

    private byte[] generateTile(PJMTileKey key) throws IOException {
        BufferedImage image =
                new BufferedImage(TILE_SIZE, TILE_SIZE, BufferedImage.TYPE_INT_ARGB);
        boolean[] landMask = new boolean[TILE_SIZE * TILE_SIZE];

        int axis = 1 << key.zoom();
        double mapPixels = TILE_SIZE * (double) axis;
        double worldPerPixelX = header.worldWidth() / mapPixels;
        double worldPerPixelZ = header.worldHeight() / mapPixels;
        long globalPixelX = (long) key.x() * TILE_SIZE;
        long globalPixelY = (long) key.y() * TILE_SIZE;

        boolean anyLand = false, anyLake = false;
        int[] surveyed = new int[TILE_SIZE * TILE_SIZE];
        boolean exactRivers = runtime.exactLocalRivers()
                && Math.max(worldPerPixelX, worldPerPixelZ) <= 4.0D
                || !runtime.vectorRiversAvailable() && key.zoom() >= 8;

        // Visit nearby pixels together at every scale. PJR 0.1.15+ reconstructs bounded
        // offline atlas tiles; full-width, multi-pass scans repeatedly evicted those tiles.
        // All geographic predicates below are unchanged and sampled at the same coordinates.
        for (int order = 0; order < TILE_SIZE * TILE_SIZE; order++) {
            PJMAsyncTileLoader.checkCancelled();
            int px = compactBits(order), py = compactBits(order >>> 1);
            int idx = py * TILE_SIZE + px;
            VisualAggregate terrain = key.zoom() <= 2
                    ? sampleOverview(globalPixelX + px, globalPixelY + py, worldPerPixelX, worldPerPixelZ)
                    : sampleCentre(globalPixelX + px, globalPixelY + py, worldPerPixelX, worldPerPixelZ);
            int argb = OCEAN_ARGB;
            if (terrain.landFraction() > 0.0D) {
                argb = terrainColor(terrain.elevationMetres());
                landMask[idx] = true;
                anyLand = true;
                if (key.zoom() <= 2) argb = blend(OCEAN_ARGB, argb, Math.max(0.38D, terrain.landFraction()));
                else if (key.zoom() <= 5 && terrain.coverage() < 0.98D)
                    argb = blend(OCEAN_ARGB, argb, clamp01(terrain.coverage()));
            }
            if (lakePixel(key.zoom(), globalPixelX + px, globalPixelY + py, worldPerPixelX, worldPerPixelZ)) {
                argb = LAKE_ARGB;
                anyLake = true;
            }
            int x = (int)Math.floor(header.minWorldX() + (globalPixelX + px + .5D) * worldPerPixelX);
            int z = (int)Math.floor(header.minWorldZ() + (globalPixelY + py + .5D) * worldPerPixelZ);
            if (exactRivers && landMask[idx] && runtime.riverWater(x, z)) argb = RIVER_ARGB;
            surveyed[idx] = switch (runtime.surveyedWater(x, z)) {
                case UNMAPPED -> 0;
                case DRY -> terrainColor(runtime.terrain(x, z).elevationMetres());
                case OCEAN -> OCEAN_ARGB;
                case RIVER -> RIVER_ARGB;
                case LAKE -> LAKE_ARGB;
            };
            image.setRGB(px, py, argb);
        }
        if (!anyLand && !anyLake) return null;
        if (!exactRivers) renderVectorRivers(image, landMask, key, globalPixelX, globalPixelY,
                worldPerPixelX, worldPerPixelZ);
        // Coarse river strokes represent coverage across a pixel, not just its centre.
        // A dry centre cannot erase a river crossing another part of that pixel.
        // Exact local tiles retain centre sampling; ocean/lake ownership still wins.
        for (int i = 0; i < surveyed.length; i++) {
            int survey = surveyed[i];
            if (survey == 0) continue;
            int px = i % TILE_SIZE, py = i / TILE_SIZE;
            boolean dry = survey != OCEAN_ARGB && survey != RIVER_ARGB && survey != LAKE_ARGB;
            if (!exactRivers && dry && image.getRGB(px, py) == RIVER_ARGB) continue;
            image.setRGB(px, py, survey);
        }
        PJMAsyncTileLoader.checkCancelled();

        ByteArrayOutputStream out = new ByteArrayOutputStream(24 * 1024);
        if (!ImageIO.write(image, "PNG", out)) {
            throw new IOException("No PNG writer available");
        }
        return out.toByteArray();
    }

    private static int compactBits(int value) {
        value &= 0x5555;
        value = (value | value >>> 1) & 0x3333;
        value = (value | value >>> 2) & 0x0F0F;
        return (value | value >>> 4) & 0xFF;
    }

    private VisualAggregate sampleOverview(long globalPx, long globalPy,
                                           double worldPerPixelX, double worldPerPixelZ) throws IOException {
        double[] offsets = {0.25D, 0.75D};
        int landSamples = 0;
        double elevation = 0.0D;
        double coverage = 0.0D;

        for (double oy : offsets) {
            for (double ox : offsets) {
                PJMAsyncTileLoader.checkCancelled();
                double worldX = header.minWorldX() + (globalPx + ox) * worldPerPixelX;
                double worldZ = header.minWorldZ() + (globalPy + oy) * worldPerPixelZ;
                double u = (worldX - header.minWorldX()) / header.worldWidth();
                double v = (worldZ - header.minWorldZ()) / header.worldHeight();
                PJMGeographicRuntime.VisualTerrain t = runtime.visualTerrain(u, v);
                coverage += t.coverage();
                if (t.land()) {
                    landSamples++;
                    elevation += t.elevationMetres();
                }
            }
        }

        return new VisualAggregate(
                landSamples / 4.0D,
                landSamples == 0 ? 0 : (int)Math.round(elevation / landSamples),
                coverage / 4.0D);
    }

    private VisualAggregate sampleCentre(long globalPx, long globalPy,
                                         double worldPerPixelX, double worldPerPixelZ) {
        double worldX = header.minWorldX() + (globalPx + 0.5D) * worldPerPixelX;
        double worldZ = header.minWorldZ() + (globalPy + 0.5D) * worldPerPixelZ;
        double u = (worldX - header.minWorldX()) / header.worldWidth();
        double v = (worldZ - header.minWorldZ()) / header.worldHeight();
        PJMGeographicRuntime.VisualTerrain t = runtime.visualTerrain(u, v);
        return new VisualAggregate(t.land() ? 1.0D : 0.0D,
                t.elevationMetres(), t.coverage());
    }

    /**
     * Samples the selected provider's water result directly.
     *
     * <p>At z0-z3 one output pixel covers a very large world footprint, so four stratified samples
     * are used. A pixel becomes lake if any sub-sample is actual PJ lake water. This is only
     * pixel-coverage preservation; there is no ellipse reconstruction or artificial lake-radius
     * expansion. z4+ samples the pixel centre directly, so local shoreline shape is exactly the
     * current PJ algorithm at the map's raster resolution.</p>
     */
    private boolean lakePixel(int zoom, long px, long py, double stepX, double stepZ) {
        int sub = zoom <= 3 ? 2 : 1;
        double inv = 1.0D / sub;
        for (int oy = 0; oy < sub; oy++) for (int ox = 0; ox < sub; ox++) {
            int x = (int)Math.floor(header.minWorldX() + (px + (ox + .5D) * inv) * stepX);
            int z = (int)Math.floor(header.minWorldZ() + (py + (oy + .5D) * inv) * stepZ);
            if (runtime.lakeWater(x, z)) return true;
        }
        return false;
    }

    private void renderVectorRivers(BufferedImage image, boolean[] landMask,
                                    PJMTileKey key,
                                    long globalPixelX, long globalPixelY,
                                    double worldPerPixelX, double worldPerPixelZ) throws IOException {
        if (runtime.exactLocalRivers() && Math.max(worldPerPixelX, worldPerPixelZ) <= 4.0D) {
            renderExactFallbackRivers(image, landMask, globalPixelX, globalPixelY,
                    worldPerPixelX, worldPerPixelZ);
            return;
        }
        if (!runtime.vectorRiversAvailable()) {
            // Compatibility fallback for a future PJ whose private RiverData implementation changes.
            // It is intentionally limited to local zooms so an incompatible PJ does not bring back
            // the old nationwide performance problem.
            if (key.zoom() >= 8) {
                renderExactFallbackRivers(image, landMask, globalPixelX, globalPixelY,
                        worldPerPixelX, worldPerPixelZ);
            }
            return;
        }

        double tileMinX = header.minWorldX() + globalPixelX * worldPerPixelX;
        double tileMinZ = header.minWorldZ() + globalPixelY * worldPerPixelZ;
        double tileMaxX = tileMinX + TILE_SIZE * worldPerPixelX;
        double tileMaxZ = tileMinZ + TILE_SIZE * worldPerPixelZ;
        double margin = Math.max(worldPerPixelX, worldPerPixelZ) * 2.0D;

        BufferedImage riverLayer =
                new BufferedImage(TILE_SIZE, TILE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = riverLayer.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_OFF);
            g.setColor(new java.awt.Color(RIVER_ARGB, true));

            double pixelsPerBlock = 0.5D
                    * (1.0D / worldPerPixelX + 1.0D / worldPerPixelZ);

            for (PJMGeographicRuntime.RiverVectorSegment segment :
                    runtime.riverSegments(tileMinX - margin, tileMinZ - margin,
                            tileMaxX + margin, tileMaxZ + margin)) {
                PJMAsyncTileLoader.checkCancelled();
                float strokePixels = (float)Math.max(
                        1.0D, segment.widthBlocks() * pixelsPerBlock);

                // Real PJ water width only. No bank/corridor width and no arbitrary low-zoom
                // multiplier. The sole cartographic concession is a 1-pixel visibility floor.
                g.setStroke(new BasicStroke(strokePixels,
                        BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

                double x1 = (segment.x1() - tileMinX) / worldPerPixelX;
                double y1 = (segment.z1() - tileMinZ) / worldPerPixelZ;
                double x2 = (segment.x2() - tileMinX) / worldPerPixelX;
                double y2 = (segment.z2() - tileMinZ) / worldPerPixelZ;
                g.draw(new Line2D.Double(x1, y1, x2, y2));
            }
        } finally {
            g.dispose();
        }

        // Clip river colour to land / immediate coastline. PJ RiverData intentionally extends
        // sea-bound routes offshore for terrain carving, but that internal extension should not
        // appear as a separate bright river shape in the map ocean.
        for (int y = 0; y < TILE_SIZE; y++) {
            for (int x = 0; x < TILE_SIZE; x++) {
                int river = riverLayer.getRGB(x, y);
                if ((river >>> 24) == 0) continue;

                int idx = y * TILE_SIZE + x;
                if (runtime.exactLocalRivers() && image.getRGB(x, y) == LAKE_ARGB) continue;
                if (landMask[idx] || adjacentLand(landMask, x, y)) {
                    image.setRGB(x, y, RIVER_ARGB);
                }
            }
        }
    }

    private void renderExactFallbackRivers(BufferedImage image, boolean[] landMask,
                                           long globalPixelX, long globalPixelY,
                                           double worldPerPixelX, double worldPerPixelZ) {
        for (int py = 0; py < TILE_SIZE; py++) {
            int worldZ = (int)Math.floor(header.minWorldZ()
                    + (globalPixelY + py + 0.5D) * worldPerPixelZ);
            for (int px = 0; px < TILE_SIZE; px++) {
                if (!landMask[py * TILE_SIZE + px]) continue;
                int worldX = (int)Math.floor(header.minWorldX()
                        + (globalPixelX + px + 0.5D) * worldPerPixelX);
                if (runtime.riverWater(worldX, worldZ)) {
                    image.setRGB(px, py, RIVER_ARGB);
                }
            }
        }
    }

    private static boolean adjacentLand(boolean[] landMask, int x, int y) {
        for (int dy = -1; dy <= 1; dy++) {
            int yy = y + dy;
            if (yy < 0 || yy >= TILE_SIZE) continue;
            for (int dx = -1; dx <= 1; dx++) {
                int xx = x + dx;
                if (xx < 0 || xx >= TILE_SIZE) continue;
                if (landMask[yy * TILE_SIZE + xx]) return true;
            }
        }
        return false;
    }

    private static int terrainColor(int elevationMetres) {
        if (elevationMetres < 20) return 0xFFC4D3AD;
        if (elevationMetres < 100) return 0xFFBECDA5;
        if (elevationMetres < 250) return 0xFFB5C49A;
        if (elevationMetres < 500) return 0xFFAAB98C;
        if (elevationMetres < 900) return 0xFFA0AD80;
        if (elevationMetres < 1400) return 0xFF9B9F79;
        if (elevationMetres < 2200) return 0xFF9B9275;
        if (elevationMetres < 3000) return 0xFFA29A88;
        return 0xFFBAB7AE;
    }

    private static int blend(int a, int b, double t) {
        t = clamp01(t);
        int ar = (a >>> 16) & 255;
        int ag = (a >>> 8) & 255;
        int ab = a & 255;
        int br = (b >>> 16) & 255;
        int bg = (b >>> 8) & 255;
        int bb = b & 255;

        int r = (int)Math.round(ar + (br - ar) * t);
        int g = (int)Math.round(ag + (bg - ag) * t);
        int bl = (int)Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static double clamp01(double value) {
        return Math.max(0.0D, Math.min(1.0D, value));
    }

    private Path tilePath(PJMTileKey key, String extension) {
        return cacheDir.resolve("z" + key.zoom())
                .resolve("x" + key.x())
                .resolve("y" + key.y() + extension);
    }

    private static void cleanupOldAutomaticCaches(Path root, Path current, List<Path> compatible) {
        if (!Files.isDirectory(root)) return;
        try (var children = Files.list(root)) {
            children.filter(Files::isDirectory)
                    .filter(path -> !path.equals(current))
                    .filter(path -> !compatible.contains(path))
                    .sorted(Comparator.comparing(Path::toString))
                    .forEach(PJMProjectJapanMapSource::deleteRecursivelyQuietly);
        } catch (IOException ignored) {
        }
    }

    private static void deleteRecursivelyQuietly(Path root) {
        try (var walk = Files.walk(root)) {
            walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                } catch (IOException ignored) {
                }
            });
        } catch (IOException ignored) {
        }
    }

    private record VisualAggregate(double landFraction, int elevationMetres, double coverage) {
    }
}
