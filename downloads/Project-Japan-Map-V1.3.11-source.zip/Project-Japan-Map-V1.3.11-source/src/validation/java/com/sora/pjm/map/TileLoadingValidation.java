package com.sora.pjm.map;

import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.BooleanSupplier;

/** Exercises obsolete views, invalidation races, decoded-memory bounds and worker shutdown. */
public final class TileLoadingValidation {
    private static int checks;
    private static final AtomicInteger live = new AtomicInteger();
    private static void require(boolean ok, String message) { checks++; if (!ok) throw new AssertionError(message); }
    private static void until(BooleanSupplier condition) throws Exception {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(8);
        while (!condition.getAsBoolean()) { if (System.nanoTime() > deadline) throw new AssertionError("Timed out"); Thread.sleep(2); }
    }
    private static final class Tile implements AutoCloseable {
        final int value; boolean closed;
        Tile(int value) { this.value = value; live.incrementAndGet(); }
        public synchronized void close() { require(!closed,"Decoded tile disposed exactly once"); closed = true; live.decrementAndGet(); }
    }
    public static void main(String[] args) throws Exception {
        CountDownLatch entered = new CountDownLatch(2), release = new CountDownLatch(1), stopped = new CountDownLatch(1);
        List<PJMTileKey> reads = Collections.synchronizedList(new ArrayList<>());
        Thread render = Thread.currentThread();
        var loader = new PJMAsyncTileLoader<Tile>(2,32,4,key -> {
            require(Thread.currentThread() != render,"Decode stays off render thread"); reads.add(key);
            if (key.zoom() == 1) { entered.countDown(); release.await(); }
            return new Tile(key.zoom());
        },stopped::countDown);
        loader.beginView(k -> k.zoom()==1,k -> k.x());
        for(int i=0;i<5000;i++) loader.request(new PJMTileKey(1,i,0));
        require(entered.await(5,TimeUnit.SECONDS),"Workers entered old view");
        require(loader.pendingCount()<=32,"Rapid requests stay bounded");
        loader.beginView(k -> k.zoom()==14,k -> k.x());
        var latest=new PJMTileKey(14,9,3);loader.request(latest);release.countDown();
        until(() -> loader.readyCount()==1);
        var result=loader.poll();require(result.key().equals(latest),"Newest view bypasses obsolete backlog");result.value().close();
        until(() -> loader.discardedCount()==2);
        require(reads.size()==3,"Old queued reads cancelled before decode");
        loader.close();require(stopped.await(5,TimeUnit.SECONDS),"Nonblocking close finishes on worker");
        require(live.get()==0,"Old view native resources released");

        CountDownLatch busy = new CountDownLatch(1), cancelDone = new CountDownLatch(1);
        AtomicInteger passes = new AtomicInteger();
        var cancellable = new PJMAsyncTileLoader<Tile>(1, 8, 2, k -> {
            if (k.zoom() == 1) {
                busy.countDown();
                while (true) { PJMAsyncTileLoader.checkCancelled(); passes.incrementAndGet(); Thread.yield(); }
            }
            return new Tile(k.zoom());
        }, cancelDone::countDown);
        cancellable.request(new PJMTileKey(1,0,0));
        require(busy.await(5,TimeUnit.SECONDS), "Long-running old map started");
        long switched = System.nanoTime();
        cancellable.beginView(k -> k.zoom()==9, k -> 0);
        cancellable.request(new PJMTileKey(9,0,0));
        until(() -> cancellable.readyCount()==1);
        long cancellationMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-switched);
        var newest = cancellable.poll();
        require(newest.key().zoom()==9 && !newest.failed(), "Running obsolete map cancelled; worker reused");
        require(cancellationMs < 2000, "Latest view does not wait for obsolete map generation");
        newest.value().close();
        cancellable.close();require(cancelDone.await(5,TimeUnit.SECONDS), "Cancellation worker closes");

        CountDownLatch first=new CountDownLatch(1), go=new CountDownLatch(1), done=new CountDownLatch(1);
        AtomicInteger version=new AtomicInteger();var key=new PJMTileKey(5,1,2);
        var racing=new PJMAsyncTileLoader<Tile>(2,16,4,k -> {
            int v=version.incrementAndGet();if(v==1){first.countDown();go.await();}return new Tile(v);
        },done::countDown);
        racing.request(key);require(first.await(5,TimeUnit.SECONDS),"Invalidation race started");
        racing.invalidate(k -> true);racing.request(key);until(() -> racing.readyCount()==1);go.countDown();
        until(() -> racing.discardedCount()==1);
        var fresh=racing.poll();require(fresh.value().value==2,"Stale overlay cannot overwrite fresh tile");fresh.value().close();
        racing.close();require(done.await(5,TimeUnit.SECONDS),"Race workers stopped");

        CountDownLatch boundedDone=new CountDownLatch(1);
        var bounded=new PJMAsyncTileLoader<Tile>(2,32,4,k -> new Tile(k.x()),boundedDone::countDown);
        for(int i=0;i<32;i++)bounded.request(new PJMTileKey(7,i,0));
        until(() -> bounded.readyCount()==4 && live.get()==6);
        require(live.get()<=6,"Decoded memory <= ready capacity + active workers");
        bounded.close();require(boundedDone.await(5,TimeUnit.SECONDS),"Blocked publishers close without joining render thread");
        require(live.get()==0,"All decoded resources released on close");

        CountDownLatch failuresDone=new CountDownLatch(1);
        var failures=new PJMAsyncTileLoader<Tile>(1,8,4,k -> {if(k.x()==0)throw new java.io.IOException("retry");return null;},failuresDone::countDown);
        failures.request(new PJMTileKey(0,0,0));failures.request(new PJMTileKey(0,1,0));
        until(() -> failures.readyCount()==2);
        List<Boolean> states=List.of(failures.poll().failed(),failures.poll().failed());
        require(states.contains(true)&&states.contains(false),"Read failure remains distinct from empty ocean");
        failures.close();require(failuresDone.await(5,TimeUnit.SECONDS),"Failure workers stopped");
        var budget=new PJMUploadBudget();require(budget.available(),"First upload allowed");budget.startUpload();budget.startUpload();require(!budget.available(),"At most two GPU uploads per rendered view");
        String report="PJM tile loading validation PASS\nrunningCancellationMs="+cancellationMs+"\nassertions="+checks+"\nobsoleteViewReads=2 active only; queued obsolete reads=0\nnewestViewStarvation=0\nmaxPendingJobs=32 under 5000 requests\nmaxDecodedLive=6 with ready=4 and workers=2\nstaleInvalidationResults=0\nremainingDecodedResources="+live.get()+"\nworkerDecode=PASS\nuploadBudget=2 per view, soft 2 ms after first upload\nNo graphical client, GPU driver timing or FPS measurement.\n";
        Files.createDirectories(Path.of("validation"));Files.writeString(Path.of("validation/tile-loading-1.3.4.txt"),report);System.out.print(report);
    }
}
