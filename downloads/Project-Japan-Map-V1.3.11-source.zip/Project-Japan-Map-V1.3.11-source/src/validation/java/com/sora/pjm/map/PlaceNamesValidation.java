package com.sora.pjm.map;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Independent known-name cases, typed homonyms, Japanese fallback and full bundled-label coverage. */
public final class PlaceNamesValidation {
    private static int checks;
    private static void require(boolean ok,String message) { checks++;if(!ok)throw new AssertionError(message); }
    private static String display(PJMPlaceNames.Kind k,String name){return PJMPlaceNames.display(k,name);}
    public static void main(String[] args)throws Exception{
        require(display(PJMPlaceNames.Kind.RIVER,"Edo").equals("江户川"),"Official Edo spelling");
        require(display(PJMPlaceNames.Kind.RIVER,"Sumida").equals("隅田川"),"Sumida name");
        require(display(PJMPlaceNames.Kind.LAKE,"Biwa").equals("琵琶湖"),"Biwa name");
        require(display(PJMPlaceNames.Kind.RIVER,"Sai").equals("犀川"),"River Sai identity");
        require(display(PJMPlaceNames.Kind.LAKE,"Sai").equals("西湖"),"Lake Sai identity");
        require(display(PJMPlaceNames.Kind.PREFECTURE,"東京都").equals("东京都"),"Tokyo prefecture name");
        require(display(PJMPlaceNames.Kind.CITY,"横浜市").equals("横滨市"),"Yokohama official form");
        require(display(PJMPlaceNames.Kind.MOUNTAIN,"富士山").equals("富士山"),"Fuji complete name");
        require(display(PJMPlaceNames.Kind.LAKE,"パンケトー").equals("パンケトー"),"Preserve kana name without invented lake suffix");
        require(display(PJMPlaceNames.Kind.RIVER,"これからの沢").equals("これからの沢"),"Unknown Japanese remains verbatim");
        require(display(PJMPlaceNames.Kind.RIVER,"FutureRiver-123").isBlank(),"Unknown internal roman ID is not a translated name");
        require(display(PJMPlaceNames.Kind.RIVER,"tidal:tokyo-bay").isBlank(),"Anonymous port owner stays unnamed");
        require(display(PJMPlaceNames.Kind.RIVER,"名称不明").isBlank(),"No invented name for unnamed official waterway");
        int legacyRivers=0,legacyLakes=0;
        for(String line:Files.readAllLines(Path.of("data/names/runtime-inputs.tsv"))){
            if(line.startsWith("#")||line.isBlank())continue;
            String[] f=line.split("\\t");var k=PJMPlaceNames.Kind.valueOf(f[1].toUpperCase(Locale.ROOT));
            String label=display(k,f[2]);require(!label.isBlank()&&!label.matches(".*[A-Za-z].*"),"Unresolved supplied PJ name "+f[2]);
            if(k==PJMPlaceNames.Kind.RIVER)legacyRivers++;else legacyLakes++;
        }
        require(legacyRivers==115&&legacyLakes==33,"Complete attached PJ name coverage");
        int labels=0;
        for(String file:List.of("cities","mountains","marine","islands")){
            var kind=switch(file){case "cities"->PJMPlaceNames.Kind.CITY;case "mountains"->PJMPlaceNames.Kind.MOUNTAIN;case "marine"->PJMPlaceNames.Kind.MARINE;default->PJMPlaceNames.Kind.ISLAND;};
            try(var reader=new BufferedReader(new InputStreamReader(Objects.requireNonNull(PlaceNamesValidation.class.getResourceAsStream("/assets/pjm/geography/"+file+".tsv")),StandardCharsets.UTF_8))){
                for(String line;(line=reader.readLine())!=null;){
                    if(line.isBlank()||line.startsWith("#"))continue;
                    String[] f=line.split("\t");String name=f[file.equals("cities")?1:0];String out=display(kind,name);
                    require(!out.isBlank(),"Lost real named label "+name);require(!out.matches(".*[A-Za-z].*"),"Roman output "+out);labels++;
                }
            }
        }
        String report="PJM place names validation PASS\nassertions="+checks+"\nbundledGeographicLabels="+labels+"\n";
        for(var k:PJMPlaceNames.Kind.values())report+=k+"Aliases="+PJMPlaceNames.aliases(k)+"\n";
        report+="Attached PJ aliases: 115 rivers + 33 lakes resolved.\nTyped river/lake homonyms, Japanese kana fallback, original suffix preservation and hidden machine IDs: PASS\nOfficial translation evidence: data/names/translation-audit.json\n";
        Files.createDirectories(Path.of("validation"));Files.writeString(Path.of("validation/place-names-1.3.4.txt"),report);System.out.print(report);
    }
}
