package com.sora.pjm.map;
import com.sora.pjr.core.*;
import java.nio.file.*;
public final class MapPerformance {
 public static void main(String[] args)throws Exception {
  long start=System.nanoTime(); var engine=WorldEngine.load(); log("engine",start);
  start=System.nanoTime(); var rt=new PJMProjectJapanRefinedRuntime(engine,"0.1.17-alpha"); log("adapter",start);
  var source=new PJMProjectJapanMapSource(rt,Path.of(args[0])); var h=source.header();
  for(String spec:args[1].split(",")) {int zoom=Integer.parseInt(spec); int x=rt.worldXFromLongitude(139.7671),z=rt.worldZFromLatitude(35.6812);
   var key=new PJMTileKey(zoom,(int)Math.floor((x-h.minWorldX())/h.worldWidth()*(1<<zoom)),(int)Math.floor((z-h.minWorldZ())/h.worldHeight()*(1<<zoom)));
   System.out.println("begin "+key);System.out.flush();start=System.nanoTime(); byte[] png=source.readTile(key); log("tile "+key+" bytes="+(png==null?0:png.length),start);
  }
 }
 static void log(String key,long t){System.out.printf("%s %.6f s%n",key,(System.nanoTime()-t)*1e-9);System.out.flush();}
}
