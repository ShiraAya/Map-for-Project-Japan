package com.sora.pjm.map;
import com.sora.pjr.core.*;
import java.nio.file.*;
import java.lang.reflect.Proxy;
import java.util.*;
import javax.imageio.ImageIO;
import java.io.*;
public class MapCoverageValidation {
 public static void main(String[] args)throws Exception {
  System.setProperty("pjm.skipBundledTiles","true");Path out=Path.of(args[0]);Files.createDirectories(out);
  var engine=WorldEngine.load();var runtime=new PJMProjectJapanRefinedRuntime(engine,args[1]);
  var unmasked=(PJMGeographicRuntime)Proxy.newProxyInstance(MapCoverageValidation.class.getClassLoader(),new Class[]{PJMGeographicRuntime.class},(p,m,v)->m.getName().equals("surveyedWater")?PJMGeographicRuntime.SurveyWater.UNMAPPED:m.invoke(runtime,v));
  var source=new PJMProjectJapanMapSource(runtime,out.resolve("actual"));var reference=new PJMProjectJapanMapSource(unmasked,out.resolve("reference"));var h=source.header();
  var field=PJMProjectJapanMapSource.class.getDeclaredField("RIVER_ARGB");field.setAccessible(true);int river=field.getInt(null);
  int total=0,gaps=0;StringBuilder log=new StringBuilder();
  for(int zoom:new int[]{7,8,9}){
   int x=-6042,z=14969,n=1<<zoom;var key=new PJMTileKey(zoom,(int)Math.floor((x-h.minWorldX())/h.worldWidth()*n),(int)Math.floor((z-h.minWorldZ())/h.worldHeight()*n));
   byte[] actual=source.readTile(key);byte[] raw=reference.readTile(key);var im=ImageIO.read(new ByteArrayInputStream(actual));var ref=ImageIO.read(new ByteArrayInputStream(raw));Files.write(out.resolve("yokohama-z"+zoom+".png"),actual);
   int targets=0,missing=0;double dx=h.worldWidth()/(256.0*n),dz=h.worldHeight()/(256.0*n);
   for(int py=0;py<256;py++)for(int px=0;px<256;px++)if(ref.getRGB(px,py)==river){
    int wx=(int)Math.floor(h.minWorldX()+(key.x()*256L+px+.5)*dx),wz=(int)Math.floor(h.minWorldZ()+(key.y()*256L+py+.5)*dz);
    if(runtime.surveyedWater(wx,wz)==PJMGeographicRuntime.SurveyWater.DRY){targets++;if(im.getRGB(px,py)!=river)missing++;}
   }
   log.append("zoom="+zoom+" coveredRiverDryCentres="+targets+" incorrectlyErased="+missing+"\n");total+=targets;gaps+=missing;
  }
  log.append("targetPixels="+total+" erasedPixels="+gaps+"\n");System.out.print(log);Files.writeString(out.resolve("coverage.txt"),log);
  if(args.length>2 && args[2].equals("verify")){if(total==0||gaps!=0)throw new AssertionError("Coarse river coverage regression");System.out.println("MAP COVERAGE PASS");}
 }
}
