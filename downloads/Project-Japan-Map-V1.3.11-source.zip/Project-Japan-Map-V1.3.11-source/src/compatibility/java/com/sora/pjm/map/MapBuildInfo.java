package com.sora.pjm.map;
import com.sora.pjr.core.WorldEngine;
public final class MapBuildInfo {
 public static void main(String[] args)throws Exception {
  var r=new PJMProjectJapanRefinedRuntime(WorldEngine.load(),"0.1.24-alpha");
  System.out.println("fingerprint="+r.fingerprint());
  System.out.println("bounds="+r.minWorldX()+","+r.minWorldZ()+","+r.maxWorldX()+","+r.maxWorldZ());
 }
}
