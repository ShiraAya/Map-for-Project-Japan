package com.sora.pjm.map;
import com.sora.pjr.core.WorldEngine;
import java.nio.file.*;
import java.io.*;
import javax.imageio.ImageIO;
/** User screenshot regression against the actual bundled map bytes. */
public final class OkayamaMapValidation {
 public static void main(String[] args)throws Exception {
  Path out=Path.of(args[0]);Files.createDirectories(out);
  var r=new PJMProjectJapanRefinedRuntime(WorldEngine.load(),"0.1.24-alpha");var s=new PJMProjectJapanMapSource(r,out.resolve("cache"));var h=s.header();
  for(int z:new int[]{7,8,9}) {
   double px=(-257820.0-h.minWorldX())/h.worldWidth()*(256<<z),py=(62406.0-h.minWorldZ())/h.worldHeight()*(256<<z);
   var key=new PJMTileKey(z,(int)px/256,(int)py/256);byte[] b=s.readTile(key);
   if(b==null) {System.out.println("OKAYAMA MAP PASS "+key+" entireTile=ocean");continue;}
   var image=ImageIO.read(new ByteArrayInputStream(b));int color=image.getRGB((int)px%256,(int)py%256);
   if(color!=0xff6e97ad)throw new AssertionError("Screenshot centre is not ocean: "+Integer.toHexString(color));
   Files.write(out.resolve("okayama-z"+z+".png"),b);System.out.println("OKAYAMA MAP PASS "+key+" centre=ocean");
  }
 }
}
