package com.sora.pjm.map;
import com.sora.pjr.core.WorldEngine;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
/** Exact local rendered pixels for the user's long Tokyo Bay strip. */
public final class HarbourMapValidation {
 public static void main(String[] args)throws Exception {
  Path out=Path.of(args[1]);Files.createDirectories(out);
  var r=new PJMProjectJapanRefinedRuntime(WorldEngine.load(),"0.1.24-alpha");var s=new PJMProjectJapanMapSource(r,out.resolve("cache"));var h=s.header();
  Map<PJMTileKey,BufferedImage> images=new HashMap<>();int checks=0;
  for(String line:Files.readAllLines(Path.of(args[0]))){if(line.startsWith("x,"))continue;String[] f=line.split(",");int x=Integer.parseInt(f[0]),y=Integer.parseInt(f[1]);
   if(r.terrain(x,y).land())throw new AssertionError("Adapter still has harbour strip");
   for(int z:new int[]{10,11}){
    double px=(x-h.minWorldX())/h.worldWidth()*(256<<z),py=(y-h.minWorldZ())/h.worldHeight()*(256<<z);var key=new PJMTileKey(z,(int)px/256,(int)py/256);
    if(!images.containsKey(key)){byte[] b=s.readTile(key);images.put(key,b==null?null:ImageIO.read(new ByteArrayInputStream(b)));if(b!=null)Files.write(out.resolve("harbour-"+z+"-"+key.x()+"-"+key.y()+".png"),b);}
    BufferedImage image=images.get(key);if(image!=null&&image.getRGB((int)px%256,(int)py%256)!=0xff6e97ad)throw new AssertionError("Rendered strip remains at "+x+","+y+" zoom="+z);checks++;
   }
  }
  System.out.println("HARBOUR MAP PASS renderedPixels="+checks+" uniqueTiles="+images.size()+" zooms=10,11");
 }
}
