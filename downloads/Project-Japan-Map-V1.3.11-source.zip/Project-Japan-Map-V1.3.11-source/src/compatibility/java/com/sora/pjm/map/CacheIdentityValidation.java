package com.sora.pjm.map;
import com.sora.pjr.core.WorldEngine;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import java.net.URLClassLoader;
import java.lang.reflect.*;
import javax.imageio.ImageIO;

/** Fail-closed data identity, complete bundled coverage, legacy-cache reuse. */
public final class CacheIdentityValidation {
 public static void main(String[] args) throws Exception {
  Path out=Path.of(args[0]);Files.createDirectories(out);
  Path oldJar=Path.of(args[1]),currentJar=Path.of(args[2]);
  var engine=WorldEngine.load();var runtime=new PJMProjectJapanRefinedRuntime(engine,"0.1.22-alpha");
  var renamed=new PJMProjectJapanRefinedRuntime(engine,"only-display-version-changed");
  require(runtime.fingerprint().equals(renamed.fingerprint()),"Version-only update invalidated maps");
  Method fingerprint=PJMProjectJapanRefinedRuntime.class.getDeclaredMethod("fingerprint",Class.class);fingerprint.setAccessible(true);
  try(var loader=new URLClassLoader(new java.net.URL[]{oldJar.toUri().toURL()},null)){
   String old=(String)fingerprint.invoke(runtime,loader.loadClass("com.sora.pjr.core.Geo"));
   require(old.equals(runtime.fingerprint()),"Audited PJR versions diverged");
  }
  for(String resource:List.of("assets/pjr/world/river-shapes.properties","com/sora/pjr/core/Hydrology.class")){
   Path override=out.resolve(resource.endsWith(".class")?"changed-code":"changed-data");Path p=override.resolve(resource);Files.createDirectories(p.getParent());
   try(var in=engine.getClass().getResourceAsStream("/"+resource)){byte[] b=in.readAllBytes();b[b.length-1]^=1;Files.write(p,b);}
   try(var loader=new URLClassLoader(new java.net.URL[]{override.toUri().toURL(),currentJar.toUri().toURL()},null)){
    String changed=(String)fingerprint.invoke(runtime,loader.loadClass("com.sora.pjr.core.Geo"));
    require(!changed.equals(runtime.fingerprint()),"Changed map input reused cache: "+resource);
   }
  }
  Properties index=new Properties();try(var in=CacheIdentityValidation.class.getResourceAsStream("/assets/pjm/precomputed/index.properties")){index.load(in);}
  require(index.getProperty("fingerprint").equals(runtime.fingerprint()),"Bundle fingerprint mismatch");
  PJMGeographicRuntime guard=(PJMGeographicRuntime)Proxy.newProxyInstance(CacheIdentityValidation.class.getClassLoader(),new Class[]{PJMGeographicRuntime.class},(p,m,a)->{
   if(Set.of("visualTerrain","terrain","lakeWater","riverWater","surveyedWater","riverSegments").contains(m.getName()))throw new AssertionError("Cache read queried map provider: "+m.getName());
   return m.invoke(runtime,a);
  });
  var source=new PJMProjectJapanMapSource(guard,out.resolve("bundle-cache"));int pngs=0,empty=0;
  for(String name:index.stringPropertyNames()){
   if(!name.contains("/"))continue;String[] xyz=name.split("/");var key=new PJMTileKey(Integer.parseInt(xyz[0]),Integer.parseInt(xyz[1]),Integer.parseInt(xyz[2]));byte[] bytes=source.readTile(key);
   if(index.getProperty(name).equals("empty")){require(bytes==null,name);empty++;}
   else {require(bytes!=null,name);var image=ImageIO.read(new ByteArrayInputStream(bytes));require(image!=null&&image.getWidth()==256&&image.getHeight()==256,name);image.flush();pngs++;}
  }
  // No legacy tile is in the bundled set; guard ensures a missed read fails immediately.
  byte[] fixture;try(var in=CacheIdentityValidation.class.getResourceAsStream("/assets/pjm/precomputed/0/0/0.png")){fixture=in.readAllBytes();}
  for(String old:index.getProperty("legacyFingerprints").split(",")){
   Path root=out.resolve("legacy-"+old),dir=root.resolve("pjr/render-v10-river-coverage-"+old+"/z14/x0");Files.createDirectories(dir);Files.write(dir.resolve("y0.png"),fixture);Files.createFile(dir.resolve("y1.empty"));
   var cached=new PJMProjectJapanMapSource(guard,root);Thread.sleep(100);
   require(Arrays.equals(fixture,cached.readTile(new PJMTileKey(14,0,0))),"Legacy png deleted/missed");require(cached.readTile(new PJMTileKey(14,0,1))==null,"Legacy empty missed");
  }
  // A mismatched current fingerprint must not inherit whitelisted caches or bundled tiles.
  PJMGeographicRuntime stale=(PJMGeographicRuntime)Proxy.newProxyInstance(CacheIdentityValidation.class.getClassLoader(),new Class[]{PJMGeographicRuntime.class},(p,m,a)->m.getName().equals("fingerprint")?"unknown-map-input":m.invoke(guard,a));
  var wrong=new PJMProjectJapanMapSource(stale,out.resolve("legacy-"+index.getProperty("legacyFingerprints").split(",")[0]));
  Field f=PJMProjectJapanMapSource.class.getDeclaredField("compatibleCacheDirs");f.setAccessible(true);require(((List<?>)f.get(wrong)).isEmpty(),"Incompatible legacy cache accepted");
  String report="Cache identity PASS\nfingerprint="+runtime.fingerprint()+"\nPJR 0.1.21/0.1.22 map identity: equal\nVersion-only rename: same identity\nChanged water resource: invalidates\nUnknown Hydrology bytecode: invalidates\nAll bundled reads: zero provider queries\nbundledPngs="+pngs+" bundledEmptyTiles="+empty+"\nTwo legacy caches: PNG and empty markers retained/read\nChanged current fingerprint: rejects legacy caches\n";
  Files.writeString(out.resolve("cache-identity.txt"),report);System.out.print(report);
 }
 static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
}
