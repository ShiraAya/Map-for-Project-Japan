package com.sora.pjm.map;
import com.sora.pjr.core.WorldEngine;
import java.nio.file.*;
import java.util.*;
/** Memoization must preserve the ordinary renderer's complete PNG bytes. */
public final class DecodedCacheParity {
 public static void main(String[] a)throws Exception {
  System.setProperty("pjm.skipBundledTiles","true");var e=WorldEngine.load();DecodedCoastCache.install(e.hydrology().terrain(),Path.of(a[0]));var r=new PJMProjectJapanRefinedRuntime(e,"0.1.24-alpha");var source=new PJMProjectJapanMapSource(r,Path.of(a[2]));
  for(var key:List.of(new PJMTileKey(4,8,6),new PJMTileKey(4,6,7))){Path old=Path.of(a[1],"pjr","render-v10-river-coverage-"+r.fingerprint(),"z"+key.zoom(),"x"+key.x(),"y"+key.y()+".png");byte[] expected=Files.readAllBytes(old),fresh=source.readTile(key);if(!Arrays.equals(expected,fresh))throw new AssertionError("Memoized renderer pixels differ "+key);System.out.println("DECODED CACHE PIXEL PARITY PASS "+key+" bytes="+fresh.length);}
 }
}
