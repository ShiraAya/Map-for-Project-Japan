package com.sora.pjm.map;

import com.sora.pjr.forge.WorldRuntime;

/** Prints the active data identity without changing map or terrain data. */
public final class PjrCacheBinding {
    public static void main(String[] args) throws Exception {
        var runtime = new PJMProjectJapanRefinedRuntime(WorldRuntime.engine(), args[0]);
        System.out.println(runtime.fingerprint());
    }
}
