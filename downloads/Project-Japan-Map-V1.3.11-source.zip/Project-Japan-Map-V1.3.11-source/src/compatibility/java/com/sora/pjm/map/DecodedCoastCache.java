package com.sora.pjm.map;
import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.security.*;
/** Build tool only: exact decoded coast tiles on disk; bounded RAM, no rendering approximation. */
public final class DecodedCoastCache extends ConcurrentHashMap<Long,short[]> {
 private final Path root;
 private final LinkedHashMap<Long,short[]> hot=new LinkedHashMap<>(256,.75f,true);
 private DecodedCoastCache(Path root){this.root=root;}
 @Override public synchronized short[] get(Object object){
  long key=(Long)object;short[] a=hot.get(key);if(a!=null)return a;
  int z=(int)(key>>>56),x=(int)((key>>>28)&0xfffffff),y=(int)(key&0xfffffff);
  try {byte[] bytes=Files.readAllBytes(root.resolve(z+"-"+x+"-"+y+".raw"));if(bytes.length!=1048576)throw new IOException("Wrong decoded tile length");a=new short[524288];ByteBuffer.wrap(bytes).asShortBuffer().get(a);}
  catch(IOException e){throw new UncheckedIOException(e);}
  if(hot.size()>=128)hot.remove(hot.keySet().iterator().next());hot.put(key,a);return a;
 }
 public static void install(Object terrain,Path root)throws Exception {
  if(!Files.isRegularFile(root.resolve("COMPLETE")))throw new IOException("Incomplete decoded coast cache");
  if(!Files.readString(root.resolve("SOURCE")).equals(sourceSignature()))throw new IOException("Decoded cache belongs to different PJR data/code");
  var pf=terrain.getClass().getDeclaredField("precision");pf.setAccessible(true);Object p=pf.get(terrain);
  var cf=p.getClass().getDeclaredField("coast");cf.setAccessible(true);Object c=cf.get(p);
  var cache=c.getClass().getDeclaredField("cache");cache.setAccessible(true);cache.set(c,new DecodedCoastCache(root));
 }
 public static String sourceSignature()throws Exception {
  Class<?> anchor=Class.forName("com.sora.pjr.core.TiledRaster");MessageDigest digest=MessageDigest.getInstance("SHA-256");SortedSet<String> paths=new TreeSet<>();
  paths.add("/com/sora/pjr/core/CoastTileCodec.class");paths.add("/com/sora/pjr/core/TiledRaster.class");
  String prefix="/assets/pjr/terrain/urban-coast/";paths.add(prefix+"format.properties");paths.add(prefix+"index.tsv");
  try(var in=new BufferedReader(new InputStreamReader(anchor.getResourceAsStream(prefix+"index.tsv")))){for(String line;(line=in.readLine())!=null;){if(line.isBlank()||line.startsWith("#"))continue;String[] f=line.split("\\t");int x=Integer.parseInt(f[f.length-2]),y=Integer.parseInt(f[f.length-1]);paths.add(prefix+"packs/14-"+(x/4)+"-"+(y/4)+".pck");}}
  for(String path:paths){digest.update(path.getBytes(java.nio.charset.StandardCharsets.UTF_8));try(var in=anchor.getResourceAsStream(path)){if(in==null)throw new IOException(path);digest.update(in.readAllBytes());}}
  return HexFormat.of().formatHex(digest.digest());
 }
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]);Files.createDirectories(root);Class<?> type=Class.forName("com.sora.pjr.core.TiledRaster");var ctor=type.getDeclaredConstructor(String.class,int.class,int.class,int.class);ctor.setAccessible(true);var tile=type.getDeclaredMethod("tile",int.class,int.class,int.class);tile.setAccessible(true);
  List<String> keys=new ArrayList<>();try(var in=new BufferedReader(new InputStreamReader(type.getResourceAsStream("/assets/pjr/terrain/urban-coast/index.tsv")))){for(String s;(s=in.readLine())!=null;)if(!s.isBlank()&&!s.startsWith("#"))keys.add(s);}
  ThreadLocal<Object> raster=ThreadLocal.withInitial(()->{try{return ctor.newInstance("urban-coast",512,2,1);}catch(Exception e){throw new IllegalStateException(e);}});
  var pool=Executors.newFixedThreadPool(4);List<Future<String>> jobs=new ArrayList<>();long start=System.nanoTime();
  for(String key:keys)jobs.add(pool.submit(()->{String[] f=key.split("\t");int x=Integer.parseInt(f[f.length-2]),y=Integer.parseInt(f[f.length-1]);short[] values=(short[])tile.invoke(raster.get(),14,x,y);ByteBuffer b=ByteBuffer.allocate(values.length*2);b.asShortBuffer().put(values);Path out=root.resolve("14-"+x+"-"+y+".raw");Files.write(out,b.array());byte[] check=Files.readAllBytes(out);if(!Arrays.equals(check,b.array()))throw new AssertionError("Decoded tile write mismatch");return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(check))+"  "+out.getFileName();}));
  pool.shutdown();StringBuilder hashes=new StringBuilder();int count=0;
  try{for(var job:jobs){hashes.append(job.get()).append('\n');if(++count%250==0)System.out.println("decoded="+count+"/"+keys.size()+" seconds="+(System.nanoTime()-start)/1e9);}}
  catch(Exception e){pool.shutdownNow();throw e;}
  Files.writeString(root.resolve("SOURCE"),sourceSignature());Files.writeString(root.resolve("SHA256SUMS"),hashes);Files.writeString(root.resolve("COMPLETE"),"Exact decoded tile roundtrip PASS: "+count+" tiles\n");System.out.println("DECODED COAST CACHE PASS tiles="+count);
 }
}
