package com.sora.pjm.map;

import com.sora.pjr.core.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import javax.imageio.ImageIO;

/** Independent generation oracle, real PJM PNGs, and the pre-repair GSI coastal grid. */
public final class TokyoWaterValidation {
    private static final int OCEAN=0xFF6E97AD,RIVER=0xFF4E9FC8,LAKE=0xFF5B9DBB;
    public static void main(String[] args) throws Exception {
        Path output=Path.of(args[0]),pjr=Path.of(args[1]);boolean baseline=args[2].equals("baseline");
        Files.createDirectories(output);
        String loadedFrom=PJMProjectJapanMapSource.class.getProtectionDomain().getCodeSource().getLocation().toString();
        if(Boolean.getBoolean("pjm.releaseJar")&&!loadedFrom.endsWith("/pjm-1.3.4.jar"))
            throw new AssertionError("Final JAR was not first on classpath: "+loadedFrom);
        WorldEngine engine=WorldEngine.load();Terrain terrain=engine.hydrology().terrain();
        var runtime=new PJMProjectJapanRefinedRuntime(engine,System.getProperty("pjr.version", "0.1.17-alpha"));
        var source=new PJMProjectJapanMapSource(runtime,output.resolve("cache"));
        var h=source.header();Set<PJMTileKey> tiles=new LinkedHashSet<>();
        Files.writeString(output.resolve("header.json"),String.format(Locale.ROOT,
            "{\"minX\":%.0f,\"minZ\":%.0f,\"width\":%.0f,\"height\":%.0f}",h.minWorldX(),h.minWorldZ(),h.worldWidth(),h.worldHeight()));
        for(int zoom=7;zoom<=14;zoom++)for(int[] p:new int[][]{{2506,1452},{2319,1191}})
            tiles.add(new PJMTileKey(zoom,(int)Math.floor((p[0]-h.minWorldX())/h.worldWidth()*(1<<zoom)),
                    (int)Math.floor((p[1]-h.minWorldZ())/h.worldHeight()*(1<<zoom))));
        long sampled=0,missed=0,extra=0,wrong=0,riverMissed=0;StringBuilder csv=new StringBuilder("zoom,tile_x,tile_z,sampled,water_as_land,land_as_water,wrong_water_kind\n");
        for(PJMTileKey key:tiles){
            byte[] png=source.readTile(key);BufferedImage image=png==null?null:ImageIO.read(new ByteArrayInputStream(png));
            if(png!=null)Files.write(output.resolve("z"+key.zoom()+"-"+key.x()+"-"+key.y()+".png"),png);
            long n=0,m=0,e=0,w=0;
            for(int py=0;py<256;py++)for(int px=0;px<256;px++){
                int x=(int)Math.floor(h.minWorldX()+(key.x()*256.0+px+.5)*h.worldWidth()/(256*(1<<key.zoom())));
                int z=(int)Math.floor(h.minWorldZ()+(key.y()*256.0+py+.5)*h.worldHeight()/(256*(1<<key.zoom())));
                if(terrain.channelAuthority(x,z)<=0)continue;
                var water=engine.hydrology().sample(x,z).water();
                int rgb=image==null?OCEAN:image.getRGB(px,py);boolean painted=rgb==RIVER||rgb==LAKE||rgb==OCEAN;n++;
                if(water.wet()&&!painted)m++;
                if(!water.wet()&&painted)e++;
                int expected=switch(water.kind()){case OCEAN->OCEAN;case RIVER->RIVER;case LAKE->LAKE;default->0;};
                if(water.wet()&&painted&&rgb!=expected)w++;
                if(runtime.riverWater(x,z)!=(water.kind()==Hydrology.Kind.RIVER))riverMissed++;
            }
            sampled+=n;missed+=m;extra+=e;wrong+=w;
            csv.append(key.zoom()+","+key.x()+","+key.y()+","+n+","+m+","+e+","+w+"\n");
            System.out.println("tile="+key+" sampled="+n+" waterAsLand="+m+" landAsWater="+e+" wrongKind="+w);
        }
        Files.writeString(output.resolve("tile-parity.csv"),csv);
        String report="PJM Tokyo water "+(baseline?"BASELINE":"PASS")+"\nPJR=0.1.17-alpha\ntiles="+tiles.size()+"\nsampledPixels="+sampled+"\nwaterAsLand="+missed+"\nlandAsWater="+extra+"\nwrongWaterKind="+wrong+"\nriverPredicateMismatches="+riverMissed+"\nloadedFrom="+loadedFrom+"\nNo graphical Minecraft client or GPU-rendering check.\n";
        if(!baseline && (missed!=0||extra!=0||wrong!=0||riverMissed!=0))throw new AssertionError(report);
        Files.writeString(output.resolve("validation.txt"),report);System.out.print(report);
        if(baseline)audit(engine,pjr,output);
    }

    private static void audit(WorldEngine engine,Path pjr,Path output)throws Exception{
        byte[] raw;
        try(var in=new GZIPInputStream(Files.newInputStream(pjr.resolve("data/baseline-tokyo-bay-0.1.10.pjrt.gz")))){raw=in.readAllBytes();}
        var in=new DataInputStream(new ByteArrayInputStream(raw));in.readInt();in.readInt();
        int x0=in.readInt(),z0=in.readInt(),step=in.readInt(),width=in.readInt(),height=in.readInt();in.readInt();
        int nodes=width*height;in.skipNBytes(nodes*6L);byte[] original=in.readNBytes(nodes);
        Terrain terrain=engine.hydrology().terrain();long[] counts=new long[4];long originalWater=0,sourceDryNowWet=0,outsideSurvey=0;
        Map<String,Long> causes=new TreeMap<>();StringBuilder exceptions=new StringBuilder("x,z,original_kind,kind,owner,survey_distance\n");
        try(var out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(output.resolve("audit-grid.bin"))))){
            for(int v:new int[]{x0,z0,step,width,height})out.writeInt(v);
            for(int j=0;j<height;j++)for(int i=0;i<width;i++){
                int x=x0+i*step,z=z0+j*step;var g=engine.geometry(x,z);int old=original[j*width+i];counts[g.kind().ordinal()]++;
                boolean authority=terrain.channelAuthority(x,z)>0;boolean mapped=terrain.channelShoreDistance(x,z)<0;
                int category=0;
                if(old>0)originalWater++;
                if(old==0&&g.wet()){
                    sourceDryNowWet++;
                    if(!authority){category=4;causes.merge("outside-inner-authority",1L,Long::sum);}
                    else if(mapped){category=1;causes.merge("repaired-survey-mask",1L,Long::sum);}
                    else if(terrain.channelShoreDistance(x,z)<=2){category=2;causes.merge("bank<=2",1L,Long::sum);}
                    else {category=3;outsideSurvey++;causes.merge(g.kind()+":"+g.owner(),1L,Long::sum);
                        exceptions.append(x+","+z+","+old+","+g.kind()+","+g.owner()+","+terrain.channelShoreDistance(x,z)+"\n");}
                }
                out.writeByte(old);out.writeByte(g.kind().ordinal());out.writeByte(category);
            }
        }
        String report="PJR Tokyo reclaimed-water audit\nstep="+step+"\ngridNodes="+nodes+"\noriginalWaterNodes="+originalWater+"\nsourceDryNowWet="+sourceDryNowWet+"\noutsideSurveyBeyond2="+outsideSurvey+"\ncauses="+causes+"\nfinalKinds="+Arrays.toString(counts)+"\n";
        Files.writeString(output.resolve("generation-audit.txt"),report);Files.writeString(output.resolve("outside-survey.csv"),exceptions);System.out.print(report);
    }
}
