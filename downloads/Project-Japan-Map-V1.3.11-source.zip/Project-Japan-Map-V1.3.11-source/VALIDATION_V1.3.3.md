# PJM 1.3.3 validation

Environment: Java 17, Minecraft 1.20.1 / Forge 47.4.20 toolchain, supplied PJR 0.1.14-alpha core and resources. The final installable PJM JAR is reobfuscated for Forge.

| Verification | Result |
| --- | --- |
| `check build validateReleasePjrCompatibility` | PASS |
| Final JAR class-origin gate | PASS; four PJM implementation classes loaded from the release JAR |
| Bounded asynchronous tile loading | 30 assertions; 5,000 requests, obsolete view cancellation, no stale same-key result, no retained decoded resources |
| Final JAR name catalogue | 3,236 assertions; all 1,537 bundled geographic records plus 115 river and 33 lake legacy PJ IDs |
| Name-table offline reproduction | PASS; 3,552 exact typed aliases |
| Actual PJR engine integration | 205,439 assertions; all 332 river and 205 lake display names resolved |
| PJR hydrology samples | 18,595 lake shoreline samples, 494 island holes, 16,932 river samples, 402,389 segments |
| Coordinate / terrain comparison | 3,000 random points |
| Local map pixel comparison | 65,536 pixels matched against the PJR engine predicates |
| Final JAR packaging | ZIP CRC, Java 17 bytecode, version 1.3.3, all 9 source assets and absence of bundled PJ/PJR core: PASS |
| Existing map assets | All existing 1.3.2 assets identical; added the name catalogue only |

The loader test uses a deliberately smaller configuration (32 queued jobs, 4 ready results and 2 workers) to exercise queue limits; production defaults are 128 jobs and 8 ready results per cache. Maximum live decoded results were 6 in that test, and 0 remained after shutdown. These are scheduler/resource tests, not GPU frame-rate measurements.

Integration rendering reused valid disk tiles where available and checked exact local water pixels against the active engine. The cache read times in the build log are not cold-render speed measurements.

The environment has no Minecraft graphical client. Actual client FPS, graphics-driver upload latency and subjective scrolling smoothness were not measured. New tile generation is still limited by terrain computation and disk performance.

Reports: `validation/tile-loading-1.3.3.txt`, `validation/place-names-1.3.3.txt`, `validation/PJR-0.1.14-integration.txt`, `validation/release-archive-1.3.3.txt`.

Reproduce with a Java 17 Forge toolchain and the supplied PJR 0.1.14 source:

```bash
python3 tools/compile_place_names.py --verify
./gradlew check build validateReleasePjrCompatibility -PpjrSource=/absolute/path/ProjectJapanRefined
```

ForgeGradle attempted an optional asset-index metadata fetch during configuration in this restricted environment. That fetch failed; the cached toolchain completed the offline build and all verification tasks successfully. This did not prevent reobfuscation or JAR production.
