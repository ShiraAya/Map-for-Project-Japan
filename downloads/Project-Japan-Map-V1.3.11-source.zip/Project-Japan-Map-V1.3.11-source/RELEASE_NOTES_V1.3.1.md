# Project Japan Map V1.3.1 — PJR compatibility

基线：用户上传的 Project-Japan-Map-V1.3.0-map-rewrite-fast-roads-source.zip。
兼容目标：用户上传的 ProjectJapanRefined-0.1.1-alpha-source.zip。
环境：Minecraft 1.20.1 / Forge 47.4.20 / Java 17。

## 修改内容

1. 增加 PJ/PJR 共用地理接口和独立 PJR 适配器，原 PJ 采样算法保留。
2. 直接使用 PJR Geo 的投影正反算，适配 0.375 等比缩放及东京原点。
3. 使用 PJR 已加载的 WorldEngine，读取其最终 115 河 / 205 湖；不复制旧 PJ 水系，不重复加载整幅 DEM。
4. PJR 湖面调用自身 Polygon.distance/wetBlock，包括岛屿孔洞；河面近景使用 Hydrology 的实际归属。概览河道使用已求解的公开 Segment/Point，而非旧 PJ 的私有河宽公式。
5. 城市、海域、山脚、岛屿的地理覆盖范围按投影比例调整，河湖近邻和山脚外容差仍为 30 格。
6. PJ/PJR 底图缓存按模组及资源指纹隔离；PJR 最大瓦片级别升至 14。
7. 同时安装 PJ/PJR 时，依据客户端已同步的维度类型选择；切换世界/维度时释放小地图并阻止旧 HUD 后台结果写回。
8. 构建固定 ForgeGradle 6.0.54，移除非必需的自动 JDK 下载插件，并确保交付 JAR 执行 reobfJar。

## 使用方法

- 删除客户端 mods 中旧版 PJM JAR，放入 pjm-1.3.1.jar。
- PJR 使用原来的 0.1.1-alpha JAR，无需修改、重新生成世界或修改比例配置。
- 如果只需要自行编译，解压完整源码后执行 gradlew.bat clean build。
- PJM 保持客户端使用方式；PJR 联机需要客户端也安装匹配版本的 PJR。
- 原 PJ 路径点保持原坐标，不对旧存档中的点位做自动比例迁移。

## 适配边界

PJR 0.1.1 尚无公开 terrain getter，本适配器仅在初始化时反射读取 Hydrology.terrain，之后直接调用 Terrain.sample。其他主要地形/河湖操作使用 PJR 的公开接口。若未来 PJR 改变这个字段、投影资源范围或水文接口，仍需重新核对兼容性。

全局概览受像素分辨率限制；低倍率河流有最小 1 像素可见宽度。每像素不超过 4 格时切换为 PJR 的实际河面采样。

原 V1.3.0 方块地图与道路扫描器已经按世界的最低/最高高度查询，没有固定套用原版 320 高度。原有道路样式、扫描周期、道路 zoom≥3.50 和快捷键保持。

本次没有进行 Minecraft 图形客户端实机游玩；具体构建、数据与渲染检查见 VALIDATION_V1.3.1.md。
