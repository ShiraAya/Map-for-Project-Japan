#!/usr/bin/env python3
"""PJM 1.3.4 offline assembly; unchanged reobfuscated client classes from pinned 1.3.3.
Compile-only Forge declarations are NOT shipped. This is not a ForgeGradle/game test.
"""
import argparse, hashlib, shutil, subprocess, zipfile
from pathlib import Path
from class_symbols import class_info
ROOT=Path(__file__).resolve().parents[1]
BASE_JAR='60bc15eb8d3d748c817c398200553a9e67fe96a66dbda7d640fb4a2ae68eaac2'
BASE_SOURCE='f5eda9ba44952054643c626f5d7cc074e04e46ed2aaf4e7299a730584a368f26'
NAMES={'PJMAsyncTileLoader','PJMProjectJapanMapSource','PJMProjectJapanRefinedRuntime'}
PACKAGE='com/sora/pjm/map/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def changed(n):return n.startswith(PACKAGE) and n[len(PACKAGE):].split('$')[0].split('.')[0] in NAMES
def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline-jar',type=Path,required=True);p.add_argument('--baseline-source',type=Path,required=True);a=p.parse_args()
 assert sha(a.baseline_jar)==BASE_JAR and sha(a.baseline_source)==BASE_SOURCE,'Unrecognized baseline'
 with zipfile.ZipFile(a.baseline_source) as z:
  prefix=next(n for n in z.namelist() if n.endswith('/src/main/java/'+PACKAGE+'PJMAsyncTileLoader.java')).split('src/main/java/')[0]+'src/main/java/'
  previous={n[len(prefix):]:z.read(n) for n in z.namelist() if n.startswith(prefix) and n.endswith('.java')}
 actual={f.relative_to(ROOT/'src/main/java').as_posix():f.read_bytes() for f in (ROOT/'src/main/java').rglob('*.java')}
 assert set(previous)==set(actual),'Source set changed: use full Forge build'
 for n,b in actual.items():
  if not changed(n):assert b==previous[n],'Unreviewed adapter/source edit: '+n
 classes=ROOT/'build/offline-classes';shutil.rmtree(classes,ignore_errors=True);classes.mkdir(parents=True)
 sources=list((ROOT/'tools/compile-only').rglob('*.java'))+[ROOT/'src/main/java'/PACKAGE/(n+'.java') for n in sorted(NAMES)]
 subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','17','-encoding','UTF-8','-cp',str(a.baseline_jar.resolve()),'-d',str(classes)]+[str(f) for f in sources],check=True)
 with zipfile.ZipFile(a.baseline_jar) as z:old={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
 fresh={f.relative_to(classes).as_posix():f.read_bytes() for f in (classes/'com/sora/pjm').rglob('*.class')}
 assert fresh and all(changed(n) for n in fresh),'Unexpected compiled class'
 old_info={n[:-6]:class_info(b) for n,b in old.items() if n.endswith('.class')}
 new_info={n[:-6]:class_info(b) for n,b in fresh.items()}
 allowed={r for owner,info in old_info.items() if changed(owner+'.class') for r in info['refs'] if r[0].startswith(('net/','org/apache/'))}
 for owner,info in new_info.items():
  assert info['major']==61
  assert not any(c.startswith(('java/net/','javax/net/','net/minecraft/')) for c in info['classes']),owner
  for r in info['refs']:
   if r[0].startswith(('net/','org/apache/')):assert r in allowed,'Changed Forge ABI: '+str(r)
 compatible=0
 for owner,info in old_info.items():
  if changed(owner+'.class'):continue
  for target,kind,name,desc in info['refs']:
   if not changed(target+'.class'):continue
   key=(kind,name,desc);before=old_info[target]['members'].get(key);after=new_info[target]['members'].get(key)
   assert before is not None and after is not None and (before&15)==(after&15),'Broken client reference: '+str((target,key))
   compatible+=1
 resources={f.relative_to(ROOT/'src/main/resources').as_posix():f.read_bytes() for f in (ROOT/'src/main/resources').rglob('*') if f.is_file()}
 for n,b in old.items():
  if n.startswith('assets/'):assert resources[n]==b,'Changed existing asset: '+n
 assert 'assets/pjm/precomputed/index.properties' in resources,'Bake must finish before release'
 props=dict(l.split('=',1) for l in (ROOT/'gradle.properties').read_text().splitlines() if '=' in l)
 assert props['mod_version']=='1.3.4'
 for n in ['META-INF/mods.toml','pack.mcmeta']:
  if n in resources:
   for k,v in props.items():resources[n]=resources[n].replace(('${'+k+'}').encode(),v.encode())
 entries={n:b for n,b in old.items() if not (n.endswith('.class') and changed(n))}
 entries.update(fresh);entries.update(resources)
 entries['META-INF/MANIFEST.MF']=b'Manifest-Version: 1.0\r\nImplementation-Title: Project Japan Map\r\nImplementation-Version: 1.3.4\r\n\r\n'
 jar=ROOT/'build/libs/pjm-1.3.4.jar';jar.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(entries.items()):
   i=zipfile.ZipInfo(n,(2026,10,8,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b,compresslevel=9)
 assert jar.stat().st_size<50_000_000
 with zipfile.ZipFile(jar) as z:
  assert z.testzip() is None
  assert not any(n.startswith(('net/','org/apache/','com/sora/pjr/')) for n in z.namelist())
  retained=[n for n in old if n.endswith('.class') and not changed(n)]
  for n in retained:assert z.read(n)==old[n]
 report=f'PJM offline assembly PASS\njarBytes={jar.stat().st_size}\nSHA256={sha(jar)}\nfreshClasses={len(fresh)}\nunchangedReobfuscatedClasses={len(retained)}\ncompatibleClientReferences={compatible}\nunchangedJavaSources={len(actual)-len(NAMES)}\n'
 report+='All previous assets byte-identical; compile-only declarations excluded; no PJR classes bundled.\nNo full ForgeGradle, graphical client, GPU or FPS run is claimed.\n'
 (ROOT/'validation/assembly-1.3.4.txt').write_text(report);print(report)
if __name__=='__main__':main()
