#!/usr/bin/env python3
"""Show actual PJM PNG tiles at identical bounds; never synthesize map geometry."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

root=Path(__file__).resolve().parents[1]
h=json.loads((root/'validation/tokyo-release/header.json').read_text())
fig,axes=plt.subplots(2,2,figsize=(12,10))
fig.subplots_adjust(top=.91,bottom=.13,left=.07,right=.98,wspace=.16,hspace=.24)
fig.suptitle('Tokyo water | PJM map correction',fontsize=19,weight='bold')
for row,(zoom,tx,ty,label) in enumerate([(9,285,203,'Arakawa and port canal'),(8,142,101,'Northern Tokyo Bay')]):
    dx=h['width']/(1<<zoom);dz=h['height']/(1<<zoom)
    bounds=[h['minX']+tx*dx,h['minX']+(tx+1)*dx,h['minZ']+(ty+1)*dz,h['minZ']+ty*dz]
    for col,(folder,version) in enumerate([('tokyo-before','PJM 1.3.1'),('tokyo-release','PJM 1.3.2')]):
        ax=axes[row,col]
        ax.imshow(Image.open(root/f'validation/{folder}/z{zoom}-{tx}-{ty}.png'),extent=bounds,interpolation='nearest')
        for n,(x,z) in enumerate([(2506,1452),(2319,1191)],1):
            ax.plot(x,z,'o',markersize=5,markerfacecolor='white',markeredgecolor='#b44340')
            if row==0:ax.annotate(str(n),(x,z),xytext=(7,-13),textcoords='offset points',fontsize=11,color='#a32c29',weight='bold')
        if row==0:
            ax.set_xlim(1550,3250);ax.set_ylim(1680,550)
        ax.set_title(version+' | '+label,fontsize=11,loc='left')
        ax.set_xlabel('X (blocks)',fontsize=9);ax.set_ylabel('Z (blocks)',fontsize=9);ax.tick_params(labelsize=8)
fig.text(.5,.035,'1: screenshot one shoreline   2: screenshot two canal\nSame PJR 0.1.13 world geometry. Real PJM tile output; no terrain changes or graphical-client capture.',ha='center',fontsize=10)
fig.savefig(root/'Tokyo-water-map-comparison.png',dpi=150)
