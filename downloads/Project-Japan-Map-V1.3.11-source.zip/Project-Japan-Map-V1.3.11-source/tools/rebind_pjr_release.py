#!/usr/bin/env python3
"""PJM 1.3.5 metadata-only release, preserving all 1.3.4 Java classes and map PNGs.

Requires pinned PJR 0.1.18, whose terrain and hydraulic output parity was verified.
"""
import argparse, hashlib, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE_JAR = 'f62a54459e35821515d2824848c3b2e41a460672b4ebeb5f86c07a861e1735a6'
BASE_SOURCE = '8c5cf43390306be4ca5fcac260b6033916149fe2110b58b004dc9a9ead5f11c8'
PJR_JAR = '6b00f9bea949be29bc0d1c18a89e41a20a39ac4465e3aab4db83808f33daf0f3'
INDEX = 'assets/pjm/precomputed/index.properties'
FINGERPRINT = 'f8998d27e332fba9e2e0'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser()
    for name in ('baseline-jar', 'baseline-source', 'pjr-jar'):
        p.add_argument('--' + name, required=True, type=Path)
    a = p.parse_args()
    assert sha(a.baseline_jar) == BASE_JAR and sha(a.baseline_source) == BASE_SOURCE
    assert sha(a.pjr_jar) == PJR_JAR, 'PJR parity must be revalidated before rebinding another release'
    with zipfile.ZipFile(a.baseline_source) as z:
        prefix = 'Project-Japan-Map-V1.3.4-source/src/main/java/'
        previous = {n[len(prefix):]: z.read(n) for n in z.namelist() if n.startswith(prefix) and n.endswith('.java')}
    actual = {f.relative_to(ROOT / 'src/main/java').as_posix(): f.read_bytes() for f in (ROOT / 'src/main/java').rglob('*.java')}
    assert previous == actual, 'This metadata-only build cannot compile changed production Java'
    with zipfile.ZipFile(a.baseline_jar) as z:
        entries = {n: z.read(n) for n in z.namelist() if not n.endswith('/')}
    resources = {f.relative_to(ROOT / 'src/main/resources').as_posix(): f.read_bytes() for f in (ROOT / 'src/main/resources').rglob('*') if f.is_file()}
    assets = {n for n in entries if n.startswith('assets/')}
    assert assets == {n for n in resources if n.startswith('assets/')}
    for n in assets - {INDEX}:
        assert entries[n] == resources[n], 'Asset changed: ' + n
    old_index = entries[INDEX].decode().replace('0.1.17-alpha', '0.1.18-alpha').replace('1944f2322168bc23ec0d', FINGERPRINT)
    assert resources[INDEX].decode() == old_index, 'Unexpected map index change'
    props = dict(line.split('=', 1) for line in (ROOT / 'gradle.properties').read_text().splitlines() if '=' in line)
    assert props['mod_version'] == '1.3.5'
    for n in ('META-INF/mods.toml', 'pack.mcmeta'):
        if n in resources:
            for k, v in props.items():
                resources[n] = resources[n].replace(('${' + k + '}').encode(), v.encode())
    original_classes = {n: b for n, b in entries.items() if n.endswith('.class')}
    entries.update(resources)
    entries['META-INF/MANIFEST.MF'] = b'Manifest-Version: 1.0\r\nImplementation-Title: Project Japan Map\r\nImplementation-Version: 1.3.5\r\n\r\n'
    jar = ROOT / 'build/libs/pjm-1.3.5.jar'
    jar.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(jar, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, b in sorted(entries.items()):
            i = zipfile.ZipInfo(n, (2026, 10, 8, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.external_attr = 0o100644 << 16
            z.writestr(i, b, compresslevel=9)
    with zipfile.ZipFile(jar) as z:
        assert z.testzip() is None
        assert all(z.read(n) == b for n, b in original_classes.items())
        assert b'version="1.3.5"' in z.read('META-INF/mods.toml')
    report = (f'PJM metadata-only assembly PASS\njarBytes={jar.stat().st_size}\nSHA256={sha(jar)}\n'
              f'unchangedProductionJavaSources={len(actual)}\nunchangedClasses={len(original_classes)}\n'
              f'unchangedMapPNGs={sum(n.startswith("assets/pjm/precomputed/") and n.endswith(".png") for n in assets)}\n'
              f'PJR=0.1.18-alpha\nfingerprint={FINGERPRINT}\n'
              'All map pixels unchanged; only cache binding and version metadata changed.\n'
              'No full ForgeGradle or graphical client execution is claimed.\n')
    (ROOT / 'validation/assembly-1.3.5.txt').write_text(report)
    print(report)

if __name__ == '__main__':
    main()
