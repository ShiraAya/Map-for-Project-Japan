package net.minecraftforge.fml;
import java.util.Optional;
public class ModList {public static ModList get(){throw new UnsupportedOperationException("compile-only");} public Optional<ModContainer> getModContainerById(String id){throw new UnsupportedOperationException("compile-only");}}
