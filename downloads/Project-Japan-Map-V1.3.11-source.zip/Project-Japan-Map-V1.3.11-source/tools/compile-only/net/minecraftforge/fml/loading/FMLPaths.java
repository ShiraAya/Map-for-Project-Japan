package net.minecraftforge.fml.loading;
import java.nio.file.Path;
public enum FMLPaths { CONFIGDIR; public Path get() {throw new UnsupportedOperationException("compile-only");} }
