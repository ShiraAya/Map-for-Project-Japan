package net.minecraftforge.fml;
import net.minecraftforge.forgespi.language.IModInfo;
public class ModContainer { public IModInfo getModInfo(){throw new UnsupportedOperationException("compile-only");} }
