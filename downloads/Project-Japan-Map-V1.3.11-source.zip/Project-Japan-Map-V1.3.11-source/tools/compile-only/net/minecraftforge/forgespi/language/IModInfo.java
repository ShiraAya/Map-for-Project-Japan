package net.minecraftforge.forgespi.language;
import org.apache.maven.artifact.versioning.ArtifactVersion;
public interface IModInfo { ArtifactVersion getVersion(); }
