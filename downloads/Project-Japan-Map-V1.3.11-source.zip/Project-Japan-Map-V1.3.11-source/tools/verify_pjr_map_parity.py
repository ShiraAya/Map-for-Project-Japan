#!/usr/bin/env python3
"""Verify the exact PJR binaries audited for PJM 1.3.9's narrow compatibility alias.
Usage: python3 tools/verify_pjr_map_parity.py old-pjr.jar new-pjr.jar
This never authorizes/aliases another binary automatically.
"""
import hashlib, re, subprocess, sys, zipfile
from pathlib import Path
old, new = map(Path, sys.argv[1:])
assert hashlib.sha256(old.read_bytes()).hexdigest() == 'edb0e703ade5b05c980a3b988dde5c4caab0db63a481e5fd48e4a5983c490749'
assert hashlib.sha256(new.read_bytes()).hexdigest() == 'a3826c732ebb5ba27b8d222eb699e4d4fe70be26f4c33b148b0734d60b0c40db'
with zipfile.ZipFile(old) as a, zipfile.ZipFile(new) as b:
    assert set(a.namelist()) == set(b.namelist())
    changed = {n for n in a.namelist() if a.read(n) != b.read(n)}
    assert changed == {'META-INF/MANIFEST.MF', 'META-INF/mods.toml', 'com/sora/pjr/core/Hydrology.class'}
def methods(jar):
    text = subprocess.check_output(['java', '-XX:-UsePerfData', '-m', 'jdk.jdeps/com.sun.tools.javap.Main', '-p', '-c', '-constants', '-classpath', str(jar), 'com.sora.pjr.core.Hydrology'], text=True)
    text = re.sub(r'#\d+', '#CP', text)
    parts = re.split(r'(?m)^(  (?:public|private|static).*(?:\);|\{))\n', text)
    return {parts[i]: parts[i+1].strip() for i in range(1, len(parts), 2)}
a, b = methods(old), methods(new)
bank = '  public int bankGround(int, int, com.sora.pjr.core.Hydrology$Context);'
assert {n for n in a.keys() & b.keys() if a[n] != b[n]} == {bank}
assert a.keys() - b.keys() == {'  private static boolean outletBank(com.sora.pjr.core.Lake, com.sora.pjr.core.River$Hit);'}
assert b.keys() - a.keys() == {'  private static double[] lambda$bankGround$3(com.sora.pjr.core.River);'}
assert {n for n, v in a.items() if 'Method outletBank:' in v} == {bank}
print('Pinned map-input parity PASS: only bankGround and its private helpers changed; all assets and other classes identical.')
