#!/usr/bin/env python3
"""PJM 1.3.6 resource update, preserving all 1.3.5 Java classes, rebuilding maps.

Requires pinned PJR 0.1.19, whose terrain and hydraulic output parity was verified.
"""
import argparse, hashlib, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE_JAR = '305e96d7ec6b89e8f3059eae76ad206c63fdd603e6157a3015c6a7e9a00a5d15'
BASE_SOURCE = 'ab78cc3ecfe313a0ae4db7bb7bf6b419bfc9469aa066169c2be79f506c7b44fe'
PJR_JAR = '662251d070c9e28a0559b9978c34c158c2966f8c8fc5251f91f82728a2c3cff4'
INDEX = 'assets/pjm/precomputed/index.properties'
FINGERPRINT = None

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser()
    for name in ('baseline-jar', 'baseline-source', 'pjr-jar'):
        p.add_argument('--' + name, required=True, type=Path)
    a = p.parse_args()
    assert sha(a.baseline_jar) == BASE_JAR and sha(a.baseline_source) == BASE_SOURCE
    assert sha(a.pjr_jar) == PJR_JAR, 'PJR parity must be revalidated before rebinding another release'
    with zipfile.ZipFile(a.baseline_source) as z:
        prefix = 'Project-Japan-Map-V1.3.5-source/src/main/java/'
        previous = {n[len(prefix):]: z.read(n) for n in z.namelist() if n.startswith(prefix) and n.endswith('.java')}
    actual = {f.relative_to(ROOT / 'src/main/java').as_posix(): f.read_bytes() for f in (ROOT / 'src/main/java').rglob('*.java')}
    assert previous == actual, 'This metadata-only build cannot compile changed production Java'
    with zipfile.ZipFile(a.baseline_jar) as z:
        entries = {n: z.read(n) for n in z.namelist() if not n.endswith('/')}
    resources = {f.relative_to(ROOT / 'src/main/resources').as_posix(): f.read_bytes() for f in (ROOT / 'src/main/resources').rglob('*') if f.is_file()}
    assets = {n for n in entries if n.startswith('assets/')}
    for n in assets:
        if not n.startswith('assets/pjm/precomputed/') and n != 'assets/pjm/geography/place-names.tsv':
            assert entries[n] == resources[n], 'Asset changed: ' + n
    assert resources['assets/pjm/geography/place-names.tsv'].startswith(entries['assets/pjm/geography/place-names.tsv'])
    index = dict(line.split('=', 1) for line in resources[INDEX].decode().splitlines() if '=' in line)
    assert index['provider'] == 'pjr' and index['renderer'] == 'render-v9-pjr-locality'
    fingerprint = index['fingerprint']
    assert len(fingerprint) == 20 and all(c in '0123456789abcdef' for c in fingerprint)
    for key, value in index.items():
        if '/' in key and value == 'png':
            assert 'assets/pjm/precomputed/' + key + '.png' in resources
    entries = {n: b for n, b in entries.items() if not n.startswith('assets/pjm/precomputed/')}
    props = dict(line.split('=', 1) for line in (ROOT / 'gradle.properties').read_text().splitlines() if '=' in line)
    assert props['mod_version'] == '1.3.6'
    for n in ('META-INF/mods.toml', 'pack.mcmeta'):
        if n in resources:
            for k, v in props.items():
                resources[n] = resources[n].replace(('${' + k + '}').encode(), v.encode())
    original_classes = {n: b for n, b in entries.items() if n.endswith('.class')}
    entries.update(resources)
    entries['META-INF/MANIFEST.MF'] = b'Manifest-Version: 1.0\r\nImplementation-Title: Project Japan Map\r\nImplementation-Version: 1.3.6\r\n\r\n'
    jar = ROOT / 'build/libs/pjm-1.3.6.jar'
    jar.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(jar, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, b in sorted(entries.items()):
            i = zipfile.ZipInfo(n, (2026, 10, 8, 0, 0, 0))
            i.compress_type = zipfile.ZIP_DEFLATED
            i.external_attr = 0o100644 << 16
            z.writestr(i, b, compresslevel=9)
    with zipfile.ZipFile(jar) as z:
        assert z.testzip() is None
        assert all(z.read(n) == b for n, b in original_classes.items())
        assert b'version="1.3.6"' in z.read('META-INF/mods.toml')
    report = (f'PJM rebuilt-map resource assembly PASS\njarBytes={jar.stat().st_size}\nSHA256={sha(jar)}\n'
              f'unchangedProductionJavaSources={len(actual)}\nunchangedClasses={len(original_classes)}\n'
              f'rebakedMapPNGs={sum(n.startswith("assets/pjm/precomputed/") and n.endswith(".png") for n in resources)}\n'
              f'PJR=0.1.19-alpha\nfingerprint={fingerprint}\n'
              'Production classes unchanged; map pixels rebuilt from final PJR 0.1.19 and source-name aliases appended.\n'
              'No full ForgeGradle or graphical client execution is claimed.\n')
    (ROOT / 'validation/assembly-1.3.6.txt').write_text(report)
    print(report)

if __name__ == '__main__':
    main()
