"""JVM symbol reader used to verify the pinned offline build."""
def class_info(data):
    """Read JVM symbols without loading Minecraft classes."""
    pos = 0

    def read(n):
        nonlocal pos
        value = data[pos:pos + n]
        pos += n
        return value

    def number(n):
        return int.from_bytes(read(n), 'big')

    if number(4) != 0xCAFEBABE:
        raise ValueError('Invalid class file')
    read(2)
    major = number(2)
    pool = [None] * number(2)
    i = 1
    while i < len(pool):
        tag = number(1)
        if tag == 1:
            pool[i] = (tag, read(number(2)).decode('utf-8', errors='replace'))
        elif tag in (7, 8, 16, 19, 20):
            pool[i] = (tag, number(2))
        elif tag in (9, 10, 11, 12, 17, 18):
            pool[i] = (tag, number(2), number(2))
        elif tag in (3, 4):
            read(4)
        elif tag in (5, 6):
            read(8)
            i += 1
        elif tag == 15:
            read(3)
        else:
            raise ValueError('Unknown constant pool tag ' + str(tag))
        i += 1

    def utf(index):
        return pool[index][1]

    def classname(index):
        return utf(pool[index][1])

    flags, this, parent = number(2), number(2), number(2)
    read(2 * number(2))
    members = {}
    for kind in ('field', 'method'):
        for _ in range(number(2)):
            access, name, descriptor = number(2), utf(number(2)), utf(number(2))
            members[(kind, name, descriptor)] = access
            for _ in range(number(2)):
                read(2)
                read(number(4))
    refs, classes = [], set()
    for entry in pool:
        if entry and entry[0] == 7:
            classes.add(utf(entry[1]))
        if entry and entry[0] in (9, 10, 11):
            nt = pool[entry[2]]
            refs.append((classname(entry[1]), 'field' if entry[0] == 9 else 'method',
                         utf(nt[1]), utf(nt[2])))
    return dict(name=classname(this), parent=classname(parent) if parent else None,
                flags=flags, major=major, members=members,
                refs=refs, classes=classes)

