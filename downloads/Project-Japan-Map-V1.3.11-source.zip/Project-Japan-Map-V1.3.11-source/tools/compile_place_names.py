#!/usr/bin/env python3
"""Rebuild the offline exact-name catalogue from reviewed Japanese aliases and translation evidence."""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--verify',action='store_true');args=p.parse_args()
 rows=json.loads((ROOT/'data/names/canonical-ja.json').read_text())
 audit={(r['kind'],r['japanese']):r for r in json.loads((ROOT/'data/names/translation-audit.json').read_text())}
 sources={p['url']:p['sha256'] for p in json.loads((ROOT/'data/names/official-source-lock.json').read_text())}
 names={}
 for r in rows:
  ja=r['japanese'];k=r['kind']
  if ja in ['名称不明','名称未設定','不明','無名']:continue
  entry=audit[(k,ja)];display=entry['display'];cn=display if entry['mode']=='official_chinese' else ''
  if cn:
   assert entry['source'] in sources and sources[entry['source']]==entry['source_sha256']
   assert entry['matched'] and entry['matched'] in cn
  else:assert display==ja
  for alias in set(r['aliases']+[cn] if cn else r['aliases']):
   if not alias:continue
   previous=names.setdefault((k,alias),(ja,display))
   assert previous[1]==display,(k,alias,previous,display)
   names[(k,alias)]=(ja,display)
 output='# kind\talias\tjapanese\tverified_chinese\n'+''.join(f'{k}\t{a}\t{ja}\t{display if display!=ja else ""}\n' for (k,a),(ja,display) in sorted(names.items()))
 target=ROOT/'src/main/resources/assets/pjm/geography/place-names.tsv'
 if args.verify:assert target.read_text()==output,'Outdated name catalogue'
 else:target.write_text(output)
 print('PJM name catalogue reproduction PASS: '+str(len(names))+' aliases; exact typed names; offline build')
if __name__=='__main__':main()
