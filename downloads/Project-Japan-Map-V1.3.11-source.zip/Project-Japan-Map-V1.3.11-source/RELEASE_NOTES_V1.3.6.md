# Project Japan Map V1.3.6

配套 PJR 0.1.19-alpha，Minecraft 1.20.1 / Forge 47.4.20 / Java 17。

按最终 PJR 新水系及港区海岸重新生成 955 张内置 PNG 和 390 个空瓦片索引，覆盖全国 z0–4 与 16 个城市精细海岸区域 z5–9。新数据指纹 `b1c5e66418edfdfe85a3`，避免沿用旧断流水系预览。高倍率地图继续读取 PJR 实际水体判定。

追加全部新增河湖的官方日文显示名，已有中文映射保留；共支持 356 条河流、221 个湖泊。40 个生产 Java 文件和 93 个类与 1.3.5 一致，界面、道路、标记点操作保留。

安装包 4,973,925 字节。关闭游戏，替换旧 PJM JAR，与 PJR 0.1.19 一同重启。地理缓存按新指纹隔离。旧世界区块不会被地图更新修改；地理地图可能与旧区块有差异，可在方块地图中检查已有地形。

最终双 JAR 通过 209,954 项兼容断言、955 张 PNG 解码、正确指纹零地形查询、错误指纹回退；网络尝试 0。东京内置 z8/z4/z0 冷读约 0.46/0.24/0.13 ms，局部 z14 实时瓦片约 409 ms；不包含引擎启动、GPU 或完整客户端帧。无完整 ForgeGradle或图形客户端执行。

装配：`python tools/build_water_release.py --baseline-jar /path/pjm-1.3.5.jar --baseline-source /path/Project-Japan-Map-V1.3.5-source.zip --pjr-jar /path/ProjectJapanRefined-0.1.19-alpha.jar`。脚本固定三个输入摘要并确认生产源码与类原样保留。地图烘焙入口为 `src/compatibility/java/com/sora/pjm/map/BakePjrMaps.java`，对照验证器和最终报告见 `validation/final-pjm-*.txt`、`validation/assembly-1.3.6.txt`。
