# Project Japan Map V1.3.1 验证记录

## 实际执行结果

- Java 17 + ForgeGradle 6.0.54 + Minecraft 1.20.1 / Forge 47.4.20：完整 Java 编译通过。
- `build`、`reobfJar`：成功，交付 JAR 已完成 Forge 运行时名称转换。
- 使用本次上传的 PJR 0.1.1-alpha **真实核心源码和资源**建立引擎，运行 `validatePjrCompatibility`；未使用伪造地形、伪造河湖或游戏 API stub。

```text
PJR_COMPATIBILITY_PASS
Assertions: 186538
Lakes: 205; shoreline samples: 18595; island holes: 494
Rivers: 115; water samples: 5865; segments: 234012
Projection/terrain random points: 3000
Exact local tile pixels: 65536
Provider selection, city/mountain labels, cache isolation/readback: PASS
Elapsed seconds: 14.07

```

## 比对内容

- 东京原点与正反投影；3000 个随机经纬度对应的陆地、高程和海岸覆盖率。
- 全部 205 个湖：代表点、外岸线和 494 个岛屿孔洞环附近的采样。共 18595 个岸线相关样本，对照 PJR Hydrology 的水体归属和湖名。
- 全部 115 条河：河道和横向边缘的 5865 个采样，对照实际水体归属和河名；读取 234012 个最终河段。
- PJ/PJR 同装时的提供者选择、单模组、无模组、提供者缺失及未知世界的决策分支。
- 东京城市标签、富士山标签，以及内置地理目录加载。
- PJR 缓存不删除 PJ 缓存；瓦片缓存读取与首次输出字节一致。
- 日本全国、琵琶湖、津久井湖、琵琶湖出口近景的 PNG 实际生成并目视检查。
- 近景瓦片 65536 像素逐一比对 PJR 湖面；陆地像素中的河面逐一比对 PJR 实际河面。
- 道路、方块地图、路径点子系统源码与用户上传的 V1.3.0 基线逐字节一致。
- 原 PJ 适配器的采样/投影/河线提取方法保持原逻辑，仅接入共用接口及共用结果类型。
- 交付 JAR 含新 PJR 适配器及版本 1.3.1 元数据，不含 PJR 核心类、PJR 数据或集成验证类。

## 验证限度

这是源码构建、真实 PJR 数据集成检查与离线地图渲染检查，**不是 Minecraft 图形客户端实机游玩**。
没有实际连接服务器，也没有在旧 PJ 世界中进行本次实机回归。维度选择的决策分支通过自动检查，联机维度同步仍有赖于正常的 Minecraft/Forge 客户端。
岸线/河道检查为上述抽样及选定局部瓦片逐像素检查，不代表逐格穷尽整个日本世界。
历史文件 VALIDATION_V1.3.0.md 记录的是旧版本当时的环境，本版的构建结果以本文件为准。

## 本地复现

```powershell
gradlew.bat clean build
gradlew.bat validatePjrCompatibility -PpjrSource=D:/ProjectJapanRefined
```

PJR 路径指向含 build.gradle 和 src 的已解压源码根目录；验证任务仅临时编译外部 PJR 核心源码，不将其打入 PJM JAR。
