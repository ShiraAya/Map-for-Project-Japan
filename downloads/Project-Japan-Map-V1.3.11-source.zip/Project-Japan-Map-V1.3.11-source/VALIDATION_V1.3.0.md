# Project Japan Map V1.3.0 validation

## Structural checks

- Old `com.sora.pjm.map.surface` source package removed.
- No `PJMSurface*` references remain in `src/main/java`.
- New block-map cache has a distinct `PJMB` magic, version 1 and `.pjmb` extension.
- Map mode reads the new `PJMBlockMapService` only.
- V1.2 `calculateRGBColor -> ABGR/ARGB swap` path is absent.
- Block-map colour generation uses `MapColor.col` directly as `0xRRGGBB`, then applies client block/biome tint and restrained terrain shading.
- Default-mode `ROAD_MIN_DISPLAY_ZOOM` remains exactly `3.50D`.
- `PJMRoadTileSource.java` SHA-256 is identical to the V1.2.1 baseline, so the accepted road drawing style was not modified by V1.3.

## Executed local checks

- `BLOCKMAP_REGION_ROUNDTRIP_PASS`: writes, closes, reopens and reads a negative-X / positive-Z `.pjmb` chunk and verifies all 256 ARGB entries exactly.
- `ROAD_REGION_DEBOUNCE_ROUNDTRIP_PASS`: writes, closes and reopens the debounced `.pjmr` cache and verifies the expected road bits.
- `ROAD_RENDER_STYLE_UNCHANGED_PASS`: working `PJMRoadTileSource.java` hash matches the V1.2.1 source ZIP exactly.
- full-source `javac --release 17 -proc:none` parse check: no Java syntax/parse failures were found; unresolved Minecraft/Forge types are expected without the ForgeGradle classpath.
- source grep confirms no stale `PJMSurface` Java references.

## Refresh scheduler checks

Road sampler:

- current chunk: 5-tick target refresh
- radius 1: 10 ticks
- radius 2: 20 ticks
- radius 3: 40 ticks
- radius 4: 80 ticks
- outer radius: 120 ticks
- up to 6 loaded chunks per tick
- 2.5 ms scan-loop budget
- urgent queue for dirty/newly received chunks
- 300 ms region-write debounce

Block-map sampler:

- scans loaded chunks only
- Map mode: up to 4 chunks/tick within a 3 ms budget
- other modes: up to 1 chunk/tick within a 0.9 ms budget
- independent `.pjmb` cache and GPU tile cache

## Full Forge build

The wrapper is configured for Gradle 8.8. In the current execution environment the wrapper cannot resolve `services.gradle.org`:

```text
curl: (6) Could not resolve host: services.gradle.org
```

Therefore ForgeGradle never reaches Minecraft/Forge compilation here. Run the final source locally with:

```text
gradlew.bat clean build
```
