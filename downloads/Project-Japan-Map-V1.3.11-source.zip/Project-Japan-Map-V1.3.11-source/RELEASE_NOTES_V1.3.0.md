# Project Japan Map V1.3.0

## Map mode rebuilt from scratch

The V1.2 `PJMSurface*` implementation has been removed rather than patched again.

V1.3 introduces a separate `com.sora.pjm.map.blockmap` pipeline:

- `PJMBlockMapService`
- `PJMBlockRegionStore`
- `PJMBlockTileSource`

The new cache is `.pjmb` under `PJM/cache/<world>/blockmap/<dimension>/regions/`; V1.2 `.pjms` data is never reused.

Surface colour generation now uses `MapColor.col` directly as RRGGBB, optionally blended with Minecraft's client biome/block tint. The old ABGR/ARGB conversion logic is gone. Non-colliding decorative blocks are skipped and a small height-derived shade is applied after the visible surface is selected.

The scanner is independent from map rendering. It performs a low-cost background exploration pass in other modes and receives a larger bounded budget while Map mode is selected.

## Road refresh rework

Road visual style and the `zoom >= 3.50` threshold are unchanged.

The road sampler is replaced with a priority scheduler:

- current chunk target refresh: 5 ticks
- radius 1: 10 ticks
- radius 2: 20 ticks
- radius 3: 40 ticks
- radius 4: 80 ticks
- outer radius: 120 ticks
- maximum 6 chunk scans per tick
- 2.5 ms scan-loop budget
- newly received / explicitly dirty chunks can enter the urgent queue
- road tile cache uses two worker threads for faster visible-tile regeneration

No mapping service ever loads a missing server chunk.

## Unchanged

- Default / Terrain / Map mode cycle remains bound to `\` and synchronized across minimap/full-screen map.
- Default-mode roads remain hidden below zoom 3.50.
- Original V1.1.2 road drawing style is retained.
- Client-only multiplayer `/tp` behaviour remains unchanged.
- `.pjmr` road cache format remains compatible.
