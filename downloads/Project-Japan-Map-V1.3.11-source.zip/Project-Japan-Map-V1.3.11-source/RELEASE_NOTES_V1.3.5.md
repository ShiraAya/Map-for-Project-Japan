# Project Japan Map V1.3.5

配套 PJR 0.1.18-alpha 的启动修复。Minecraft 1.20.1 / Forge 47.4.20 / Java 17。

仅更新版本元数据与内置地图的 PJR 标识 `f8998d27e332fba9e2e0`，防止升级后内置地图失配、重新实时绘制。保留 V1.3.4 全部 40 个生产 Java 源文件、93 个编译类及 955 张 PNG；无绘图算法或用户操作变化。原 PJR 与修复版地形资源、求解水位和几何已完成一致性核验后才复用地图。

安装包 4,947,370 字节。替换旧 PJM JAR，与 PJR 0.1.18-alpha 一起重启。已有标记点保留。地图缓存按新数据标识隔离，内置层级可直接读取。

通过 205,527 项最终 JAR 兼容检查、955 张 PNG 解码检查、正确标识零地形采样检查及错误标识回退检查；离线联网尝试为 0。东京内置 z0/z4/z8 冷读约 0.11/0.17/0.29 毫秒，局部 z14 实时绘制约 412 毫秒；这些仅为该测试机器的瓦片字节耗时，不包含引擎启动、GPU 或完整游戏帧。

README 的比例说明更正为实际代码读取的 0.5:0.5:0.5；生产适配器一直从 PJR 动态读取比例，不涉及坐标改动。

本次未运行完整 ForgeGradle 或图形客户端。所有 Java 字节码原样继承 1.3.4，本次无新增类。运行时检查使用真实最终 PJR/PJM JAR。

可复现装配入口：

```bash
python tools/rebind_pjr_release.py --baseline-jar /path/pjm-1.3.4.jar --baseline-source /path/Project-Japan-Map-V1.3.4-source.zip --pjr-jar /path/ProjectJapanRefined-0.1.18-alpha.jar
```

脚本固定校验三个发布文件摘要，拒绝任何生产源代码或 PNG 改动。验证入口 `src/compatibility/java/com/sora/pjm/map/MapBundleValidation.java` 与 `PJRCompatibilityValidation.java`，报告为 `validation/final-pjm-*.txt`、`validation/assembly-1.3.5.txt`。旧 1.3.4 性能报告仅为历史记录。
