# PJM 1.3.2 验证记录

Minecraft 1.20.1 / Forge 47.4.20 / Java 17，配合 PJR 0.1.13-alpha。

完整 `check build validatePjrCompatibility` 成功并完成 `reobfJar`。随后把最终发行 JAR 放在类路径首位，运行 `validateReleaseTokyoWater`；验证器确认地图源类实际来自 `pjm-1.3.2.jar`。

| 检查 | 结果 |
|---|---|
| PJR 兼容验证 | 204,916 项断言通过 |
| 河流／湖泊 | 332 条河、205 湖；16,932 个河道采样点，18,595 个湖岸采样点，494 个湖内孔洞 |
| 河道线段 | 402,329 段完整读取 |
| 投影及地形 | 3,000 个随机点一致 |
| 琵琶湖出口详细瓦片 | 65,536 像素与实际水体一致 |
| 东京专项 | 瓦片级别 z7–z14，共 11 张不同瓦片、662,524 个测绘范围内像素 |
| 修复前水面画成陆地 | 222,579 像素 |
| 最终 JAR 水面画成陆地／陆地画成水／水体类型错误 | 均为 0 |
| 河道查询漏判 | 修复前 221,427 次，修复后 0 |
| 缓存 | 旧渲染版本失效、PJ/PJR 目录隔离和 PNG 回读通过 |
| JAR | ZIP、83 个主代码类、Java 17 class 版本、资源字节一致性通过；不内置 PJR 代码 |

东京网格审查与 GSI 原始来源点见 `TOKYO-WATER-AUDIT.md`。PJR 地形代码和资源没有改动。PNG 由真实 PJM 地图瓦片生成器输出；未启动图形客户端、显卡渲染或着色器。

复验命令（`PJR_PATH` 指 PJR 0.1.13 源码目录）：

```bash
./gradlew check build validatePjrCompatibility -PpjrSource="$PJR_PATH"
./gradlew validateReleaseTokyoWater -PpjrSource="$PJR_PATH"
```

`-PwaterBaseline` 仅用于在修复前源码上采集基线，不应把修复后结果当作旧版基线。

SHA-256：`b367d1d9f9aebe37f67e9360f9944e314800d44091e5e05aa1c06700f45246bd`。
