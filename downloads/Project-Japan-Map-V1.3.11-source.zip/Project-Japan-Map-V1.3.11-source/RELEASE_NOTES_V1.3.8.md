# Project Japan Map V1.3.8

配套 PJR 0.1.21-alpha；Minecraft 1.20.1 / Forge 47.4.20 / Java17。

随 PJR 的连岸细条与河岸修复重新生成离线地图。保留 1.3.7 的低倍率河线覆盖修复以及原有全部地图操作、地名和道路显示。

内置 955 张 PNG、390 个空瓦片，PJR 指纹 `b911098dfe6f70c2bcf0`。完全离线，其他倍率继续实时生成和缓存。安装包 4,976,616 字节。

最终双 JAR 检查通过 209,954 项断言、65536细节像素、955 PNG解码与缓存指纹检查。未运行完整 ForgeGradle、图形客户端或 GPU/FPS 测试。

关闭游戏后替换旧 PJM，与 PJR 0.1.21 配套重启。地理地图反映新版生成数据，旧世界已生成区块不会被重写，方块地图可核对现有区块。

构建：`tools/build_feedback_release.py` 以固定 1.3.7 JAR/源码装配；当前检查见 `validation/final-*.txt`、`validation/assembly-1.3.8.txt`。旧报告为历史记录。
