# Project Japan Map V1.3.2

Fixes geographic map water omissions with PJR 0.1.13-alpha. Surveyed lower-river footprints and port canals now override centre-line cartography at all zooms. Canal queries bypass the centre-line bounds filter, and internal anonymous-water IDs are hidden from HUD labels. Coastal resource bytes participate in the geographic cache fingerprint; the rendering revision discards stale automatic coastal tiles.

Install `pjm-1.3.2.jar` in the client mods folder, replacing the old PJM JAR. Keep PJR 0.1.13-alpha and reopen the world. No terrain regeneration is required. Detailed scope and evidence: `TOKYO-WATER-AUDIT.md` and `VALIDATION_V1.3.2.md`.
